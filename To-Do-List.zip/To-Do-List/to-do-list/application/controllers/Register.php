<?php
class Register extends CI_Controller 
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->helper('url');
		$this->load->model('RegisterModel');
		$this->load->library('session');
	}
	public function index()
	{
		$this->load->view('layout/header');
		$this->load->view('register');
		$this->load->view('layout/footer');
	}
		
	public function insertUser()
	{
		if($this->input->post('register') == 'register')
		{
			$result = $this->RegisterModel->selectUsers($this->input->post('email'));
			if($result > 0)
			{
				$this->session->set_flashdata('msg', 'danger');
				$this->session->set_flashdata('error_msg', 'User already present.');
				redirect('Register');
			}
			else
			{
				$password = $this->input->post('password');
				$data['username'] = $this->input->post('username');
				$data['password'] = base64_encode($password);	
				$data['first_name'] = $this->input->post('first_name');
				$data['last_name'] = $this->input->post('last_name');			
				$data['email'] = $this->input->post('email');	
				$data['user_role'] = '0';	
				$data['date'] = date('Y-m-d H:i:s');		
				$result = $this->RegisterModel->insertUser($data);			
				if($result)
				{
					$this->session->set_flashdata('msg', 'success');
					$this->session->set_flashdata('error_msg', 'Registration Successful. Please Login.');
					redirect('Login');
				}
				else
				{
					$this->session->set_flashdata('msg', 'danger');
					$this->session->set_flashdata('error_msg', 'Please try again.');
					redirect('Register');
				}
			}
		}
	}		
}
?>