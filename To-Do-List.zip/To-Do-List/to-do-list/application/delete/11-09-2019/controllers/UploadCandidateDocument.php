<?php
class UploadCandidateDocument extends CI_Controller 
{
	public function __construct()
	{
	
	parent::__construct();
	
	$this->load->database();
	
	$this->load->helper('url');
	$this->load->library('javascript'); 
	$this->load->model('UploadCandidateDocumentModel');
	$this->load->library('session');
	$this->load->library('pagination');
			
	}
		public function index()
		{
			
		}
		public function uploaddoc()
		{
		
			$id = $this->uri->segment(3);
			
			$data['data1'] = $this->UploadCandidateDocumentModel->insertdoc($id);
			$data['user'] = $this->UploadCandidateDocumentModel->showdocuments($id);
			$data['deadline'] = $this->UploadCandidateDocumentModel->showdeadline($id);
			$this->load->view('layout/header');
			$this->load->view('layout/menu_side_bar');
			$this->load->view('layout/menu_top_bar');
			
			$this->load->view('upload_candidate_document',$data);
			
			$this->load->view('layout/footer');
			
		}
		public function uploaddocument()
		{
			
				$userid = $this->input->post('userid');
				$doc_category = $this->input->post('doc_category');
				
				 if(!empty($_FILES['doc']['name']))
				 {
					$filesCount = count($_FILES['doc']['name']);
					for($i = 0; $i < $filesCount; $i++)
					{
						$_FILES['file']['name']     = $_FILES['doc']['name'][$i];
						$_FILES['file']['type']     = $_FILES['doc']['type'][$i];
						$_FILES['file']['tmp_name'] = $_FILES['doc']['tmp_name'][$i];
						$_FILES['file']['error']     = $_FILES['doc']['error'][$i];
						$_FILES['file']['size']     = $_FILES['doc']['size'][$i];
						
						if (!is_dir('uploads/documents/'.$userid)) 
						{
							mkdir('./uploads/documents/' . $userid, 0777, TRUE);

						}
						
						$uploadPath = 'uploads/documents/'.$userid.'/';
						$config['upload_path'] = $uploadPath;
						$config['allowed_types'] = 'jpg|jpeg|png|gif|doc|docx|pdf';
						
						$this->load->library('upload', $config);
						$this->upload->initialize($config);
						
						if($this->upload->do_upload('file'))
							{
								$fileData = $this->upload->data();
								$uploadData[$i]['file_name'] = $fileData['file_name'];
								date_default_timezone_set("Asia/Kolkata");
								$uploadData[$i]['uploaded_on'] = date("Y-m-d H:i:s");
							}
					}
				}
				else
				{
					
				}
					date_default_timezone_set("Asia/Kolkata");
					$created = date("Y-m-d H:i:sa");
					
					$this->UploadCandidateDocumentModel->insertdocument($userid,$doc_category,$uploadData,$created,$filesCount);
					
					$this->session->set_flashdata('msg3', 'success');
					$this->session->set_flashdata('success_msg', 'Documents uploaded sucessfully. Please upload another documents.');
					
					redirect('UploadCandidateDocument/uploaddoc/'.$userid);
				
		}
		public function setdeadline()
		{
			$data['id'] = $this->uri->segment(3);
			$data['doc_category'] = str_replace('-','/',urldecode($this->uri->segment(4)));
			
			$data['numb'] = $this->uri->segment(5);
			//$data['noti'] = $this->DashboardNotificationModel->fetchnotification();
			$this->load->view('layout/header');
			$this->load->view('layout/menu_side_bar');
			$this->load->view('layout/menu_top_bar');
			
			$this->load->view('set_document_deadline',$data);
			
			$this->load->view('layout/footer');
		}
		public function insertdeadline()
		{
			$userid = $this->input->post('userid');
			$numb = $this->input->post('numb');
			$doc_category = $this->input->post('doc_category');
			$deadline = $this->input->post('deadline');
			
			$reason = $this->input->post('reason');
			date_default_timezone_set("Asia/Kolkata");
					$created = date("Y-m-d H:i:sa");
			$this->UploadCandidateDocumentModel->insertdeadlinemodel($userid,$doc_category,$deadline,$reason,$created,$numb);
			//$data['documents'] = $this->UploadCandidateDocumentModel->showdeadline($userid);
			//redirect('UploadCandidateDocument/setdeadline/'.$userid.'/'.$doc_category.'');
			redirect('UploadCandidateDocument/uploaddoc/'.$userid);
		}
		
		
	}

?>