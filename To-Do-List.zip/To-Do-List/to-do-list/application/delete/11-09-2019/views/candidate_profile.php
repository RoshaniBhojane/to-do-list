 <?php
	$path = base_url();
	foreach($data as $row)
	{

?>
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Candidate Profile</h3>
              </div>

              
            </div>
            
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <br><br>
                  <div class="x_content">
                    <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
                      <div class="profile_img">
                        <div id="crop-avatar">
                         
                          <img class="img-responsive avatar-view" src="<?php echo base_url('uploads/profile_image/user.jpg');?>" alt="Avatar" title="Change the avatar">
                        </div>
                      </div>
                      <h3><?php echo $row->first_name; echo "&nbsp"; echo $row->last_name; ?></h3>

                      <ul class="list-unstyled user_data">
                        <li><i class="fa fa-envelope user-profile-icon"></i> <?php echo $row->primary_email_address; ?>
                        </li>

                        <li>
                          <i class="fa fa-briefcase user-profile-icon"></i> <?php echo $row->designation; ?>
                        </li>

                      </ul>

                      <a href="<?php echo $path;?>UpdateCandidatesProcessTwo/updateCandidates/<?php echo $row->id;?>" class="btn btn-success"><i class="fa fa-edit m-right-xs"></i>Edit Profile</a>
                      <br />
                      
                    </div>
                    <div class="col-md-9 col-sm-9 col-xs-12">
                 
                      <div class="" role="tabpanel" data-example-id="togglable-tabs">
                        <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">
                          <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Basic Information</a>
                          </li>
                          <li role="presentation" class=""><a href="#tab_content2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Identity Proofs</a>
                          </li>
                          <li role="presentation" class=""><a href="#tab_content3" role="tab" id="profile-tab2" data-toggle="tab" aria-expanded="false">Job Details</a>
                          </li>
                        </ul>
                        <div id="myTabContent" class="tab-content">
                          <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
  
                                
                                <div class="message_wrapper" style="margin-left:40px">
								<table class="" style="width:75% !important;" width="75% !important">
								<thead>
                                <tr>
									<td><h4 class="heading" style="font-weight:bold">First Name: </h4></td>
									
									<td style="font-size:15px"><?php echo $row->first_name; ?></td>
								</tr>
								
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Middle Name: </h4></td>
									
									<td style="font-size:15px"><?php echo $row->middle_name; ?></td>
								</tr>
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Last Name: </h4></td>
									<td style="font-size:15px"><?php echo $row->last_name; ?></td>
								</tr>
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Primary Email Address: </h4></td>
									<td style="font-size:15px"><?php echo $row->primary_email_address;?></td>
								</tr>
								<?php
								if($row->secondary_email_address !='')
									{ 
								?>
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Secondary Email Address: </h4></td>
									<td style="font-size:15px"><?php echo $row->secondary_email_address; ?></td>
								</tr>
								<?php } ?>
								
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Primary Phone Number: </h4></td>
									<td style="font-size:15px"><?php echo $row->primary_phone;?></td>
								</tr>
								<?php 
								if($row->secondary_phone !='')
										{ ?>
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Secondary Phone Number: </h4></td>
									<td style="font-size:15px"><?php echo $row->secondary_phone;?></td>
								</tr>
										<?php } ?>
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Age: </h4></td>
									<td style="font-size:15px"><?php echo $row->age; ?></td>
								</tr>
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Gender: </h4></td>
									<td style="font-size:15px"><?php echo $row->gender; ?></td>
								</tr>
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Date of Birth: </h4></td>
									<td style="font-size:15px"><?php echo $row->date_of_birth; ?></td>
								</tr>
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Current Address: </h4></td>
									<td style="font-size:15px"><?php echo $row->current_address; ?></td>
								</tr>
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Permanant Address: </h4></td>
									<td style="font-size:15px"><?php echo $row->permanant_address; ?></td>
                                </tr>
								</tbody>
								</table>  
                                </div>
                              
                            <!-- end recent activity -->

                          </div>
                          <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">

                                                            
                                <div class="message_wrapper" style="margin-left:40px">
								<table class="" style="width:42% !important;" width="42% !important">
								<thead>
                                <tr>
									<td><h4 style="font-weight:bold" class="heading">Adhar Number: </h4></td>
									<td style="font-size:15px"><?php echo $row->aadhar_no; ?></td>
								</tr>
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Passport Number: </h4></td>
									<td style="font-size:15px"><?php echo $row->passport_no; ?></td>
								</tr>
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Passport Valid Date: </h4></td>
									<td style="font-size:15px"><?php echo $row->passport_valid_date; ?></td>
								</tr>
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Passport Issue Place: </h4></td>
									<td style="font-size:15px"><?php echo $row->passport_issue_place; ?></td>
								<tr>
								
								</tbody>
								</table> 
                                </div>
                              

                          </div>
                          <div role="tabpanel" class="tab-pane fade" id="tab_content3" aria-labelledby="profile-tab">
                            
                                
                                
                                <div class="message_wrapper" style="margin-left:40px">
								<table class="" style="width:34% !important;" width="34% !important">
								<thead>
                                <tr> 
									<td><h4 style="font-weight:bold" class="heading">Designation: </h4></td>
									<td style="font-size:15px"><?php echo $row->designation; ?></td>
								</tr>
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Offer CTC: </h4></td>
									<td style="font-size:15px"><?php echo $row->offere_ctc; ?></td>
								</tr>
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Date of Joining: </h4></td>
									<td style="font-size:15px"><?php echo $row->date_of_join; ?></td>
								</tr>
								<tr>
									<td><h4 style="font-weight:bold" class="heading">Comments: </h4></td>
									<td style="font-size:15px"><?php echo $row->comments; ?></td>
                                 </tr>
								</tbody>
								</table> 
                                </div>
                              
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php
	}
?>