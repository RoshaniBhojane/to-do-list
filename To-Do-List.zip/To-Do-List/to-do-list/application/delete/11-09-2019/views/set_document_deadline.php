<?php
	$path = base_url();
	$main_doc1 = array("Adhaar Card", "Pan Card", "Passport size photograph", "SSC Marksheet","HSC Marksheet", "Graduation Marksheet", "Post Graduation Marksheet", "Relieving Letter/Experience Letter/Resignation Letter", "Resume", "Salary Slips");
	
?>
				
<div class="right_col" role="main" style="min-height:783px !important">
	<div class="page-title">
        <div class="title_left">
            <h3 style="font-weight:bold">Documents Deadline</h3>
		</div>
    </div>
	<div class="clearfix"></div>
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
                  <div class="x_title">
                    <h2>Set Deadline <!--<small>Candidate Name:</small><br>--><small> Document Category: <?php echo $doc_category; ?></small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
				  <?php
				  
				if($this->session->flashdata('success_msg'))
              {
              ?>
                <div class="alert alert-<?php  echo $this->session->flashdata('msg3');?> fade in">
                 <?php  echo $this->session->flashdata('success_msg');?>    
                </div>
              <?php
              }
				?>
                    <br>
                    <form id="demo-form2" data-parsley-validate="" action="<?php echo base_url('UploadCandidateDocument/insertdeadline')?>" method="post" enctype="multipart/form-data" class="form-horizontal form-label-left" novalidate="">

                      <input type="text" style="display:none" name="userid" value="<?php echo $id; ?>">
					  <input type="text" style="display:none" name="doc_category" value="<?php echo $doc_category; ?>">
					   <input type="text" style="display:none" name="numb" value="<?php echo $numb; ?>">
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Deadline<?php echo $numb; ?> <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <div class="input-group date" id="myDatepicker1">
                                <input type="text" name="deadline" value="" class="form-control">
                                <span class="input-group-addon">
                                   <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                      </div>
					  <div class="form-group">
                        <label for="reason" class="control-label col-md-3 col-sm-3 col-xs-12">Reason<span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="reason" class="form-control col-md-7 col-xs-12" type="text" name="reason">
                        </div>
                      </div>
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          
						  <button class="btn btn-primary" type="reset">Reset</button>
                          <button type="submit" class="btn btn-success">Submit</button>
                        </div>
                      </div>

                    </form>
                  </div>
	</div>
	
</div>
</div>
