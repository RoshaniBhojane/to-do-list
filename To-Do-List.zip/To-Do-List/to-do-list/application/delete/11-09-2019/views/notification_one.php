<div class="right_col" role="main" style="min-height: 1054px;">
          <div class="">

            <div class="page-title">
              <div class="title_left">
                <h3>HR Notifications<small></small></h3>
              </div>

            </div>

            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Notification box<small>User Notification</small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="row">
                      <div class="col-sm-3 mail_list_column">
					  <?php
                        foreach($data1 as $row)
						{
							$id = $row->id;
							$status = $row->status;
						?>
                        <a href="<?php echo base_url();?>NotificationOne/index/<?php echo $id; ?>">
                          <div class="mail_list">
                            <div class="left">
							<?php
							if($status==0)
							{
							?>
                              <i class="fa fa-circle"></i>
							<?php
							}
							else{
							?>
								<i class="fa fa-check-circle"></i>
							<?php
							}
							?>
                            </div>
                            <div class="right">
                              <h3>Deadline one Expired <small><?php echo $row->deadline_date; ?></small></h3>
                              <p>Candidate Name:<?php echo $row->first_name; echo "<br>"; echo $row->last_name; ?></p>
                            </div>
                          </div>
                        </a>
						<?php
						}
						?>
                        
                      </div>
                      <!-- /MAIL LIST -->

                      <!-- CONTENT MAIL -->
					  <?php
					 
					  if(!empty($noti))
					  {
						  foreach($noti as $row)
						  {
					  ?>
                      <div class="col-sm-9 mail_view">
                        <div class="inbox-body">
                          <div class="mail_heading row">
                            
                            <div class="col-md-4 text-right">
                              <p class="date"><?php echo $row->deadline_date; ?></p>
                            </div>
                            <div class="col-md-12">
                              <h4> <?php echo $row->notification_msg; ?></h4>
                            </div>
                          </div>
                          
                          <div class="view-mail">
                            <p>Candidate Name: <?php echo $row->first_name; echo " "; echo $row->last_name; ?></p>
                            <p>Designation: <?php echo $row->designation; ?></p>
                            <p>Document Category: <?php echo $row->document_name; ?></p>
                            <p>Expired On: <?php echo $row->deadline_date; ?></p>
                          </div>
                          
                          
                        </div>

                      </div>
					  <?php
						  }
					  }
					  else
					  {
						  ?>
							<div class="col-sm-9 mail_view">
                        <div class="inbox-body">
                          <div class="mail_heading row">
                            
                            <div class="col-md-4 text-right">
                              <p class="date"><?php echo $row->deadline_date; ?></p>
                            </div>
                            <div class="col-md-12">
                              <h4> Deadline One Expired</h4>
                            </div>
                          </div>
                          
                          <div class="view-mail">
                            <p>Candidate Name:<?php echo $row->first_name; echo " "; echo $row->last_name; ?></p>
                            <p>Designation: <?php echo $row->designation; ?></p>
                            <p>Document Category:<?php echo $row->document_name; ?></p>
                            <p>Expired On:<?php echo $row->deadline_date; ?></p>
                          </div>
                          
                          
                        </div>

                      </div>
						<?php  
					  }
					  ?>
                      <!-- /CONTENT MAIL -->
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>