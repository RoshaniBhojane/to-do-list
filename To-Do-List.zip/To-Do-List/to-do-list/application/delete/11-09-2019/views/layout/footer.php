<!-- footer content -->
        <footer>
          <div class="pull-right">
            Recruitionary | Powered by <a href="https://www.digitalzonein.com/">Digitalzone</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo base_url('assets/vendors/jquery/dist/jquery.min.js'); ?>"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url('assets/vendors/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url('assets/vendors/fastclick/lib/fastclick.js'); ?>"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url('assets/vendors/nprogress/nprogress.js'); ?>"></script>
    <!-- Chart.js -->
    <script src="<?php echo base_url('assets/vendors/Chart.js/dist/Chart.min.js'); ?>"></script>
    <!-- gauge.js -->
    <script src="<?php echo base_url('assets/vendors/gauge.js/dist/gauge.min.js'); ?>"></script>
    <!-- bootstrap-progressbar -->
    <script src="<?php echo base_url('assets/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js'); ?>"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url('assets/vendors/iCheck/icheck.min.js'); ?>"></script>
    <!-- Skycons -->
    <script src="<?php echo base_url('assets/vendors/skycons/skycons.js'); ?>"></script>
    <!-- Flot -->
    <script src="<?php echo base_url('assets/vendors/Flot/jquery.flot.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/Flot/jquery.flot.pie.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/Flot/jquery.flot.time.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/Flot/jquery.flot.stack.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/Flot/jquery.flot.resize.js'); ?>"></script>
    <!-- Flot plugins -->
    <script src="<?php echo base_url('assets/vendors/flot.orderbars/js/jquery.flot.orderBars.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/flot-spline/js/jquery.flot.spline.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/flot.curvedlines/curvedLines.js'); ?>"></script>
    <!-- DateJS -->
    <script src="<?php echo base_url('assets/vendors/DateJS/build/date.js'); ?>"></script>
    <!-- JQVMap -->
    <script src="<?php echo base_url('assets/vendors/jqvmap/dist/jquery.vmap.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/jqvmap/dist/maps/jquery.vmap.world.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js'); ?>"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="<?php echo base_url('assets/vendors/moment/min/moment.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/bootstrap-daterangepicker/daterangepicker.js'); ?>"></script>
    <!-- bootstrap-datetimepicker -->    
    <script src="<?php echo base_url('assets/vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js'); ?>"></script>

    <!-- Datatables -->
    <script src="<?php //echo base_url('assets/vendors/datatables.net/js/jquery.dataTables.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/datatables.net-buttons/js/dataTables.buttons.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/datatables.net-buttons/js/buttons.flash.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/datatables.net-buttons/js/buttons.html5.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/datatables.net-buttons/js/buttons.print.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/datatables.net-responsive/js/dataTables.responsive.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js'); ?>"></script>
    <script src="<?php //echo base_url('assets/vendors/datatables.net-scroller/js/dataTables.scroller.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/jszip/dist/jszip.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/pdfmake/build/pdfmake.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/pdfmake/build/vfs_fonts.js'); ?>"></script>

    <!-- bootstrap-wysiwyg -->
    <script src="<?php echo base_url('assets/vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/jquery.hotkeys/jquery.hotkeys.js'); ?>"></script>
    <script src="<?php echo base_url('assets/vendors/google-code-prettify/src/prettify.js'); ?>"></script>
    <!-- jQuery Tags Input -->
    <script src="<?php echo base_url('assets/vendors/jquery.tagsinput/src/jquery.tagsinput.js'); ?>"></script>
    <!-- Switchery -->
    <script src="<?php echo base_url('assets/vendors/switchery/dist/switchery.min.js'); ?>"></script>
    <!-- Select2 -->
    <script src="<?php echo base_url('assets/vendors/select2/dist/js/select2.full.min.js'); ?>"></script>
    <!-- Parsley -->
    <script src="<?php echo base_url('assets/vendors/parsleyjs/dist/parsley.min.js'); ?>"></script>
    <!-- Autosize -->
    <script src="<?php echo base_url('assets/vendors/autosize/dist/autosize.min.js'); ?>"></script>
    <!-- jQuery autocomplete -->
    <script src="<?php echo base_url('assets/vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js'); ?>"></script>
    <!-- starrr -->
    <script src="<?php echo base_url('assets/vendors/starrr/dist/starrr.js'); ?>"></script>

    <!-- validator -->
    <script src="<?php echo base_url('assets/vendors/validator/validator.js'); ?>"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url('assets/build/js/custom.min.js'); ?>"></script>

    <!--Update status onselect option table -->
    <script>
        $('.statusselect').change(function(e) {
            var status = $(this).val();
            var id = $(this).attr("data-id");
            var formURL = "<?php echo base_url();?>ListCandidatesProcessOne/updateCandidateStatus"; 
            $.ajax(
            {
                url : formURL,
                type: "POST",
                data : {status: status, id: id},
                success:function(data, textStatus, jqXHR) 
                {
                    //$('div#taskdisplay').hide(); 
                    $('td#'+id).load('<?php echo base_url();?>ListCandidatesProcessOne').fadeIn(3000);
                    location.reload(); 
                },
                error: function(jqXHR, textStatus, errorThrown) 
                {
                    //if fails      
                }  
            });   
                 e.preventDefault(); //STOP default action
        });  
    </script>
    <!--End update status onselect option table -->

    <!-- Initialize datetimepicker -->
    <script>
        $('#myDatepicker').datetimepicker();

        $('#myDatepicker1').datetimepicker({
            format: 'YYYY-MM-DD'
        });
        
        $('#myDatepicker2').datetimepicker({
            format: 'DD.MM.YYYY'
        });
        
        $('#myDatepicker3').datetimepicker({
            format: 'hh:mm A'
        });
        
        $('#myDatepicker4').datetimepicker({
            ignoreReadonly: true,
            allowInputToggle: true
        });

        $('#datetimepicker6').datetimepicker();
        
        $('#datetimepicker7').datetimepicker({
            useCurrent: false
        });
        
        $("#datetimepicker6").on("dp.change", function(e) {
            $('#datetimepicker7').data("DateTimePicker").minDate(e.date);
        });
        
        $("#datetimepicker7").on("dp.change", function(e) {
            $('#datetimepicker6').data("DateTimePicker").maxDate(e.date);
        });
        $('#myDatepicker8').datetimepicker({
            format: 'YYYY-MM-DD'
        });
        $('#myDatepicker9').datetimepicker({
            format: 'YYYY-MM-DD'
        });
        $('#fromDatepicker').datetimepicker({
            format: 'YYYY-MM-DD'
        });
        $('#toDatepicker').datetimepicker({
            format: 'YYYY-MM-DD'
        });
        $('#dateofbirth').datetimepicker({
            format: 'YYYY-MM-DD'
        });
         $('#jobrequirementdeadline').datetimepicker({
            format: 'YYYY-MM-DD'
        });
    </script>
    <!--End Initialize datetimepicker -->
    <!-- Add Education list -->
    <script>

        var i = 1000;
        function addeducation()
        {
            var element ='<div class="row"><input type="hidden" name="edu['+i+'][user_id]" value="<?php if(!empty($data['id'])){echo $data['id'];}else{}?>" class="deleteelement_'+i+'"><input type="hidden" name="edu['+i+'][date]" value="<?php echo date("Y-m-d H:i:s"); ?>"><div class="col-md-10 col-sm-10 col-xs-12 form-group has-feedback">  <select id="ex3" class="form-control deleteelement_'+i+'" name="edu['+i+'][degree_type]" required="">    <option>Select Degree</option>    <?php      if(!empty($education))      {        foreach ($education as $education_value)         {    ?>                                        <option value="<?php echo $education_value->degree_type; ?>"><?php echo $education_value->degree_type; ?></option>    <?php        }      }    ?></select></div><div class="col-md-2 col-sm-2 col-xs-12 form-group has-feedback"><button style="margin-left:20px" type="button" class="btn btn-danger btn-xs deleteelement_'+i+'"><a href="javascript:;" style="color:white" onclick="delete1('+i+')">Remove</a></button></div></div><div class="row"><div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">  <input type="text" class="form-control deleteelement_'+i+'" name="edu['+i+'][name_of_institute]" placeholder="Name of institute" required=""></div><div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">  <input type="text" class="form-control deleteelement_'+i+'" name="edu['+i+'][university]" placeholder="University" required=""></div><div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">  <input type="text" class="form-control deleteelement_'+i+'" name="edu['+i+'][specialization]" placeholder="Specialization" required=""></div></div><div class="row"><div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">  <input type="text" class="form-control deleteelement_'+i+'" name="edu['+i+'][marks]" placeholder="Marks" required=""></div><div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">  <input type="text" class="form-control deleteelement_'+i+'" name="edu['+i+'][edu_start_date]" id="fromDatepicker_'+i+'" placeholder="Start date" required=""></div><div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">  <input type="text" class="form-control deleteelement_'+i+' datepicker" name="edu['+i+'][edu_end_date]" id="toDatepicker_'+i+'" placeholder="End date" required=""></div></div><div class="ln_solid"></div>';

            $(".content").append(element);

            $('#fromDatepicker_'+i).datetimepicker({
                format: 'YYYY-MM-DD'
            });
            $('#toDatepicker_'+i).datetimepicker({
                format: 'YYYY-MM-DD'
            });

            i++;

        }
        function delete1(id)
        {
            $('.deleteelement_'+id).remove();
        }
    </script> 
    <!-- End Education list -->
    <script>
        $.ajax({
            url: '<?php echo base_url();?>Dashboard/top_notification', 
            type: 'POST',                         
            success: function(data)
            {
                //alert(data);
               $('.append_top_notification').html(data);
            }
        });
        function read_status()
        {
             $.ajax({
                url: '<?php echo base_url();?>Dashboard/notification_read_status_update', 
                type: 'POST',                         
                success: function(data)
                {
                   $('.read_status_count').text('0');
                }
            });
        }
    </script>
    <!--start Blink text-->
    <script type="text/javascript">
    $(function() {
      var on = false;
      window.setInterval(function() {
        on = !on;
        if (on) {
          $('.redwarning').addClass('red-blink');
        } else {
          $('.red-blink').removeClass('red-blink');
         }
        }, 1000);
      });
    </script>
    <style type="text/css">
    .red-blink 
    { 
      background-color: #b1271f !important; 
      color:#fff !important;font-weight: bold;
    }
    .green-blink 
    { 
      background-color: #499649 !important;
      color:#000 !important;font-weight: bold;
    }
    .redwarning {
        color: red;
    }
    .redfail {
        color: red;
    }
    .greensuccess {
        color: #008000;
        font-weight: 600;
    }
    </style>
    <!--end Blink text-->
  </body>
</html>
