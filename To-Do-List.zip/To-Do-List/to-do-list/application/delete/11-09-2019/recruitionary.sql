-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 11, 2019 at 01:01 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `recruitionary`
--

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('97cf1735ebb191033df8c70195ab2a1ea44d53cc', '49.248.250.134', 1567165034, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536373136343839363b757365726e616d657c733a31303a22736b6f74686177616c65223b66697273745f6e616d657c733a363a2253686974616c223b),
('74e25ba9740c78c3e244d8041a785904092f09b5', '49.248.250.134', 1567165419, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536373136353137323b757365726e616d657c733a32363a227262686f6a616e65406469676974616c7a6f6e65696e2e636f6d223b66697273745f6e616d657c733a373a22726f7368616e69223b),
('a7dde0b0e2076313df437a8bfa994ea88b024f5a', '49.248.250.134', 1567164802, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536373136343538333b757365726e616d657c733a32363a227262686f6a616e65406469676974616c7a6f6e65696e2e636f6d223b66697273745f6e616d657c733a373a22726f7368616e69223b),
('515047f19fd27bacfcf23444e8c674220ee81e89', '49.248.250.134', 1567164861, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536373136343539313b757365726e616d657c733a31303a22736b6f74686177616c65223b66697273745f6e616d657c733a363a2253686974616c223b),
('ea133609975158b2e089a79ad0eca89b497b4c45', '49.248.250.134', 1567163470, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536373136333336363b757365726e616d657c733a31303a22736b6f74686177616c65223b66697273745f6e616d657c733a363a2253686974616c223b),
('79ecfe2a1cbe6d0abd6b0cd4272f34fd44f8a4a7', '49.248.250.134', 1567162966, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536373136323936353b757365726e616d657c733a31303a22736b6f74686177616c65223b66697273745f6e616d657c733a363a2253686974616c223b),
('44f6bdd425c4e35a9051a6fa9d52e4a951080d69', '49.248.250.134', 1567159475, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536373135393437353b),
('005d59f68c6b436ad0f31af9770eb9d15e3e2ecb', '49.248.250.134', 1567159654, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536373135393437363b757365726e616d657c733a31303a22736b6f74686177616c65223b66697273745f6e616d657c733a363a2253686974616c223b),
('f859d2fdabe9bb5fc19d4115d0c552df63e48a57', '49.248.250.134', 1567161040, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536373136313032353b757365726e616d657c733a31303a22736b6f74686177616c65223b66697273745f6e616d657c733a363a2253686974616c223b),
('426a10fd166c1230b4b2b17aa1137f85015b3941', '49.248.250.134', 1567161485, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536373136313335303b757365726e616d657c733a31303a22736b6f74686177616c65223b66697273745f6e616d657c733a363a2253686974616c223b6d7367337c733a373a2273756363657373223b5f5f63695f766172737c613a323a7b733a343a226d736733223b733a333a226e6577223b733a31313a22737563636573735f6d7367223b733a333a226e6577223b7d737563636573735f6d73677c733a36343a22446f63756d656e74732075706c6f616465642073756365737366756c6c792e20506c656173652075706c6f616420616e6f7468657220646f63756d656e74732e223b),
('cdc5edbc46c909b19c865c60e807d3740ce7455c', '49.248.250.134', 1567162012, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536373136313732353b757365726e616d657c733a31303a22736b6f74686177616c65223b66697273745f6e616d657c733a363a2253686974616c223b),
('51d9c81ec9b3ba2accf2bd3fb5214b797a3a2cb6', '49.248.250.134', 1567162300, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536373136323034303b757365726e616d657c733a31303a22736b6f74686177616c65223b66697273745f6e616d657c733a363a2253686974616c223b),
('561f28149847ae6f9537496c6d74d409cf149b6a', '49.248.250.134', 1567162459, 0x5f5f63695f6c6173745f726567656e65726174657c693a313536373136323335343b757365726e616d657c733a31303a22736b6f74686177616c65223b66697273745f6e616d657c733a363a2253686974616c223b);

-- --------------------------------------------------------

--
-- Table structure for table `designation_openings_tbl`
--

CREATE TABLE `designation_openings_tbl` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `designation` varchar(250) NOT NULL,
  `no_requirements` int(11) NOT NULL,
  `comments` text NOT NULL,
  `deadline` date NOT NULL,
  `no_fullfil_requirements` int(11) NOT NULL,
  `approved_status` int(11) DEFAULT '0' COMMENT '0 - Pending, 1 - approved, 2 - not approved',
  `approved_by` int(11) NOT NULL,
  `opening_closed_status` int(11) NOT NULL DEFAULT '0' COMMENT '0 - Pending, 1 - closed, 2 - not closed',
  `opening_closed_by` int(11) NOT NULL,
  `hr_comments` text NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `designation_openings_tbl`
--

INSERT INTO `designation_openings_tbl` (`id`, `user_id`, `designation`, `no_requirements`, `comments`, `deadline`, `no_fullfil_requirements`, `approved_status`, `approved_by`, `opening_closed_status`, `opening_closed_by`, `hr_comments`, `date`) VALUES
(1, 37, 'LGE', 2, 'two LGE need', '2019-09-08', 1, 1, 0, 2, 0, 'test2', '2019-09-10 15:34:26'),
(2, 38, 'BDE', 2, 'two BDE need', '2019-09-19', 1, 1, 0, 2, 0, 'test2', '2019-09-11 16:22:30'),
(3, 37, 'PHP developer', 3, 'developer', '2019-09-17', 3, 1, 0, 0, 0, '', '2019-09-11 15:49:28'),
(4, 38, 'Content Writer', 3, 'fghfghfg', '2019-09-19', 3, 2, 0, 1, 0, 'test', '2019-09-10 23:30:45'),
(5, 37, 'Content Writer', 2, 'test', '0000-00-00', 0, 0, 0, 0, 0, '', '2019-09-10 21:44:16');

-- --------------------------------------------------------

--
-- Table structure for table `documents_deadline_tbl`
--

CREATE TABLE `documents_deadline_tbl` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `document_name` varchar(250) NOT NULL,
  `deadline_one` date NOT NULL,
  `deadline_two` date NOT NULL,
  `comments` text NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `documents_tbl`
--

CREATE TABLE `documents_tbl` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `document_name` varchar(250) NOT NULL,
  `document_path` varchar(250) NOT NULL,
  `document_uploading_date` datetime NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `documents_tbl`
--

INSERT INTO `documents_tbl` (`id`, `user_id`, `document_name`, `document_path`, `document_uploading_date`, `date`) VALUES
(1, 4, 'adharcard', 'zetafree.JPG', '2019-08-29 00:00:00', '2019-08-29 00:00:00'),
(2, 4, 'Adhaar Card', 'Box_logo_-_blue.png', '2019-08-30 00:00:00', '2019-08-30 00:00:00'),
(3, 4, 'pancard', 'zetafree.JPG', '2019-08-30 00:00:00', '2019-08-30 00:00:00'),
(4, 4, 'SSC Marksheet', 'Cognizant-banner-1.jpg', '2019-08-30 00:00:00', '2019-08-30 00:00:00'),
(5, 4, 'HSC Marksheet', '0.png', '2019-08-30 00:00:00', '2019-08-30 00:00:00'),
(6, 5, 'Adhaar Card', 'zetafree.JPG', '2019-08-30 00:00:00', '2019-08-30 00:00:00'),
(7, 5, 'pancard', 'udemy-logo.png', '2019-08-30 00:00:00', '2019-08-30 00:00:00'),
(8, 6, 'Adhaar Card', 'Cognizant-banner-1.jpg', '2019-08-30 00:00:00', '2019-08-30 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `education_list_tbl`
--

CREATE TABLE `education_list_tbl` (
  `id` int(11) NOT NULL,
  `degree_type` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `education_list_tbl`
--

INSERT INTO `education_list_tbl` (`id`, `degree_type`) VALUES
(1, 'S.S.C.'),
(2, 'H.S.C.'),
(3, 'Bachelor'),
(4, 'Master');

-- --------------------------------------------------------

--
-- Table structure for table `education_tbl`
--

CREATE TABLE `education_tbl` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name_of_institute` varchar(250) NOT NULL,
  `university` varchar(250) NOT NULL,
  `location` varchar(250) NOT NULL,
  `degree_type` varchar(250) NOT NULL,
  `specialization` varchar(250) NOT NULL,
  `marks` varchar(50) NOT NULL,
  `edu_start_date` date NOT NULL,
  `edu_end_date` date NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `education_tbl`
--

INSERT INTO `education_tbl` (`id`, `user_id`, `name_of_institute`, `university`, `location`, `degree_type`, `specialization`, `marks`, `edu_start_date`, `edu_end_date`, `date`) VALUES
(87, 6, 'sdgfdg', 'nagpur', '', 'S.S.C.', 'science', '78', '2019-09-15', '2019-10-09', '2019-09-04 16:05:19'),
(88, 6, 'amravati', 'gdfgdfg', '', 'Bachelor', '33', '54', '2019-09-01', '2019-09-30', '2019-09-04 16:05:19'),
(89, 6, 'nagpur', '22', '', 'Master', '33', '78', '2019-09-25', '2019-10-10', '2019-09-04 16:05:19'),
(90, 6, 'kgiet', 'nagpur', '', 'H.S.C.', 'science', '44', '2019-10-02', '2019-10-11', '2019-09-04 16:05:19'),
(96, 12, 'gdfg', 'dfgdfg', '', 'H.S.C.', 'dfdgdfg', '456', '2019-09-10', '2019-10-01', '2019-09-09 16:43:56'),
(97, 13, 'gdfg', 'dfgdfg', '', 'S.S.C.', 'dfdgdfg', 'dfgdfg', '2019-09-03', '2019-10-03', '2019-09-09 16:44:16');

-- --------------------------------------------------------

--
-- Table structure for table `employee_history`
--

CREATE TABLE `employee_history` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `previous_employer` varchar(250) NOT NULL,
  `location` varchar(250) NOT NULL,
  `office_contact` varchar(50) NOT NULL,
  `employee_code` varchar(50) NOT NULL,
  `emp_start_date` date NOT NULL,
  `emp_end_date` date NOT NULL,
  `designation` varchar(250) NOT NULL,
  `ctc` varchar(50) NOT NULL,
  `reason_for_leaving` text NOT NULL,
  `reporting_manager` varchar(250) NOT NULL,
  `hr_manager` varchar(250) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `interview_schedule_tbl`
--

CREATE TABLE `interview_schedule_tbl` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `interview_schedule_date` date NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `interview_schedule_tbl`
--

INSERT INTO `interview_schedule_tbl` (`id`, `user_id`, `interview_schedule_date`, `date`) VALUES
(1, 3, '2019-09-12', '2019-09-04 00:00:00'),
(2, 2, '2019-09-12', '2019-09-04 00:00:00'),
(4, 4, '2019-09-12', '2019-09-04 00:00:00'),
(5, 5, '2019-09-12', '2019-09-04 00:00:00'),
(6, 6, '2019-09-12', '2019-09-04 00:00:00'),
(7, 7, '2019-09-12', '2019-09-04 00:00:00'),
(8, 8, '2019-09-13', '2019-09-04 00:00:00'),
(9, 9, '2019-09-12', '2019-09-04 00:00:00'),
(10, 10, '2019-09-12', '2019-09-04 00:00:00'),
(11, 11, '2019-09-12', '2019-09-04 00:00:00'),
(12, 12, '2019-09-12', '2019-09-04 00:00:00'),
(13, 13, '2019-09-12', '2019-09-04 00:00:00'),
(14, 0, '2019-09-17', '0000-00-00 00:00:00'),
(16, 8, '2019-09-12', '2019-09-04 00:00:00'),
(32, 14, '2019-09-19', '0000-00-00 00:00:00'),
(35, 0, '2019-09-17', '0000-00-00 00:00:00'),
(37, 0, '2019-09-11', '0000-00-00 00:00:00'),
(39, 0, '2019-10-03', '0000-00-00 00:00:00'),
(44, 26, '2019-10-03', '2019-09-05 21:18:08'),
(45, 26, '2019-10-05', '2019-09-05 21:18:08'),
(46, 27, '2019-09-17', '2019-09-05 21:19:21'),
(47, 0, '2019-09-17', '0000-00-00 00:00:00'),
(49, 0, '2019-09-27', '0000-00-00 00:00:00'),
(50, 32, '2019-09-27', '2019-09-05 22:43:43'),
(51, 14, '2019-09-20', '0000-00-00 00:00:00'),
(53, 14, '2019-09-24', '0000-00-00 00:00:00'),
(54, 14, '2019-09-25', '0000-00-00 00:00:00'),
(56, 1, '2019-09-13', '2019-09-06 17:43:41');

-- --------------------------------------------------------

--
-- Table structure for table `mst_designation_tbl`
--

CREATE TABLE `mst_designation_tbl` (
  `id` int(11) NOT NULL,
  `designation` varchar(250) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_designation_tbl`
--

INSERT INTO `mst_designation_tbl` (`id`, `designation`, `date`) VALUES
(1, 'PHP developer', '2019-08-28 00:00:00'),
(2, 'Content Writer', '2019-08-28 00:00:00'),
(3, 'SEO', '2019-08-28 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `mst_users_tbl`
--

CREATE TABLE `mst_users_tbl` (
  `id` int(11) NOT NULL,
  `first_name` varchar(250) NOT NULL,
  `last_name` varchar(250) NOT NULL,
  `middle_name` varchar(250) NOT NULL,
  `fh_first_name` varchar(250) NOT NULL,
  `fh_middle_name` varchar(250) NOT NULL,
  `fh_last_name` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `experience` varchar(250) NOT NULL DEFAULT '0' COMMENT '1 - Fresher, 2 - Experience',
  `source` varchar(250) NOT NULL,
  `primary_email_address` varchar(250) NOT NULL,
  `secondary_email_address` varchar(250) NOT NULL,
  `primary_phone` varchar(110) NOT NULL,
  `secondary_phone` varchar(110) NOT NULL,
  `age` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `date_of_birth` date NOT NULL,
  `current_address` text NOT NULL,
  `permanant_address` text NOT NULL,
  `aadhar_no` varchar(110) NOT NULL,
  `passport_no` varchar(110) NOT NULL,
  `passport_valid_date` date NOT NULL,
  `passport_issue_place` varchar(250) NOT NULL,
  `designation` varchar(110) NOT NULL,
  `net_ctc` float NOT NULL,
  `gross_ctc` float NOT NULL,
  `date_of_join` date NOT NULL,
  `comments` text NOT NULL,
  `status` varchar(50) NOT NULL COMMENT '0 - initiate, 1 - inprocess, 2 - hired, 3 - rejected, 4 - on hold, 5 - join, 6 - not join',
  `user_role` varchar(50) NOT NULL COMMENT '0 - new employee, 1 - data entry, 2 - manager, 3 - HR, 4 - admin',
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mst_users_tbl`
--

INSERT INTO `mst_users_tbl` (`id`, `first_name`, `last_name`, `middle_name`, `fh_first_name`, `fh_middle_name`, `fh_last_name`, `username`, `password`, `experience`, `source`, `primary_email_address`, `secondary_email_address`, `primary_phone`, `secondary_phone`, `age`, `gender`, `date_of_birth`, `current_address`, `permanant_address`, `aadhar_no`, `passport_no`, `passport_valid_date`, `passport_issue_place`, `designation`, `net_ctc`, `gross_ctc`, `date_of_join`, `comments`, `status`, `user_role`, `date`) VALUES
(1, 'roshani', 'bhojane', '', '', '', '', 'rbhojane@digitalzonein.com', 'Um9zaGFuaQ==', '1', 'Job Portal', 'rbhojane@digitalzonein.com', '', '9130890098', '', '', '', '0000-00-00', '', '', '', '', '0000-00-00', '', 'PHP developer', 0, 0, '0000-00-00', '', '3', '4', '2019-09-06 17:43:41'),
(2, 'Shital', 'Kothawale', '', '', '', '', 'skothawale', 'c2hpdGFsQDEyMw==', '', '', 'skothawale@digitalzonein.com', '', '', '', '', '', '0000-00-00', '', '', '', '', '0000-00-00', '', '', 0, 0, '0000-00-00', '', '', '4', '2019-08-28 00:00:00'),
(3, 'Roshani', 'Bhojane', '', '', '', '', 'roshanihr', 'Um9zaGFuaQ==', '0', '', 'rbhojane@digitalzonein.com', '', '9130890098', '', '25', 'female', '2019-08-01', 'Keshav Nagar Pune', '', '', '', '0000-00-00', '', 'PHP developer', 0, 0, '0000-00-00', '1st round completed', '0', '3', '0000-00-00 00:00:00'),
(4, 'Roshani222', 'Bhojane222', 'Subhash', '', '', '', '', '', '', '', 'rbhojane@digitalzonein.com', 'roshu17.bhojane@gmail.com', '9130890098', '9561559337', '25', 'female', '1993-10-05', 'Keshav Nagar Pune', 'Amravati', '', '', '0000-00-00', '', 'PHP developer', 0, 0, '0000-00-00', 'Hired', '2', '0', '0000-00-00 00:00:00'),
(5, 'Shital', 'Kothawale', 'Shankaer', '', '', '', '', '', '', '', 'shitalkothawale111@gmail.com', '', '7420033777', '', '24', 'female', '1994-11-12', 'B-1003, Sonchafa, Ivy estate road, Wagholi', 'B-1003, Sonchafa, Ivy estate road, Wagholi', '', '', '0000-00-00', '', 'PHP developer', 0, 0, '0000-00-00', 'Hired', '2', '0', '0000-00-00 00:00:00'),
(6, 'test', 'test', 'test2', 'test2', 'test222', 'test2', '', '', '2', '', 'roshu17.bhojane@gmail.com', 'rbhojane@digitalzonein.com', '9130890098', '9561559337', '26', 'male', '2019-08-16', 'test', 'test22', '78537857865786', '562121', '2019-10-25', 'test', 'PHP developer', 500000, 0, '2019-10-24', 'test223322 goood', '5', '0', '2019-09-06 16:28:19'),
(7, 'Roshani333', 'Bhojane33', '', '', '', '', '', '', '1', '', 'rbhojane@digitalzonein.com', '', '9130890098', '', '25', 'female', '2019-08-01', 'Keshav Nagar Pune', '', '', '', '0000-00-00', '', 'PHP developer', 0, 0, '0000-00-00', '1st round completed', '0', '0', '2019-09-05 23:00:20'),
(8, 'a', 'a', '', '', '', '', 'rbhojane@digitalzonein.com', 'Um9zaGFuaQ==', '', '', 'rbhojane@digitalzonein.com', '', '', '', '', '', '0000-00-00', '', '', '', '', '0000-00-00', '', '', 0, 0, '0000-00-00', '', '0', '0', '2019-08-26 00:00:00'),
(9, 'b', 'b', '', '', '', '', 'skothawale', 'c2hpdGFsQDEyMw==', '', '', 'skothawale@digitalzonein.com', '', '', '', '', '', '0000-00-00', '', '', '', '', '0000-00-00', '', '', 0, 0, '0000-00-00', '', '0', '0', '2019-08-28 00:00:00'),
(10, 'c', 'c', '', '', '', '', '', '', '0', '', 'rbhojane@digitalzonein.com', '', '9130890098', '', '25', 'female', '2019-08-01', 'Keshav Nagar Pune', '', '', '', '0000-00-00', '', 'PHP developer', 0, 0, '0000-00-00', '1st round completed', '0', '0', '0000-00-00 00:00:00'),
(11, 'd', 'd', 'Subhash', '', '', '', '', '', '', '', 'rbhojane@digitalzonein.com', 'roshu17.bhojane@gmail.com', '9130890098', '9561559337', '25', 'female', '1993-10-05', 'Keshav Nagar Pune', 'Amravati', '', '', '0000-00-00', '', 'PHP developer', 0, 0, '0000-00-00', 'Hired', '2', '0', '0000-00-00 00:00:00'),
(12, 'ererererere', 'rererereree', 'ererererer', 'test2', 'test2', 'test2', '', '', '1', 'Reference', 'shitalkothawale111@gmail.com', '', '7420033777', '', '25', 'female', '1993-10-05', 'B-1003, Sonchafa, Ivy estate road, Wagholi', 'B-1003, Sonchafa, Ivy estate road, Wagholi', '78537857865786', '562121', '2019-09-09', 'Amravati', 'PHP developer', 500000, 300000, '2019-09-11', 'Hired', '2', '0', '2019-09-09 16:43:56'),
(13, 'd', 'd', 'test2', 'test2', 'test222', 'test2', '', '', '1', 'Job Portal', 'roshu17.bhojane@gmail.com', 'rbhojane@digitalzonein.com', '9130890098', '9561559337', '0', 'male', '2019-08-16', 'test', 'test22', '78537857865786', '562121', '2019-10-25', 'test', 'PHP developer', 500000, 300000, '2019-10-24', 'test223322 goood', '5', '0', '2019-09-09 16:44:16'),
(14, 'eeee', 'eeee', '', '', '', '', '', '', 'Select', '', 'eeee@digitalzonein.com', '', '9130890098', '', '25', 'female', '2019-08-01', 'Keshav Nagar Pune', '', '', '', '0000-00-00', '', 'PHP developer', 0, 0, '0000-00-00', '1st round completed', '0', '0', '0000-00-00 00:00:00'),
(36, '444444', '444444444', '', '', '', '', '', '', '1', 'Reference', 'roshu17.bhojane@gmail.com', 'rbhojane@digitalzonein.com', '9130890098', '9561559337', '25', 'female', '1993-11-17', '4444444', '44444444', '', '', '0000-00-00', '', 'Content Writer', 0, 0, '0000-00-00', '4444444', '0', '0', '2019-09-09 15:53:36'),
(37, 'manager1', 'manager1', '', '', '', '', 'manager1', 'Um9zaGFuaQ==', '0', '', 'rbhojane@digitalzonein.com', '', '', '', '', '', '0000-00-00', '', '', '', '', '0000-00-00', '', '', 0, 0, '0000-00-00', '', '', '2', '0000-00-00 00:00:00'),
(38, 'manager2', 'manager2', '', '', '', '', 'manager2', 'Um9zaGFuaQ==', '0', '', 'rbhojane@digitalzonein.com', '', '', '', '', '', '0000-00-00', '', '', '', '', '0000-00-00', '', '', 0, 0, '0000-00-00', '', '', '2', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `id` int(50) NOT NULL,
  `to_user_id` int(100) NOT NULL,
  `form_user_id` int(50) NOT NULL,
  `notification_msg` varchar(200) NOT NULL,
  `notification_type` varchar(200) NOT NULL,
  `document_name` varchar(200) NOT NULL,
  `comments` text NOT NULL,
  `deadline_date` date NOT NULL,
  `date` date NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`id`, `to_user_id`, `form_user_id`, `notification_msg`, `notification_type`, `document_name`, `comments`, `deadline_date`, `date`, `status`) VALUES
(1, 3, 4, 'Deadline One Expired', 'deadline_one', 'SSC Marksheet', '', '2019-09-03', '2019-09-06', 0),
(2, 4, 4, 'Deadline One Expired', 'deadline_one', 'SSC Marksheet', '', '2019-09-03', '2019-09-06', 0),
(3, 8, 4, 'Deadline One Expired', 'deadline_one', 'SSC Marksheet', '', '2019-09-03', '2019-09-06', 1),
(4, 3, 5, 'Deadline One Expired', 'deadline_one', 'SSC Marksheet', '', '2019-09-02', '2019-09-06', 0),
(5, 4, 5, 'Deadline One Expired', 'deadline_one', 'SSC Marksheet', '', '2019-09-02', '2019-09-06', 0),
(6, 8, 5, 'Deadline One Expired', 'deadline_one', 'SSC Marksheet', '', '2019-09-02', '2019-09-06', 1),
(7, 3, 5, 'Deadline One Expired', 'deadline_one', 'Graduation Marksheet', '', '2019-09-04', '2019-09-06', 0),
(8, 4, 5, 'Deadline One Expired', 'deadline_one', 'Graduation Marksheet', '', '2019-09-04', '2019-09-06', 0),
(9, 8, 5, 'Deadline One Expired', 'deadline_one', 'Graduation Marksheet', '', '2019-09-04', '2019-09-06', 1),
(10, 3, 4, 'Deadline One Expired', 'deadline_one', 'Pan Card', '', '2019-09-02', '2019-09-06', 0),
(11, 4, 4, 'Deadline One Expired', 'deadline_one', 'Pan Card', '', '2019-09-02', '2019-09-06', 0),
(12, 8, 4, 'Deadline One Expired', 'deadline_one', 'Pan Card', '', '2019-09-02', '2019-09-06', 1),
(13, 1, 37, 'Requirement for 23 Content Writer', 'Urgent Requirements', '', 'sdgdfgfdg', '2019-09-10', '2019-09-10', 0),
(14, 2, 37, 'Requirement for 23 Content Writer', 'Urgent Requirements', '', 'sdgdfgfdg', '2019-09-10', '2019-09-10', 0);

-- --------------------------------------------------------

--
-- Table structure for table `source_tbl`
--

CREATE TABLE `source_tbl` (
  `id` int(11) NOT NULL,
  `source` varchar(250) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `source_tbl`
--

INSERT INTO `source_tbl` (`id`, `source`, `date`) VALUES
(1, 'Direct walk in', '2019-09-06 00:00:00'),
(2, 'Reference', '2019-09-06 00:00:00'),
(3, 'Job Portal', '2019-09-06 00:00:00'),
(4, 'Linked in', '2019-09-06 00:00:00'),
(5, 'Consultancy', '2019-09-06 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indexes for table `designation_openings_tbl`
--
ALTER TABLE `designation_openings_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documents_deadline_tbl`
--
ALTER TABLE `documents_deadline_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `documents_tbl`
--
ALTER TABLE `documents_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `education_list_tbl`
--
ALTER TABLE `education_list_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `education_tbl`
--
ALTER TABLE `education_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee_history`
--
ALTER TABLE `employee_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `interview_schedule_tbl`
--
ALTER TABLE `interview_schedule_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mst_designation_tbl`
--
ALTER TABLE `mst_designation_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mst_users_tbl`
--
ALTER TABLE `mst_users_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `source_tbl`
--
ALTER TABLE `source_tbl`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `designation_openings_tbl`
--
ALTER TABLE `designation_openings_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `documents_deadline_tbl`
--
ALTER TABLE `documents_deadline_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `documents_tbl`
--
ALTER TABLE `documents_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `education_list_tbl`
--
ALTER TABLE `education_list_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `education_tbl`
--
ALTER TABLE `education_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;
--
-- AUTO_INCREMENT for table `employee_history`
--
ALTER TABLE `employee_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `interview_schedule_tbl`
--
ALTER TABLE `interview_schedule_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `mst_designation_tbl`
--
ALTER TABLE `mst_designation_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `mst_users_tbl`
--
ALTER TABLE `mst_users_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `source_tbl`
--
ALTER TABLE `source_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
