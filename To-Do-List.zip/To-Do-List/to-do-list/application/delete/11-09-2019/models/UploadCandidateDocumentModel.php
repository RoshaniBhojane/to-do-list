<?php

class UploadCandidateDocumentModel extends CI_Model

{
	
	function insertdoc($id)
	{
		$sql = "SELECT * FROM mst_users_tbl WHERE id='".$id."'";
		$query = $this->db->query($sql);
		if($query->num_rows() > 0)
	    {
	    	return $query->result();
	    }
	    else
	    {
	    	return false;
	    }  
	}
	public function showdocuments($userid)
	{
		$sql = "SELECT * FROM documents_tbl WHERE user_id='".$userid."'";
		$query = $this->db->query($sql);
		
		if($query->num_rows() > 0)
	    {
	    	return $query->result();
	    }
	    else
	    {
	    	return false;
	    }  
	}
	function insertdocument($userid,$doc_category,$uploadData,$created,$filesCount)
	{
		for($i = 0; $i < $filesCount; $i++)
			{
				$doc_category1 = $doc_category[$i];
				$document=$uploadData[$i]['file_name'];
				
				
				//$extension = pathinfo($document, PATHINFO_EXTENSION );
				//$document = $doc_category1 . '.' . $extension;
				
				$sql = "SELECT * FROM documents_tbl WHERE user_id='".$userid."' AND document_name='".$doc_category1."'";
				
				$query = $this->db->query($sql);
				if($query->num_rows() > 0)
				{
					$query = "UPDATE documents_tbl SET user_id='".$userid."',document_name='".$doc_category1."',document_path='".$document."',document_uploading_date='".$created."',date='".$created."' WHERE user_id='".$userid."' AND document_name='".$doc_category1."'";
					
					$this->db->query($query);
				}
				else
				{
					
					$query = "insert into documents_tbl(user_id,document_name,document_path,document_uploading_date,date) values('$userid','$doc_category1','$document','$created','$created')";
					$this->db->query($query);
					
					$uploaded = '1';
					
					$query = "UPDATE documents_deadline_tbl SET status='".$uploaded."' WHERE user_id='".$userid."' AND document_name='".$doc_category1."'";
					$this->db->query($query);
				}  
				
			}
		
	}
	function insertdeadlinemodel($userid,$doc_category,$deadline,$reason,$created,$numb)
	{
		if($numb == 1)
		{
		$query = "insert into documents_deadline_tbl(user_id,document_name,deadline_one,comments,date) values('$userid','$doc_category','$deadline','$reason','$created')";
					$this->db->query($query);
		}
		else
		{
			
					
			$query = "UPDATE documents_deadline_tbl SET user_id='".$userid."',deadline_two='".$deadline."',date='".$created."' WHERE user_id='".$userid."' AND document_name='".$doc_category."'";
					
			$this->db->query($query);
		}
		
	}
	public function showdeadline($userid)
	{
		$sql = "SELECT * FROM documents_deadline_tbl WHERE user_id='".$userid."'";
		$query = $this->db->query($sql);
		
		if($query->num_rows() > 0)
	    {
	    	return $query->result();
	    }
	    else
	    {
	    	return false;
	    }  
	}

	
		
}

?>