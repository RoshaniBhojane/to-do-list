<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class AddJobRequirementsManagerModels extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	public function addNewJobRequirements($data)
	{
		$result=$this->db->insert('designation_openings_tbl', $data);
		if($result)
		{
			$sql = "SELECT `id` FROM `mst_users_tbl` WHERE `user_role` = '4'";
			$query = $this->db->query($sql);
				if($query->num_rows() > 0)
				{		
						
					$id = $query->result();	
					//$cnt = count($id);
							
					foreach($id as $row2)
						{
						
							$to_user_id = $row2->id;
								
							$noti_msg = "Requirement for ".$data['no_requirements']." ".$data['designation'];
							$noti_type = "Urgent Requirements";
							
							date_default_timezone_set("Asia/Kolkata");
							$created = date("Y-m-d H:i:sa");
								
							$sql2 = "INSERT INTO `notification`(to_user_id,form_user_id,notification_msg,notification_type,comments,deadline_date,date) values('".$to_user_id."','".$this->session->userdata('user_id')."','".$noti_msg."','".$noti_type."','".$data['comments']."','".$created."','".$created."')";
							  $this->db->query($sql2);
							  print_r($this->db->last_query());
						}
				}
			return true;
		}
	}
	public function updateCandidates($data,$id)
	{
		$this->db->where('id',$id);
        return $this->db->update('designation_openings_tbl',$data);   
	}
	public function getAdmin()
	{
        $condition = $this->db->query('SELECT primary_email_address FROM `mst_users_tbl` WHERE user_role="4"');   
        if($condition->num_rows() > 0)
	    {
	    	return $condition->result();
	    }
	    else
	    {
	    	return false;
	    } 
	}
}
?>
