<?php

class DashboardNotificationModel extends CI_Model

{
	
	function fetchnotification()
	{
		date_default_timezone_set("Asia/Kolkata");
		$nowdate = date("Y-m-d");
		//$sql = "SELECT d.*, m.first_name, m.last_name, m.designation FROM documents_deadline_tbl d INNER JOIN mst_users_tbl m ON d.user_id=m.id WHERE d.deadline_one < '".$nowdate."' AND d.status != '1' limit 5";
		
		$sql = "SELECT * FROM documents_deadline_tbl WHERE deadline_one < '".$nowdate."' AND status != '1'";
		
		$query = $this->db->query($sql);
		
		if($query->num_rows() > 0)
	    {
			$data = $query->result();
			foreach ($data as $row) 
			{
				
				$sql = "SELECT * FROM notification WHERE form_user_id = '".$row->user_id."' AND document_name = '".$row->document_name."' AND notification_type = 'deadline_one'";
		
				$query = $this->db->query($sql);
				
				if($query->num_rows() > 0)
				{		
						  
				}
				else
				{
					$sql = "SELECT id FROM mst_users_tbl WHERE user_role = '3'";
					$query = $this->db->query($sql);
					if($query->num_rows() > 0)
					{		
					
						$id = $query->result();	
						//$cnt = count($id);
						
						foreach($id as $row2)
						{
					
							$to_user_id = $row2->id;;
							
							$noti_msg = "Deadline One Expired";
							$noti_type = "deadline_one";
							date_default_timezone_set("Asia/Kolkata");
							$created = date("Y-m-d H:i:sa");
							
						  $sql2 = "insert into notification(to_user_id,form_user_id,notification_msg,notification_type,document_name,deadline_date,date) values('$to_user_id','".$row->user_id."','$noti_msg','$noti_type','".$row->document_name."','".$row->deadline_one."','$created')";
						  $this->db->query($sql2);
						}
					}
				
				}
			}
			
			/*return $data;
			$val = $query->result();
			echo "<pre>";
			print_r($val);
			die;*/
			
	    }
	    else
	    {
	    	//return false;
	    } 
		
		$sql = "SELECT n.*, m.first_name, m.last_name, m.designation FROM notification n INNER JOIN mst_users_tbl m ON n.form_user_id=m.id where n.to_user_id='".$this->session->userdata('id')."' ORDER BY n.deadline_date DESC limit 2";
		
		$query = $this->db->query($sql);
		
		if($query->num_rows() > 0)
	    {
			//return $query->result();
			$val = $query->result();
			echo "<pre>";
			print_r($val);
			
		}
		else
	    {
	    	return false;
	    } 
	}
	public function opennotification($id)
    { 
		$sql = "SELECT n.*, m.first_name, m.last_name, m.designation FROM notification n INNER JOIN mst_users_tbl m ON n.form_user_id=m.id WHERE n.id='".$id."'";
		
		
		
		$query = $this->db->query($sql);
		
		if($query->num_rows() > 0)
	    {
			
			$sql2 = "UPDATE notification SET status='1' WHERE id='".$id."'";
		
			$query2 = $this->db->query($sql2);
			
			return $query->result();
		}
		else
	    {
	    	return false;
	    }    
    }
	function fetchnotificationall()
	{
		$sql = "SELECT n.*, m.first_name, m.last_name, m.designation FROM notification n INNER JOIN mst_users_tbl m ON n.form_user_id=m.id where n.to_user_id='".$this->session->userdata('id')."' ORDER BY n.deadline_date DESC";
		
		$query = $this->db->query($sql);
		
		if($query->num_rows() > 0)
	    {
			return $query->result();
			/*$val = $query->result();
			echo "<pre>";
			print_r($val);
			die;*/
		}
		else
	    {
	    	return false;
	    } 
	}
	public function get_count_notification()
    { 
		//$query = $this->db->query('select n.id from notification where n.to_user_id='.$this->session->userdata('id').' AND n.status=0');
		
		$sql = "SELECT id from notification WHERE to_user_id='".$this->session->userdata('id')."' AND status='0'";
		$query = $this->db->query($sql);
		if($query->num_rows() > 0)
        {
           return $query->num_rows();
        }
        else
        {
            return false;
        }         
    }	
	
}

?>