<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ListCandidatesExport extends CI_Controller {
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url');		
		$this->load->library('session');
		$this->load->model('ListCandidatesExportModel');
		$this->load->model('ListDesignationModel');
		$this->load->model('ListSourceModel');
		$this->load->library('pagination');
	}
	public function index()
	{
		$data['designation'] = $this->ListDesignationModel->getDesignationList();
		$data['source'] = $this->ListSourceModel->getSource();
		$this->load->view('layout/header');
		$this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('list_candidates_export',$data);
		$this->load->view('layout/footer');
	}

	public function getCandidateDataCount()
	{
		$data['fromdate']=$this->input->post('fromdate');
		$data['todate']=$this->input->post('todate');
		$data['gender']=$this->input->post('gender');
		$data['fromage']=$this->input->post('fromage');
		$data['toage']=$this->input->post('toage');
		$data['status']=$this->input->post('status');
		$data['designation']=$this->input->post('designation');
		$data['experience']=$this->input->post('experience');
		$data['source']=$this->input->post('source');
		$result = $this->ListCandidatesExportModel->getCandidateDataCount($data);
		/*print_r(count($result));
		echo "<pre>"; print_r($result); die;*/
		$data['count'] = count($result);
		if((!empty($_POST['reset'])) == 'reset')
		{
			unset($_POST);
			redirect('ListCandidatesExport');
		}
		if((!empty($_POST['download'])) == 'download')
		{
			$csv="User ID, First Name, Last Name, Middle Name, Father's/Husband's First Name, Father's/Husband's  Middle Name, Father's/Husband's Last Name, Experience, Source, Primary Email Address, Secondary Email Address, Primary Phone, Secondary Phone, Age, Gender, Date Of Birth, Current Address, Permanant Address, Aadhar No, Passport No, Passport Valid Date, Passport Issue Place, Designation, Net CTC, Gross CTC, Date Of Joining, Comments, Status, date\n";
            if($result)
            {
                foreach($result as $values)
                {
                    $csv.='"'.$values['id'].'","'.$values['first_name'].'","'.$values['last_name'].'","'.$values['middle_name'].'","'.$values['fh_first_name'].'","'.$values['fh_middle_name'].'","'.$values['fh_last_name'].'","'.$values['experience'].'","'.$values['source'].'","'.$values['primary_email_address'].'","'.$values['secondary_email_address'].'","'.$values['primary_phone'].'","'.$values['secondary_phone'].'","'.$values['age'].'","'.$values['gender'].'","'. $values['date_of_birth'].'","'.$values['current_address'].'","'.$values['permanant_address'].'","'.$values['aadhar_no'].'","'.$values['passport_no'].'","'.$values['passport_valid_date'].'","'. $values['passport_issue_place'].'","'.$values['designation'].'","'.$values['net_ctc'].'","'.$values['gross_ctc'].'","'.$values['date_of_join'].'","'.$values['comments'].'","'.$values['status'].'",'.$values['date']."\n";
                }
            }
            $handle = fopen("uploads/CandidatesData.csv", "w");
            if(fwrite($handle, $csv))
            {
                ob_clean(); 
                fclose($handle);
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename='.basename("uploads/CandidatesData.csv"));
                header('Expires: 0');
                header('Cache-Control: must-revalidate');
                header('Pragma: public');
                header('Content-Length: ' . filesize("uploads/CandidatesData.csv"));
                readfile("uploads/CandidatesData.csv");
                unlink("uploads/CandidatesData.csv");
                exit;
            }
		}
		$this->load->view('layout/header');
		$this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('list_candidates_export',$data);
		$this->load->view('layout/footer');
	}
	public function showCandidateDetails()
	{
		$data['data'] = $this->ListCandidatesExportModel->editCandidates($this->uri->segment(3));
		$this->load->view('layout/header');
		$this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('list_candidates_export',$data);
		$this->load->view('layout/footer');
	}
}
