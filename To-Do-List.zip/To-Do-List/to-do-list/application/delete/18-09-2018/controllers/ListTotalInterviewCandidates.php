<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ListTotalInterviewCandidates extends CI_Controller {
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url');		
		$this->load->library('session');
		$this->load->model('ListTotalInterviewCandidatesModel');
		$this->load->library('pagination');
	}
	public function index()
	{
		if(count($_POST) < 0)
		{
			redirect('ListTotalInterviewCandidates');
		}

		$searchby = $this->input->post('searchby');	
		$searchkeyword = $this->input->post('searchkeyword');
		
		$num_rows=$this->ListTotalInterviewCandidatesModel->get_candidates_count($searchby,$searchkeyword);
        $config['base_url'] = base_url().'/ListTotalInterviewCandidates/index/';
        $config['total_rows'] = $num_rows;
        $config['per_page'] = 5;
        $config['num_links'] = 3;
        $config['use_page_numbers'] = False;

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['prev_link'] = '&laquo;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["links"] = $this->pagination->create_links();
		$data['user'] = $this->ListTotalInterviewCandidatesModel->getCandidatesdData($config["per_page"], $page,$searchby,$searchkeyword);
		$this->load->view('layout/header');
		$this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('list_total_interview_candidates', $data);
		$this->load->view('layout/footer');
	}

	public function getCandidatesScheduleInterview()
	{
		if(count($_POST) < 0)
		{
			redirect('ListTotalInterviewCandidates/getCandidatesScheduleInterview');
		}

		$searchby = $this->input->post('searchby');	
		$searchkeyword = $this->input->post('searchkeyword');
		
		$num_rows=$this->ListTotalInterviewCandidatesModel->get_getCandidatesScheduleInterview_count($searchby,$searchkeyword,$this->uri->segment(3),$this->uri->segment(4));
        $config['base_url'] = base_url().'/ListTotalInterviewCandidates/getCandidatesScheduleInterview/'.$this->uri->segment(3).'/'.$this->uri->segment(4).'/index/';
        $config['total_rows'] = $num_rows;
        $config['per_page'] = 5;
        $config['num_links'] = 5;
        $config['use_page_numbers'] = False;

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['prev_link'] = '&laquo;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
        $data["links"] = $this->pagination->create_links();
		$data['user'] = $this->ListTotalInterviewCandidatesModel->getCandidatesScheduleInterview($config["per_page"], $page,$searchby,$searchkeyword,$this->uri->segment(3),$this->uri->segment(4));
		
		$this->load->view('layout/header');
		$this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('list_total_interview_candidates', $data);
		$this->load->view('layout/footer');
	}

	public function getFutureCandidatesScheduleInterview()
	{
		if(count($_POST) < 0)
		{
			redirect('ListTotalInterviewCandidates/getFutureCandidatesScheduleInterview');
		}

		$searchby = $this->input->post('searchby');	
		$searchkeyword = $this->input->post('searchkeyword');
		
		$num_rows=$this->ListTotalInterviewCandidatesModel->get_getFutureCandidatesScheduleInterview_count($searchby,$searchkeyword,$this->uri->segment(3),$this->uri->segment(4));
        $config['base_url'] = base_url().'/ListTotalInterviewCandidates/getFutureCandidatesScheduleInterview/'.$this->uri->segment(3).'/'.$this->uri->segment(4).'/index/';
        $config['total_rows'] = $num_rows;
        $config['per_page'] = 5;
        $config['num_links'] = 5;
        $config['use_page_numbers'] = False;

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['prev_link'] = '&laquo;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $page = ($this->uri->segment(5)) ? $this->uri->segment(5) : 0;
        $data["links"] = $this->pagination->create_links();
		$data['user'] = $this->ListTotalInterviewCandidatesModel->getFutureCandidatesScheduleInterview($config["per_page"], $page,$searchby,$searchkeyword,$this->uri->segment(3),$this->uri->segment(4));
		
		$this->load->view('layout/header');
		$this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('list_total_interview_candidates', $data);
		$this->load->view('layout/footer');
	}

	public function updateCandidateStatus()
	{
		$data['status']=$this->input->post('status');
		$result = $this->ListTotalInterviewCandidatesModel->updateCandidateStatus($data,$this->input->post('id'));
	}
	public function showCandidateDetails()
	{
		$data['data'] = $this->ListTotalInterviewCandidatesModel->editCandidates($this->uri->segment(4));
		$this->load->view('layout/header');
		$this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('candidates_details_process_one',$data);
		$this->load->view('layout/footer');
	}
}
