<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url');		
		$this->load->library('session');		
		$this->load->model('UserLoginModel');
	}
	public function index()
	{
		$this->load->view('layout/login_header');
		$this->load->view('login');
		$this->load->view('layout/login_footer');
	}
	public function login()
	{
		ob_start();
		if($this->input->post('login'))
		{			
			if($this->input->post('username') && $this->input->post('password'))
			{
				$username=$this->input->post('username');
				$password=$this->input->post('password');
				$result = $this->UserLoginModel->getLoginUsers($username,$password);
				
				if($result > 0)
				{
					//set the session variables
					$this->session->set_flashdata('msg', 'success');
					$this->session->set_userdata('username', $result['username']);
					$this->session->set_userdata('first_name', $result['first_name']);
					$this->session->set_userdata('last_name', $result['last_name']);
					$this->session->set_userdata('user_id', $result['id']);
					$this->session->set_userdata('user_role', $result['user_role']);
					$this->session->set_userdata('id', $result['id']);
					redirect("Dashboard");
				}
				else
				{
					$this->session->set_flashdata('msg', 'danger');
					$this->session->set_flashdata('error_msg', 'Invalid email and password!');
			 		redirect('Login');
				}
			}
			else
			{
				$this->session->set_flashdata('error_msg', 'Please enter username and password');
				print_r('Please enter username and password');
			 	redirect('Login');
			}
		}
	}
	public function logout()
	{
		$this->session->sess_destroy();
		redirect('Login');
	}
}
