
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Candidates <small>Basic information</small></h3>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">              
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <?php
                    // print_r($this->session->userdata('username'));
                    if($this->session->flashdata('error_msg'))
                    {
                    ?>
                      <div class="alert alert-<?php  echo $this->session->flashdata('msg');?> fade in">
                       <?php  echo $this->session->flashdata('error_msg');?>    
                      </div>
                    <?php
                    }
                  ?>
                  <div class="x_content">
                    <div id="datatable-buttons_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                      <div class="dt-buttons btn-group">
					  <form method="post" action="">
                        <label>
                          Search By: <select name="searchby" class="form-control input-sm" placeholder="" aria-controls="datatable-buttons">
						  <option value="first_name">first_name</option>
						  <option value="last_name">last_name</option>
						  <option value="designation">designation</option>
						  <option value="source">Source</option>
						  
						  <option value="primary_email_address">Email</option>
						  <select>
                        </label>&nbsp;&nbsp;&nbsp;&nbsp;
						<label>
                          Search keyword: <input type="text" name="searchkeyword" class="form-control input-sm" placeholder="" aria-controls="datatable-buttons">
                        </label>
						<label>
						<button type="submit" name="search" value="search" class="btn btn-success btn-xs"><i class="fa fa-search-minus"></i>Search</button>
						</label>
						</form>
                      </div>

                      <div class="dataTables_length" id="datatable-buttons_length">                        
                        <a class="btn btn-primary" type="submit" href="<?php echo base_url();?>AddCandidatesProcessOne">Add</a>
						
                        <!--<label>
                          Show 
                          <select name="datatable-buttons_length" aria-controls="datatable-buttons" class="form-control input-sm">
                            <option value="10">10</option>
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                          </select> entries
                        </label>-->
                      </div>

                      <!--<div id="datatable-buttons_filter" class="dataTables_filter">
                        <label>
                          Search:<input type="search" class="form-control input-sm" placeholder="" aria-controls="datatable-buttons">
                        </label>
                      </div>-->
						<br><br><br>
                      <table id="datatable-buttons" class="table table-striped table-bordered">
                        <thead>
                          <tr>
                            <th>Name</th>
                            <th>Email Address</th>
                            <th>Designation</th>
                            <th>Phone</th>
                            <th>Experience</th>
                            <th>Source</th>
                            <th>gender</th>
                            <th>Age</th>
                            <th>Address</th>
                            <th>Status</th>
                            <th></th>
                          </tr>
                        </thead>


                        <tbody>
                           <?php
                            if(!empty($user))
                            {
                              foreach ($user as $user_value) 
                              {
                          ?>
                          <tr>
                            <td><?php echo $user_value->first_name." ".$user_value->last_name; ?></td>
                            <td><?php echo $user_value->primary_email_address; ?></td>
                            <td><?php echo $user_value->designation; ?></td>
                            <td><?php echo $user_value->primary_phone; ?></td>
                            <td><?php if($user_value->experience == '1') { echo "Fresher"; } elseif($user_value->experience == '2') { echo "Experienced"; }; ?></td>
                            <td><?php echo $user_value->source; ?></td>
                            <td><?php echo $user_value->gender; ?></td>
                            <td><?php echo $user_value->age; ?></td>
                            <td><?php echo $user_value->current_address; ?></td>
                            <td>
                              <?php if($user_value->status == 0) { ?> 
                                <select class="statusselect" data-id="<?php echo $user_value->id; ?>" id="initiate">
                                  <option value="<?php echo $user_value->status; ?>" ><?php echo "Initiate"; ?></option>
                                  <option value="1">Inprocess</option>
                                  <option value="2">Hired</option>
                                  <option value="3">Rejected</option>
                                  <option value="4">On-Hold</option>
                                  <option value="5">On-Board</option>
                                  <option value="6">Not Joined</option>
                                </select>
                              <?php } ?>
                              <?php if($user_value->status == 1) { ?> 
                                <select class="statusselect" data-id="<?php echo $user_value->id; ?>" id="inprocess">
                                  <option value="<?php echo $user_value->status; ?>" ><?php echo "Inprocess"; ?></option>
                                  <option value="0">Initiate</option>
                                  <option value="2">Hired</option>
                                  <option value="3">Rejected</option>
                                  <option value="4">On-Hold</option>
                                  <option value="5">On-Board</option>
                                  <option value="6">Not Joined</option>
                                </select>
                              <?php } ?> 
                              <?php if($user_value->status == 2) { ?> 
                                <select class="statusselect" data-id="<?php echo $user_value->id; ?>" id="hired">
                                  <option value="<?php echo $user_value->status; ?>" ><?php echo "Hired"; ?></option>
                                  <option value="0">Initiate</option>
                                  <option value="1">Inprocess</option>
                                  <option value="3">Rejected</option>
                                  <option value="4">On-Hold</option>
                                  <option value="5">On-Board</option>
                                  <option value="6">Not Joined</option>
                                </select>
                              <?php } ?> 
                              <?php if($user_value->status == 3) { ?> 
                                <select class="statusselect" data-id="<?php echo $user_value->id; ?>" id="rejected">
                                  <option value="<?php echo $user_value->status; ?>" class="red"><?php echo "Rejected"; ?></option>
                                  <option value="0">Initiate</option>
                                  <option value="1">Inprocess</option>
                                  <option value="2">Hired</option>
                                  <option value="4">On-Hold</option>
                                  <option value="5">On-Board</option>
                                  <option value="6">Not Joined</option>
                                </select>
                              <?php } ?> 
                              <?php if($user_value->status == 4) { ?> 
                                <select class="statusselect" data-id="<?php echo $user_value->id; ?>" id="onhold">
                                  <option value="<?php echo $user_value->status; ?>" ><?php echo "On-Hold"; ?></option>
                                  <option value="0">Initiate</option>
                                  <option value="1">Inprocess</option>
                                  <option value="2">Hired</option>
                                  <option value="3">Rejected</option>
                                  <option value="5">On-Board</option>
                                  <option value="6">Not Joined</option>
                                </select>
                              <?php } ?> 
                              <?php if($user_value->status == 5) { ?> 
                                <select class="statusselect" data-id="<?php echo $user_value->id; ?>" id="join">
                                  <option value="<?php echo $user_value->status; ?>" ><?php echo "On-Board"; ?></option>
                                  <option value="0">Initiate</option>
                                  <option value="1">Inprocess</option>
                                  <option value="2">Hired</option>
                                  <option value="3">Rejected</option>
                                  <option value="4">On-Hold</option>
                                  <option value="6">Not Joined</option>
                                </select>
                              <?php } ?> 
                              <?php if($user_value->status == 6) { ?> 
                                <select class="statusselect" data-id="<?php echo $user_value->id; ?>" id="notjoin">
                                  <option value="<?php echo $user_value->status; ?>" ><?php echo "Not Joined"; ?></option>
                                  <option value="0">Initiate</option>
                                  <option value="1">Inprocess</option>
                                  <option value="2">Hired</option>
                                  <option value="3">Rejected</option>
                                  <option value="4">On-Hold</option>
                                  <option value="5">On-Board</option>
                                </select>
                              <?php } ?>
                            </td>
                            <td>
                              <a href="<?php echo base_url();?>ListCandidatesProcessOne/showCandidateDetails/<?php echo $user_value->id;?>" class="btn btn-primary btn-xs"><i class="fa fa-folder">View</i></a>
                              <a href="<?php echo base_url();?>AddCandidatesProcessOne/updateCandidates/<?php echo $user_value->id;?>" class="btn btn-info btn-xs"><i class="fa fa-pencil">Edit</i></a>
                            </td>
                          </tr>
                          <?php
                              }
                            }
                          ?>
                          <tr>
                            <td colspan="11"><?php echo $links; ?></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
        <!-- /page content -->