<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url');		
		$this->load->library('session');
    $this->load->model('DashboardModel');
		$this->load->model('DashboardNotificationModel');		
	}
	public function index()
	{
    $data['total'] = $this->DashboardModel->getCandidatesTotalCount();
    $data['hired'] = $this->DashboardModel->getCandidatesHireCount();
    $data['joined'] = $this->DashboardModel->getCandidatesJoinedCount();
    $data['notjoined'] = $this->DashboardModel->getCandidatesNotJoinedCount();
    $data['rejected'] = $this->DashboardModel->getCandidatesRejectedCount();
    $data['onhold'] = $this->DashboardModel->getCandidatesOnHoldCount();
    $data['initiate'] = $this->DashboardModel->getCandidatesInitiateCount();
    $data['inprocess'] = $this->DashboardModel->getCandidatesInProcessCount();
    $data['todaysinterview'] = $this->DashboardModel->getScheduleInterviewToday();
    $data['totalinterview'] = $this->DashboardModel->getScheduleInterviewTotal();
    $data['requirementrequest'] = $this->DashboardModel->getDesignationOpening();
	$data['chart']=$this->DashboardNotificationModel->showchartdata();
	$data['profile_requirement']=$this->DashboardNotificationModel->top_profile_requirements();
		$this->load->view('layout/header');
		$this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('dashboard',$data);
		$this->load->view('layout/footer');
	}
	
	function top_notification()
    {
        $data=$this->DashboardNotificationModel->fetchnotification();
        $count=$this->DashboardNotificationModel->get_count_notification();
      
        if($data)
        {

            ?>
			 <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-bell-o"></i>
                    <span class="badge bg-green"><?php echo $count; ?></span>
                  </a>
				   <ul id="menu1" class="dropdown-menu list-unstyled msg_list " role="menu">
            <?php
				  foreach($data as $row)
				  {
					  $id = $row->id;
				  ?>
                    <li>
                      <a href="<?php echo base_url();?>NotificationOne/index?var1=<?php echo $id; ?>">
                        
                        <span>
                          <span style="font-weight:bold"><?php echo $row->notification_type; ?></span>
                          <span class="time"><?php echo $row->deadline_date; ?></span>
                        </span>
                        <span class="message">
                          <?php echo $row->notification_msg; ?>.<br>
                        </span>
                      </a>
                    </li>
				  <?php } ?>
                   
                    <li>
                      <div class="text-center">
                        <a href="<?php echo base_url();?>NotificationOne">
                          <strong>See All Alerts</strong>
                          <i class="fa fa-angle-right"></i>
                        </a>
                      </div>
                    </li>
					 </ul>
           <?php
        }
		else
		{?>
			 <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-bell-o"></i>
                    <span class="badge bg-green"></span>
                  </a>
				  <ul id="menu1" class="dropdown-menu list-unstyled msg_list " role="menu">
				  <li>
                      <div class="text-center">
                        <a href="#">
                          <strong>No Notification Yet</strong>
                          <i class="fa fa-angle-right"></i>
                        </a>
                      </div>
                    </li>
					 </ul>
	<?php	}
    }
}
