<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class DashboardModel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	public function getCandidatesTotalCount()
	{
		$condition = $this->db->query("SELECT COUNT(*) AS total FROM `mst_users_tbl` WHERE user_role='0'");
	    if($condition->num_rows() > 0)
	    {
	    	return $condition->row();
	    }
	    else
	    {
	    	return false;
	    }   
	}	
	public function getCandidatesHireCount()
	{
		$condition = $this->db->query("SELECT COUNT(*) AS hired FROM `mst_users_tbl` WHERE user_role='0' AND status='2'");
	    if($condition->num_rows() > 0)
	    {
	    	return $condition->row();
	    }
	    else
	    {
	    	return false;
	    }   
	}
	public function getCandidatesJoinedCount()
	{
		$condition = $this->db->query("SELECT COUNT(*) AS joined FROM `mst_users_tbl` WHERE user_role='0' AND status='5'");
	    if($condition->num_rows() > 0)
	    {
	    	return $condition->row();
	    }
	    else
	    {
	    	return false;
	    }   
	}
	public function getCandidatesNotJoinedCount()
	{
		$condition = $this->db->query("SELECT COUNT(*) AS notjoined FROM `mst_users_tbl` WHERE user_role='0' AND status='6'");
	    if($condition->num_rows() > 0)
	    {
	    	return $condition->row();
	    }
	    else
	    {
	    	return false;
	    }   
	}
	public function getCandidatesRejectedCount()
	{
		$condition = $this->db->query("SELECT COUNT(*) AS rejected FROM `mst_users_tbl` WHERE user_role='0' AND status='3'");
	    if($condition->num_rows() > 0)
	    {
	    	return $condition->row();
	    }
	    else
	    {
	    	return false;
	    }   
	}	
	public function getCandidatesOnHoldCount()
	{
		$condition = $this->db->query("SELECT COUNT(*) AS onhold FROM `mst_users_tbl` WHERE user_role='0' AND status='4'");
	    if($condition->num_rows() > 0)
	    {
	    	return $condition->row();
	    }
	    else
	    {
	    	return false;
	    }   
	}
	public function getCandidatesInProcessCount()
	{
		$condition = $this->db->query("SELECT COUNT(*) AS inprocess FROM `mst_users_tbl` WHERE user_role='0' AND status='1'");
	    if($condition->num_rows() > 0)
	    {
	    	return $condition->row();
	    }
	    else
	    {
	    	return false;
	    }   
	}
	public function getCandidatesInitiateCount()
	{
		$condition = $this->db->query("SELECT COUNT(*) AS initiate FROM `mst_users_tbl` WHERE user_role='0' AND status='0'");
	    if($condition->num_rows() > 0)
	    {
	    	return $condition->row();
	    }
	    else
	    {
	    	return false;
	    }   
	}
	public function getScheduleInterviewToday()
	{
		$arr=[];
		$condition = $this->db->query("SELECT DISTINCT designation FROM `mst_users_tbl`");
		if($condition->num_rows() > 0)
		{
			foreach ($condition->result_array() as $value) 
	    	{
	    		$count = '';
	    		$condition1 = $this->db->query("SELECT id FROM `mst_users_tbl` WHERE designation='".$value['designation']."'");
	    		if($condition1->num_rows() > 0)
				{
					foreach ($condition1->result_array() as $value1) 
			    	{
			    		$condition2 = $this->db->query("SELECT user_id FROM `interview_schedule_tbl` WHERE user_id = '".$value1['id']."' AND interview_schedule_date= '".date('Y-m-d')."'");
			    		$mstResult = $condition2->result_array();
			    		$count += count($mstResult);			    		
			    	}
			    }
			    if($count > 0)
			    		{
			    			$arr[]=array(
				    			'designation'=>$value['designation'],
				    			'count'=>$count
				    		);
			    		}
	    	}
	    	return $arr;
		}
		else
	    {
	    	return false;
	    }
	}
	public function getScheduleInterviewTotal()
	{
		$arr=[];
		$condition = $this->db->query("SELECT DISTINCT designation FROM `mst_users_tbl`");
		if($condition->num_rows() > 0)
		{
			foreach ($condition->result_array() as $value) 
	    	{
	    		$count = '';
	    		$condition1 = $this->db->query("SELECT id FROM `mst_users_tbl` WHERE designation='".$value['designation']."'");
	    		if($condition1->num_rows() > 0)
				{
					foreach ($condition1->result_array() as $value1) 
			    	{
			    		$condition2 = $this->db->query("SELECT user_id FROM `interview_schedule_tbl` WHERE user_id = '".$value1['id']."' AND interview_schedule_date > '".date('Y-m-d')."'");
			    		$mstResult = $condition2->result_array();
			    		$count += count($mstResult);			    		
			    	}
			    }
			    if($count > 0)
			    		{
			    			$arr[]=array(
				    			'designation'=>$value['designation'],
				    			'count'=>$count
				    		);
			    		}
	    	}
	    	return $arr;
		}
		else
	    {
	    	return false;
	    }
	}
	public function getDesignationOpening()
	{
		$arr=[];
		$condition = $this->db->query("SELECT DISTINCT user_id FROM `designation_openings_tbl`");
		if($condition->num_rows() > 0)
		{
			foreach ($condition->result_array() as $value) 
	    	{
	    		//$count = '';
	    		$condition1 = $this->db->query("SELECT id, first_name, last_name FROM `mst_users_tbl` WHERE id='".$value['user_id']."'");
	    		if($condition1->num_rows() > 0)
				{
					foreach ($condition1->result_array() as $value1) 
			    	{
			    		$RequestQuery = $this->db->query("SELECT count(*) as RequestCount FROM `designation_openings_tbl` WHERE user_id = '".$value1['id']."'");
			    		$RequestCount = $RequestQuery->row();

			    		$pendingRequestQuery = $this->db->query("SELECT count(*) as pendingRequestCount FROM `designation_openings_tbl` WHERE approved_status='0' AND user_id = '".$value1['id']."'");
			    		$pendingRequestCount = $pendingRequestQuery->row();

			    		$approveRequestQuery = $this->db->query("SELECT count(*) as approveRequestCount FROM `designation_openings_tbl` WHERE approved_status='1' AND user_id = '".$value1['id']."'");
			    		$approveRequestCount = $approveRequestQuery->row();

			    		$notapproveRequestQuery = $this->db->query("SELECT count(*) as notapproveRequestCount FROM `designation_openings_tbl` WHERE approved_status='2' AND user_id = '".$value1['id']."'");
			    		$notapproveRequestCount = $notapproveRequestQuery->row();

			    		$pendingcloseRequestQuery = $this->db->query("SELECT count(*) as pendingcloseRequestCount FROM `designation_openings_tbl` WHERE opening_closed_status='0' AND user_id = '".$value1['id']."'");
			    		$pendingcloseRequestCount = $pendingcloseRequestQuery->row();

			    		$closedRequestQuery = $this->db->query("SELECT count(*) as closedRequestCount FROM `designation_openings_tbl` WHERE opening_closed_status='1' AND user_id = '".$value1['id']."'");
			    		$closedRequestCount = $closedRequestQuery->row();

			    		$notclosedRequestQuery = $this->db->query("SELECT count(*) as notclosedRequestCount FROM `designation_openings_tbl` WHERE opening_closed_status='2' AND user_id = '".$value1['id']."'");
			    		$notclosedRequestCount = $notclosedRequestQuery->row();

			    		if(!empty($value1['first_name']))
			    		{
			    			$arr[]=array(
				    			'first_name'=>$value1['first_name'],
				    			'last_name'=>$value1['last_name'],
				    			'RequestCount'=>$RequestCount,
				    			'pendingRequestCount'=>$pendingRequestCount,
				    			'approveRequestCount'=>$approveRequestCount,
				    			'notapproveRequestCount'=>$notapproveRequestCount,
				    			'pendingcloseRequestCount'=>$pendingcloseRequestCount,
				    			'closedRequestCount'=>$closedRequestCount,
				    			'notclosedRequestCount'=>$notclosedRequestCount
				    		);
			    		}	    		
			    	}
			    }
			    
	    	}
	    	return $arr;
		}
		else
	    {
	    	return false;
	    }
	}
}
?>
