<?php
	$path = base_url();
?>
				
<div class="right_col" role="main">
	<div class="page-title">
        <div class="title_left">
            <h3 style="font-weight:bold">Candidate Documents</h3>
		</div>
    </div>
	<div class="clearfix"></div>
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
            <div class="x_title">
                    <h2>Upload Documents </h2>
                    
                    <div class="clearfix"></div>
                  </div>  
            <div class="x_content">
                
				<div style="margin-right:43em">
				<?php
				if($this->session->flashdata('success_msg'))
              {
              ?>
                <div class="alert alert-<?php  echo $this->session->flashdata('msg3');?> fade in">
                 <?php  echo $this->session->flashdata('success_msg');?>    
                </div>
              <?php
              }
				?>
					</div>
					<?php
				  foreach($data1 as $row)
						  {?>
				<h4>Candidate Name: <?php echo $row->first_name; echo " "; echo $row->last_name; ?></h4>		  
                <h4>You can upload multiple document onclicking "Add" Button.</h4><br><br>
                
                <form class="form-inline" action="<?php echo base_url('UploadCandidateDocument/uploaddocument')?>" method="post" enctype="multipart/form-data">
				
                  <div class="form-group" style="">
				  
                    <input type="text" name="userid" style="display:none" value="<?php echo $row->id; ?>"  >
						  <?php } ?>
					<select id="ex3" class="form-control" name="doc_category[]" required="">
						<option value="">Select Category</option>
						<option value="Adhaar Card">Adhaar Card</option>
						<option value="Pan Card">Pan Card</option>
						<option value="Passport size photograph">Passport size photograph</option>
						<option value="SSC Marksheet">SSC Marksheet</option>
						<option value="HSC Marksheet">HSC Marksheet</option>
						<option value="Graduation Marksheet">Graduation Marksheet</option>
						<option value="Post Graduation Marksheet">Post Graduation Marksheet</option>
						<option value="Relieving Letter/ Experience Letter/ Resignation Letter">Relieving Letter/ Experience Letter/ Resignation Letter</option>
						<option value="Resume">Resume</option>
						<option value="Salary Slips">Salary Slips</option>
					</select>
                  </div>
				  
                  <div class="form-group" style="margin-left:36px">
                    
                    <input type="file" name="doc[]" id="ex4" class="form-control" placeholder=" ">
                  </div>
				  
				  
				  
					<div class="content">
					</div>
					
                  <br><br>
				  <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                    <button class="btn btn-primary" onclick="addelement();" id="addScnt" type="button">Add</button>
					<button name="upload" style="" type="submit" class="btn btn-success">Upload</button>
                  </div>
				  
                </form>
            </div>
        </div>
	</div>
	
	<div class="clearfix"></div>
	<?php
	 if(!empty($user))
      {?>
	<div class="col-md-12 col-sm-12 col-xs-12" style="margin-top:30px">
                <div class="x_panel">
                 <div class="x_title" style="border-bottom:none !important">
                    <h2> List of Uploaded Documents</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
					<div id="datatable-buttons_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                      
                      
                    <table id="datatable-buttons" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                          <th>No.</th>
                          <th>Document Category</th>
                          <th>Document</th>
                          <th>Uploaded Date</th>
                          
                        </tr>
                      </thead>


                      <tbody>
						<?php
							$i=1;
						  foreach($user as $row)
						  {
							echo "<tr>";
						  
							echo "<td>".$i."</td>";
							echo "<td>".$row->document_name."</td>";
							echo "<td><a target='_blank' href='".$path."uploads/documents/".$row->user_id."/".$row->document_path."'>".$row->document_path."</a></td>";
							
							echo "<td>".$row->document_uploading_date."</td>";
							
							
							echo "</tr>";
							$i++;
						  }
						?>
                        
                      </tbody>
                    </table>
					</div>
                  </div>
                </div>
              </div>
			  <?php
			  }?>
			  <div class="clearfix"></div>
	<!--<div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 <div class="x_title">
                    <h2>Pending Documents</small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
					<div id="datatable-buttons_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                      <div class="dt-buttons btn-group">
                        <a class="btn btn-default buttons-copy buttons-html5 btn-sm" tabindex="0" aria-controls="datatable-buttons" href="#">
                          <span>Copy</span></a><a class="btn btn-default buttons-csv buttons-html5 btn-sm" tabindex="0" aria-controls="datatable-buttons" href="#"><span>CSV</span></a><a class="btn btn-default buttons-print btn-sm" tabindex="0" aria-controls="datatable-buttons" href="#"><span>Print</span>
                        </a>
                      </div>

                      <div class="dataTables_length" id="datatable-buttons_length">
                        <label>
                          Show 
                          <select name="datatable-buttons_length" aria-controls="datatable-buttons" class="form-control input-sm">
                            <option value="10">10</option>
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                          </select> entries
                        </label>
                      </div>

                      <div id="datatable-buttons_filter" class="dataTables_filter">
                        <label>
                          Search:<input type="search" class="form-control input-sm" placeholder="" aria-controls="datatable-buttons">
                        </label>
                      </div>
                    <table id="datatable-buttons" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Designation</th>
                          <th>Phone</th>
                          <th>Age</th>
                          <th>Gender</th>
                          <th>DOB</th>
                          <th>Address</th>
                          <th>Status</th>
                          <th>Remarks</th>
						  
                          <th></th>
						  <th></th>
                          
                        </tr>
                      </thead>


                      <tbody>
						<tr><td><a href="http://localhost/recruitionary/CandidateProfile/profileview/2">testuser</a></td><td>testprimaryemail</td><td>developer</td><td>testprimaryphone</td><td>testage</td><td>male</td><td>1990-08-02</td><td>test permanent address</td><td>Hired</td><td>good to go</td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="UpdateData?id=2">Edit&nbsp;<i class="fa fa-pencil"></i></a></button></td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="http://localhost/recruitionary/UploadCandidateDocument/uploaddoc/2">Document&nbsp;<i class="fa fa-arrow-up"></i></a></button></td></tr><tr><td><a href="http://localhost/recruitionary/CandidateProfile/profileview/3">aghda</a></td><td>sdfsdf</td><td>gsgsggsssg</td><td>dsfsd</td><td>fsdf</td><td>fsdf</td><td>1990-08-02</td><td>sdfsdfs</td><td>Hired</td><td>gssgsgssg</td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="UpdateData?id=3">Edit&nbsp;<i class="fa fa-pencil"></i></a></button></td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="http://localhost/recruitionary/UploadCandidateDocument/uploaddoc/3">Document&nbsp;<i class="fa fa-arrow-up"></i></a></button></td></tr><tr><td><a href="http://localhost/recruitionary/CandidateProfile/profileview/4">aghda</a></td><td>sdfsdf</td><td>gsgsggsssg</td><td>dsfsd</td><td>fsdf</td><td>fsdf</td><td>1990-08-02</td><td>sdfsdfs</td><td>Hired</td><td>gssgsgssg</td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="UpdateData?id=4">Edit&nbsp;<i class="fa fa-pencil"></i></a></button></td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="http://localhost/recruitionary/UploadCandidateDocument/uploaddoc/4">Document&nbsp;<i class="fa fa-arrow-up"></i></a></button></td></tr><tr><td><a href="http://localhost/recruitionary/CandidateProfile/profileview/5">aghda</a></td><td>sdfsdf</td><td>gsgsggsssg</td><td>dsfsd</td><td>fsdf</td><td>fsdf</td><td>1990-08-02</td><td>sdfsdfs</td><td>Hired</td><td>gssgsgssg</td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="UpdateData?id=5">Edit&nbsp;<i class="fa fa-pencil"></i></a></button></td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="http://localhost/recruitionary/UploadCandidateDocument/uploaddoc/5">Document&nbsp;<i class="fa fa-arrow-up"></i></a></button></td></tr><tr><td><a href="http://localhost/recruitionary/CandidateProfile/profileview/6">aghda</a></td><td>sdfsdf</td><td>gsgsggsssg</td><td>dsfsd</td><td>fsdf</td><td>fsdf</td><td>1990-08-02</td><td>sdfsdfs</td><td>Hired</td><td>gssgsgssg</td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="UpdateData?id=6">Edit&nbsp;<i class="fa fa-pencil"></i></a></button></td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="http://localhost/recruitionary/UploadCandidateDocument/uploaddoc/6">Document&nbsp;<i class="fa fa-arrow-up"></i></a></button></td></tr><tr><td><a href="http://localhost/recruitionary/CandidateProfile/profileview/7">aghda</a></td><td>sdfsdf</td><td>gsgsggsssg</td><td>dsfsd</td><td>fsdf</td><td>fsdf</td><td>1990-08-02</td><td>sdfsdfs</td><td>Hired</td><td>gssgsgssg</td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="UpdateData?id=7">Edit&nbsp;<i class="fa fa-pencil"></i></a></button></td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="http://localhost/recruitionary/UploadCandidateDocument/uploaddoc/7">Document&nbsp;<i class="fa fa-arrow-up"></i></a></button></td></tr><tr><td><a href="http://localhost/recruitionary/CandidateProfile/profileview/8">aghda</a></td><td>sdfsdf</td><td>gsgsggsssg</td><td>dsfsd</td><td>fsdf</td><td>fsdf</td><td>1990-08-02</td><td>sdfsdfs</td><td>Hired</td><td>gssgsgssg</td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="UpdateData?id=8">Edit&nbsp;<i class="fa fa-pencil"></i></a></button></td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="http://localhost/recruitionary/UploadCandidateDocument/uploaddoc/8">Document&nbsp;<i class="fa fa-arrow-up"></i></a></button></td></tr><tr><td><a href="http://localhost/recruitionary/CandidateProfile/profileview/9">ffsgvs</a></td><td>gvsdgvs</td><td>dfhdh</td><td>14141</td><td>42</td><td>qrqwe</td><td>1990-08-02</td><td>faefgaeg</td><td>Hired</td><td>fsdhsdfh</td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="UpdateData?id=9">Edit&nbsp;<i class="fa fa-pencil"></i></a></button></td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="http://localhost/recruitionary/UploadCandidateDocument/uploaddoc/9">Document&nbsp;<i class="fa fa-arrow-up"></i></a></button></td></tr><tr><td><a href="http://localhost/recruitionary/CandidateProfile/profileview/10">ffsgvs</a></td><td>gvsdgvs</td><td>dfhdh</td><td>14141</td><td>42</td><td>qrqwe</td><td>1990-08-02</td><td>faefgaeg</td><td>Hired</td><td>fsdhsdfh</td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="UpdateData?id=10">Edit&nbsp;<i class="fa fa-pencil"></i></a></button></td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="http://localhost/recruitionary/UploadCandidateDocument/uploaddoc/10">Document&nbsp;<i class="fa fa-arrow-up"></i></a></button></td></tr><tr><td><a href="http://localhost/recruitionary/CandidateProfile/profileview/11">ffsgvs</a></td><td>gvsdgvs</td><td>dfhdh</td><td>14141</td><td>42</td><td>qrqwe</td><td>1990-08-02</td><td>faefgaeg</td><td>Hired</td><td>fsdhsdfh</td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="UpdateData?id=11">Edit&nbsp;<i class="fa fa-pencil"></i></a></button></td><td> <button type="button" class="btn btn-success btn-xs"><a style="color:#FFF" href="http://localhost/recruitionary/UploadCandidateDocument/uploaddoc/11">Document&nbsp;<i class="fa fa-arrow-up"></i></a></button></td></tr>                        <tr>
                            <td colspan="12"><ul class="pagination"><li class="active"><a href="#">1</a></li><li><a href="http://localhost/recruitionary/ListCandidateProcessTwo/index/2" data-ci-pagination-page="2">2</a></li><li><a href="http://localhost/recruitionary/ListCandidateProcessTwo/index/2" data-ci-pagination-page="2" rel="next">&gt;</a></li></ul></td>
                          </tr>
                      </tbody>
                    </table>
					</div>
                  </div>
                </div>
              </div>-->
</div>
<script>

var i = 0;
function addelement()
{
	
	var element ='<div style="margin-top:40px" class="form-group deleteelement_'+i+'"><select id="ex3" class="form-control" name="doc_category[]" required=""><option value="">Select Category</option><option value="adharcard">Adhaar Card</option><option value="pancard">Pan Card</option><option value="photo">Passport size photograph</option><option value="ssc">SSC Marksheet</option><option value="hsc">HSC Marksheet</option><option value="graduation">Graduation Marksheet</option><option value="postgraduation">Post Graduation Marksheet</option><option value="resignation">Relieving Letter/ Experience Letter/ Resignation Letter</option><option value="resume">Resume</option></select></div><div style="margin-top:40px;margin-left:40px" class="form-group deleteelement_'+i+'"><input type="file" name="doc[]" id="ex4" class="form-control" placeholder=" "><button style="margin-left:20px" type="button" class="btn btn-danger btn-xs"><a href="javascript:;" style="color:white" onclick="delete1('+i+')">Remove</a></button></div>';
	
	$(".content").append(element);
	i++;
}
function delete1(id)
{
	$('.deleteelement_'+id).remove();
}
</script>                     