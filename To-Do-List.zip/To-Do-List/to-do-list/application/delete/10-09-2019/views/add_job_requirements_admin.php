        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Add New Candidates</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    <form action="<?php echo base_url();?>AddJobRequirementsAdmin/addNewJobRequirements" method="post" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
                      <input type="hidden" name="id" value="<?php if(!empty($opening['id'])){echo $opening['id'];}else{}?>">
                      <input type="hidden" name="date" value="<?php echo date("Y-m-d H:i:s"); ?>">
                      <input type="hidden" name="user_id" value="<?php if(!empty($opening['user_id'])){echo $opening['user_id'];}else{}?>" class="form-control has-feedback-left" id="inputSuccess2">
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Requested Person Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" name="fullname" value="<?php if(!empty($opening['user_id'])){echo $opening['first_name']." ".$opening['last_name'];}else{}?>" class="form-control has-feedback-left" readonly="readonly">
                          <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Required Designation <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" name="designation" value="<?php if(!empty($opening['designation'])){echo $opening['designation'];}else{}?>" class="form-control has-feedback-left" readonly="readonly">
                        </div>
                      </div>                      
                      <div class="form-group">
                         <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          No. of Requirements
                        </label> 
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="number" name="no_requirements" value="<?php if(!empty($opening['no_requirements'])){echo $opening['no_requirements'];}else{}?>" class="form-control has-feedback-left" readonly="readonly">
                          <span class="fa fa-sort form-control-feedback right" aria-hidden="true"></span>
                        </div>
                      </div>
                      <div class="form-group">
                         <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Remarks
                        </label> 
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <textarea name="comments" class="form-control has-feedback-left" readonly="readonly"><?php if(!empty($opening['comments'])){echo $opening['comments'];}else{}?></textarea>
                        </div>
                      </div>
                       <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Deadline <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="input-group date" id="jobrequirementdeadline">
                                <input type="text" name="deadline" value="<?php if(!empty($opening['deadline'])){echo $opening['deadline'];}else{}?>" class="form-control">
                                <span class="input-group-addon">
                                   <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                      </div>
                      <div class="form-group">
                         <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Approved status
                        </label> 
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <select name="approved_status" class="form-control has-feedback-left">
                            <option value="<?php echo $opening['approved_status']; ?>"><?php if($opening['approved_status'] == '0') { echo "Pending"; } elseif($opening['approved_status'] == '1') { echo "Approved"; } elseif($opening['approved_status'] == '2') { echo "Not Approved"; } ?></option>
                            <option value="1">Approved</option>
                            <option value="2">Not Approved</option>
                          </select>
                        </div>
                      </div>
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <button class="btn btn-primary" type="reset">Reset</button>
                          <button type="submit" class="btn btn-success" name="add" value="add">Submit</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

