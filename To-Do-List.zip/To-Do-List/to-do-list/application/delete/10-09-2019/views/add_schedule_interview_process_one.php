

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
            <div class="row">
              <div class="clearfix"></div>

              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Interview Schedule </h2>
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">

                    <div class="table-responsive">
                      <div id="datatable-buttons_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                        <div class="dt-buttons btn-group">
                          <a class="btn btn-default buttons-copy buttons-html5 btn-sm" tabindex="0" aria-controls="datatable-buttons" href="#">
                            <span>Copy</span></a><a class="btn btn-default buttons-csv buttons-html5 btn-sm" tabindex="0" aria-controls="datatable-buttons" href="#"><span>CSV</span></a><a class="btn btn-default buttons-print btn-sm" tabindex="0" aria-controls="datatable-buttons" href="#"><span>Print</span>
                          </a>
                        </div>

                        <div class="dataTables_length" id="datatable-buttons_length">                        
                          <a class="btn btn-primary" type="submit" href="<?php echo base_url();?>ListScheduleInterviewProcessOne/addInterviewScheduleCandidates">Add</a>
                          <label>
                            Show 
                            <select name="datatable-buttons_length" aria-controls="datatable-buttons" class="form-control input-sm">
                              <option value="10">10</option>
                              <option value="25">25</option>
                              <option value="50">50</option>
                              <option value="100">100</option>
                            </select> entries
                          </label>
                        </div>

                        <div id="datatable-buttons_filter" class="dataTables_filter">
                          <label>
                            Search:<input type="search" class="form-control input-sm" placeholder="" aria-controls="datatable-buttons">
                          </label>
                        </div>
                      </div>
                      <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap dataTable no-footer dtr-inline">
                        <thead>
                          <tr role="row">
                            <!-- <th class="sorting">Name </th> -->
                            <th>Name </th>
                            <th>Email </th>
                            <th>Phone </th>
                            <th>Experience </th>
                            <th>Designation </th>
                            <th>Source </th>
                            <th>Interview Date </th>
                            <th class="column-title no-link last"><span class="nobr">Action</span>
                            </th>
                            <th class="bulk-actions" colspan="7">
                              <a class="antoo" style="color:#fff; font-weight:500;">Bulk Actions ( <span class="action-cnt"> </span> ) <i class="fa fa-chevron-down"></i></a>
                            </th>
                          </tr>
                        </thead>

                        <tbody>
                          <?php
                            if(!empty($user))
                            {
                              foreach ($user as $user_value) 
                              {
                          ?>
                          <tr role="row">
                            <td class=" "><?php echo $user_value['first_name']." ".$user_value['last_name']; ?></td>
                            <td class=" "><?php echo $user_value['primary_email_address']; ?></td>
                            <td class=" "><?php echo $user_value['primary_phone']; ?></td>
                            <td class=" "><?php if($user_value['experience'] == 1) { echo "Fresher"; } elseif($user_value['experience'] == 2) { echo "Experienced"; }  ?></td>
                            <td class=" "><?php echo $user_value['designation']; ?></td>
                            <td class=" "><?php echo $user_value['source']; ?></td>
                            <td class=" ">
                              <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap dataTable no-footer dtr-inline">
                                <tbody>
                                  <tr class="row">
                                    <?php foreach ($user_value['interview_date'] as $interview_date_value) 
                                    { //echo $interview_date_value['interview_schedule_date']; } ?>
                                    <td class="a-center "><?php echo $interview_date_value['interview_schedule_date']; ?></td>
                                    <?php } ?>
                                  </tr>
                                </tbody>
                              </table>
                            </td>
                            <td class=" last">
                              <!-- <a href="<?php echo base_url();?>AddCandidatesProcessOne/updateCandidates/<?php echo $user_value['user_id'];?>" class="btn btn-primary btn-xs"><i class="fa fa-folder">View</i></a> -->
                              <a href="<?php echo base_url();?>ListScheduleInterviewProcessOne/updateScheduleInterview/<?php echo $user_value['user_id'];?>" class="btn btn-info btn-xs"><i class="fa fa-pencil">Edit</i></a>
                            </td>
                          </tr>
                          <?php
                              }
                            }
                          ?>
                          <tr>
                            <td colspan="8"><?php echo $links; ?></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
              
            
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

