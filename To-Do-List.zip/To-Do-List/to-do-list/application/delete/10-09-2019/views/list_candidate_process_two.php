<?php
	$path = base_url();
?>
	
	<div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Candidate List:  <small>List of hired candidates.</small></h3>
              </div>
			<div class="row">

              
			<div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <?php
                    // print_r($this->session->userdata('username'));
                    if($this->session->flashdata('error_msg'))
                    {
                    ?>
                      <div class="alert alert-<?php  echo $this->session->flashdata('msg');?> fade in">
                       <?php  echo $this->session->flashdata('error_msg');?>    
                      </div>
                    <?php
                    }
                  ?>
                 
                  <div class="x_content">
                    
					<div id="datatable-buttons_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                      <div class="dt-buttons btn-group">
                        <a class="btn btn-default buttons-copy buttons-html5 btn-sm" tabindex="0" aria-controls="datatable-buttons" href="#">
                          <span>Copy</span></a><a class="btn btn-default buttons-csv buttons-html5 btn-sm" tabindex="0" aria-controls="datatable-buttons" href="#"><span>CSV</span></a><a class="btn btn-default buttons-print btn-sm" tabindex="0" aria-controls="datatable-buttons" href="#"><span>Print</span>
                        </a>
                      </div>

                      <div class="dataTables_length" id="datatable-buttons_length">
                        <label>
                          Show 
                          <select name="datatable-buttons_length" aria-controls="datatable-buttons" class="form-control input-sm">
                            <option value="10">10</option>
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                          </select> entries
                        </label>
                      </div>

                      <div id="datatable-buttons_filter" class="dataTables_filter">
                        <label>
                          Search:<input type="search" class="form-control input-sm" placeholder="" aria-controls="datatable-buttons">
                        </label>
                      </div>
                    <table id="datatable-buttons" class="table table-striped table-bordered">
                      <thead>
                        <tr>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Designation</th>
                          <th>Phone</th>
                          <th>Experience</th>
                          <th>Source</th>
                          <th>Gender</th>
                          <th>Age</th>
                          <th>Address</th>
                          <th>Status</th>					  
                          <th></th>                          
                        </tr>
                      </thead>


                      <tbody>
						<?php
	
						  foreach($user as $row)
						  {
							  
							$stat = $row->status;
							/*if($stat == 2)
								{
									$stat = "Hired";
								}*/
							echo "<tr>";
						  
							echo "<td><a href='".$path."CandidateProfile/profileview/".$row->id."'>".$row->first_name."</a></td>";
							echo "<td>".$row->primary_email_address."</td>";
							echo "<td>".$row->designation."</td>";
							echo "<td>".$row->primary_phone."</td>";
							echo "<td>"; if($row->experience == '1') { echo "Fresher"; } elseif($row->experience == '2') { echo "Experienced"; }; echo "</td>";
              echo "<td>".$row->source."</td>";
							echo "<td>".$row->gender."</td>";
							echo "<td>".$row->age."</td>";
							echo "<td>".$row->permanant_address."</td>";
							?>
              <td>
              <?php if($row->status == 2) { ?> 
                <select class="statusselect" data-id="<?php echo $row->id; ?>" id="hired">
                  <option value="<?php echo $row->status; ?>" ><?php echo "Hired"; ?></option>
                  <option value="5">On-Board</option>
                  <option value="6">Not Joined</option>
                </select>
              <?php } ?> 
              <?php if($row->status == 5) { ?> 
                <select class="statusselect" data-id="<?php echo $row->id; ?>" id="join">
                  <option value="<?php echo $row->status; ?>" ><?php echo "On-Board"; ?></option>
                  <option value="2">Hired</option>
                  <option value="6">Not Joined</option>
                </select>
              <?php } ?> 
              <?php if($row->status == 6) { ?> 
                <select class="statusselect" data-id="<?php echo $row->id; ?>" id="notjoin">
                  <option value="<?php echo $row->status; ?>" ><?php echo "Not Joined"; ?></option>
                  <option value="2">Hired</option>
                  <option value="5">On-Board</option>
                </select>
              <?php } ?>
              </td>

  							<td> 
                  <!-- <a href="<?php echo $path;?>UpdateCandidatesProcessTwo/updateCandidates/<?php echo $row->id;?>" class="btn btn-info btn-xs"><i class="fa fa-pencil">Edit</i></a> -->
                  <a href="<?php echo $path;?>UpdateCandidatesProcessTwo/updateCandidates/<?php echo $row->id;?>" class="btn btn-info btn-xs"><i class="fa fa-pencil">Edit</i></a>
                  <a href='<?php echo $path ?>UploadCandidateDocument/uploaddoc/<?php echo $row->id; ?>' class="btn btn-success btn-xs"><i class='fa fa-arrow-up'>Upload</i></a>
                </td>
  						<?php
  							echo "</tr>";
  							
  						  }
  						?>
                        <tr>
                            <td colspan="12"><?php echo $links; ?></td>
                          </tr>
                      </tbody>
                    </table>
					</div>
                  </div>
                </div>
              </div>
			  </div>
			</div>
			</div>
			</div>