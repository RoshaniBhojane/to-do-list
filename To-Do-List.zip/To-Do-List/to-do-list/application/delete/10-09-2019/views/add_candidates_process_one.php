        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Add New Candidates</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    <form action="<?php echo base_url();?>AddCandidatesProcessOne/addNewCandidates" method="post" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
                      <input type="hidden" name="id" value="<?php if(!empty($data['id'])){echo $data['id'];}else{}?>">
                      <input type="hidden" name="date" value="<?php echo date("Y-m-d H:i:s"); ?>">
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          First Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" name="first_name" value="<?php if(!empty($data['first_name'])){echo $data['first_name'];}else{}?>" class="form-control has-feedback-left" id="inputSuccess2" placeholder="First Name">
                          <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Last Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" name="last_name" value="<?php if(!empty($data['last_name'])){echo $data['last_name'];}else{}?>" class="form-control has-feedback-left" id="inputSuccess2" placeholder="Last Name">
                          <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>                      
                      <!--<div class="form-group">
                         <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Middle Name
                        </label> 
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" name="middle_name" value="<?php if(!empty($data['middle_name'])){echo $data['middle_name'];}else{}?>" class="form-control has-feedback-left" id="inputSuccess2" placeholder="Middle Name">
                          <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>-->
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Experience <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <select class="form-control" name="experience">
                              <?php if(!empty($data['experience'])){ ?>                               
                              <option value="<?php echo $data['experience']; ?>"  selected="selected">
                                <?php if($data['experience'] == 1) { echo "Fresher"; } elseif($data['experience'] == 2) { echo "Experienced"; }?>
                              </option>
                              <?php }?>
                              <option>Select</option>
                              <option value="1"><?php echo "Fresher"; ?></option>
                              <option value="2"><?php echo "Experienced"; ?></option>
                          </select>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Source <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <select class="form-control" name="source">
                            <?php if(!empty($data['source'])){ ?> 
                              <option value="<?php echo $data['source']; ?>" selected="selected" ><?php echo $data['source'];?></option>
                            <?php }?>
                              <option>Select</option>
                             <?php
                                if(!empty($source))
                                {
                                  foreach ($source as $source_value) 
                                  {
                              ?>                              
                                    <option value="<?php echo $source_value->source; ?>"><?php echo $source_value->source; ?></option>
                              <?php
                                  }
                                }
                              ?>
                          </select>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Designation <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <select class="form-control" name="designation">
                            <?php if(!empty($data['designation'])){ ?> 
                              <option value="<?php echo $data['designation']; ?>" selected="selected" ><?php echo $data['designation'];?></option>
                            <?php }?>
                              <option>Select</option>
                             <?php
                                if(!empty($user))
                                {
                                  foreach ($user as $user_value) 
                                  {
                              ?>                              
                                    <option value="<?php echo $user_value->designation; ?>"><?php echo $user_value->designation; ?></option>
                              <?php
                                  }
                                }
                              ?>
                          </select>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Primary Email <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="email" name="primary_email_address" value="<?php if(!empty($data['primary_email_address'])){echo $data['primary_email_address'];}else{}?>" class="form-control has-feedback-left" id="inputSuccess4" placeholder="Primary Email">
                          <span class="fa fa-envelope form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Secondary Email
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="email" name="secondary_email_address" value="<?php if(!empty($data['secondary_email_address'])){echo $data['secondary_email_address'];}else{}?>" class="form-control has-feedback-left" id="inputSuccess4" placeholder="Secondary Email">
                          <span class="fa fa-envelope form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Phone Number1 <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" name="primary_phone" value="<?php if(!empty($data['primary_phone'])){echo $data['primary_phone'];}else{}?>" class="form-control" id="inputSuccess5" placeholder="Phone Number1">
                          <span class="fa fa-phone form-control-feedback right" aria-hidden="true"></span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Phone Number2
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" name="secondary_phone" value="<?php if(!empty($data['secondary_phone'])){echo $data['secondary_phone'];}else{}?>" class="form-control" id="inputSuccess5" placeholder="Phone Number2">
                          <span class="fa fa-phone form-control-feedback right" aria-hidden="true"></span>
                        </div>
                      </div>                      
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Date Of Birth <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="input-group date" id="myDatepicker1">
                                <input type="text" name="date_of_birth" value="<?php if(!empty($data['date_of_birth'])){echo $data['date_of_birth'];}else{}?>" class="form-control">
                                <span class="input-group-addon">
                                   <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                      </div>
                      <!-- <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Age
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="birthday" class="date-picker form-control col-md-7 col-xs-12" type="text" name="age" value="<?php if(!empty($data['age'])){echo $data['age'];}else{}?>">
                        </div>
                      </div> -->
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Gender  <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <div id="gender" class="btn-group" data-toggle="buttons">
                            <div <?php if((!empty($data['gender'])) && ($data['gender'] == 'male')){ ?> class="btn btn-default active" <?php } else { ?> class="btn btn-default" <?php } ?>>
                              <input type="radio" name="gender" value="male" <?php if((!empty($data['gender'])) && ($data['gender'] == 'male')){ ?> checked="checked"<?php } ?>> &nbsp; Male &nbsp;
                            </div>
                            <div <?php if((!empty($data['gender'])) && ($data['gender'] == 'female')){ ?> class="btn btn-default active" <?php } else { ?> class="btn btn-default" <?php } ?>>
                              <input type="radio" name="gender" value="female" <?php if((!empty($data['gender'])) && ($data['gender'] == 'female')){ ?>checked="checked"<?php } ?>> Female
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Current Address 
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <textarea id="message" class="form-control" name="current_address"><?php if(!empty($data['current_address'])){echo $data['current_address'];}else{}?></textarea>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Permanent Address
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <textarea id="message" class="form-control" name="permanant_address"><?php if(!empty($data['permanant_address'])){echo $data['permanant_address'];}else{}?></textarea>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Remarks 
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <textarea id="message" class="form-control" name="comments"><?php if(!empty($data['comments'])){echo $data['comments'];}else{}?></textarea>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Status <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <select class="form-control" name="status">
                            <option <?php if((!empty($data['status'])) && ($data['status'] == 0)) { ?> value="<?php echo $data['status']; ?>"  selected="selected" <?php } else { ?> value="0" <?php } ?> >
                              Initiate
                            </option>
                            <option <?php if((!empty($data['status'])) && ($data['status'] == 1)) { ?> value="<?php echo $data['status']; ?>"  selected="selected" <?php } else { ?> value="1" <?php } ?> >
                              Inprocess
                            </option>
                            <option <?php if((!empty($data['status'])) && ($data['status'] == 2)) { ?> value="<?php echo $data['status']; ?>"  selected="selected" <?php } else { ?> value="2" <?php } ?> >
                              Hired
                            </option>
                            <option <?php if((!empty($data['status'])) && ($data['status'] == 3)) { ?> value="<?php echo $data['status']; ?>"  selected="selected" <?php } else { ?> value="3" <?php } ?> >
                              Rejected
                            </option>
                            <option <?php if((!empty($data['status'])) && ($data['status'] == 4)) { ?> value="<?php echo $data['status']; ?>"  selected="selected" <?php } else { ?> value="4" <?php } ?> >
                              On-Hold
                            </option>
                            <option <?php if((!empty($data['status'])) && ($data['status'] == 5)) { ?> value="<?php echo $data['status']; ?>"  selected="selected" <?php } else { ?> value="5" <?php } ?> >
                              On-Board
                            </option>
                            <option <?php if((!empty($data['status'])) && ($data['status'] == 6)) { ?> value="<?php echo $data['status']; ?>"  selected="selected" <?php } else { ?> value="6" <?php } ?> >
                              Not Joined
                            </option>
                          </select>
                        </div>
                      </div>
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <button class="btn btn-primary" type="reset">Reset</button>
                          <button type="submit" class="btn btn-success" name="add" value="add">Submit</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

