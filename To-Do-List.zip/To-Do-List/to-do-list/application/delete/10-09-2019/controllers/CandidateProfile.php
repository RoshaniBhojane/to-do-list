<?php
class CandidateProfile extends CI_Controller 
{
	public function __construct()
	{
	
	parent::__construct();
	
	$this->load->database();
	
	$this->load->helper('url');
	
	$this->load->model('CandidateProfileModel');
	$this->load->library('session');
	$this->load->library('pagination');
	}
		public function index()
		{
			
		}
		public function profileview()
		{
		
			$id = $this->uri->segment(3);
			$result['data'] = $this->CandidateProfileModel->displayprofile($id);
			
			$this->load->view('layout/header');
			$this->load->view('layout/menu_side_bar');
			$this->load->view('layout/menu_top_bar');
			
			$this->load->view('candidate_profile' , $result);
			
			$this->load->view('layout/footer');
			
		}
	
		
		
		
	}

?>