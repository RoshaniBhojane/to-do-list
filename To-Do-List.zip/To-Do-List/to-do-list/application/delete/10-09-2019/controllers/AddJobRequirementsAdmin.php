<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AddJobRequirementsAdmin extends CI_Controller {
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url');		
		$this->load->library('session');
		$this->load->model('AddJobRequirementsAdminModels');
		$this->load->model('ListJobRequirementsAdminModel');
		$this->load->model('ListDesignationModel');
	}
	public function index()
	{
		$data['designation'] = $this->ListDesignationModel->getDesignationList();
		$this->load->view('layout/header');
		$this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('add_job_requirements_admin', $data);
		$this->load->view('layout/footer');
	}
	public function addNewJobRequirements()
	{
		if($this->input->post('id'))
		{
			//get form's data and store in local varable
			$data['deadline']=$this->input->post('deadline');
			$data['approved_status']=$this->input->post('approved_status');
			$data['date']=$this->input->post('date');
			/*echo "<pre>";
			print_r($data);
			die;*/
			$result = $this->AddJobRequirementsAdminModels->updateCandidates($data,$this->input->post('id'));
			if($result)
			{
				$this->session->set_flashdata('msg', 'success');				
				$this->session->set_flashdata('error_msg', 'Record Sucessfuly added!');
				redirect('ListJobRequirementsAdmin');
			}
			else
			{
				$this->session->set_flashdata('msg', 'danger');
				$this->session->set_flashdata('error_msg', 'Data not updated!');
				redirect('ListJobRequirementsAdmin');
			}
		}
		else
		{
			/*//get form's data and store in local varable
			$data['user_id']=$this->input->post('user_id');
			$data['designation']=$this->input->post('designation');
			$data['designation']=$this->input->post('designation');
			$data['no_requirements']=$this->input->post('no_requirements');
			$data['comments']=$this->input->post('comments');
			$data['deadline']=$this->input->post('deadline');
			$data['no_fullfil_requirements']=$this->input->post('no_fullfil_requirements');
			$data['approved_status']=$this->input->post('approved_status');
			$data['opening_closed_status']=$this->input->post('opening_closed_status');
			$data['date']=$this->input->post('date');
			$result = $this->AddJobRequirementsAdminModels->addNewCandidates($data);
			if($result)
			{
				$this->session->set_flashdata('msg', 'success');				
				$this->session->set_flashdata('error_msg', 'Record Sucessfuly added!');
				redirect('ListCandidatesProcessOne');
			}
			else
			{
				$this->session->set_flashdata('msg', 'danger');
				$this->session->set_flashdata('error_msg', 'Data not updated!');
				redirect('ListCandidatesProcessOne');
			}*/
		}
	}
	public function updateJobRequirements()
	{
		$data['opening'] = $this->ListJobRequirementsAdminModel->editJobRequirements($this->uri->segment(3));
		$data['designation'] = $this->ListDesignationModel->getDesignationList();
		/*echo "<pre>";
		print_r($data);
		die;*/
		/*$data['user'] = $this->ListDesignationModel->getDesignationList();
		$data['source'] = $this->ListSourceModel->getSource();*/
	    $this->load->view('layout/header'); 
	    $this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('add_job_requirements_admin', $data);
        $this->load->view('layout/footer');
	}
}
