<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AddJobRequirementsManager extends CI_Controller {
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url');		
		$this->load->library('session');
		$this->load->model('AddJobRequirementsManagerModels');
		$this->load->model('ListJobRequirementsManagerModel');
		$this->load->model('ListDesignationModel');
	}
	public function index()
	{
		$data['designation'] = $this->ListDesignationModel->getDesignationList();
		$this->load->view('layout/header');
		$this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('add_job_requirements_Manager', $data);
		$this->load->view('layout/footer');
	}
	public function addNewJobRequirements()
	{
		if($this->input->post('id'))
		{
			//get form's data and store in local varable
			$data['date']=$this->input->post('date');
			$data['user_id']=$this->input->post('user_id');
			$data['designation']=$this->input->post('designation');
			$data['no_requirements']=$this->input->post('no_requirements');
			$data['comments']=$this->input->post('comments');
			$result = $this->AddJobRequirementsManagerModels->updateCandidates($data,$this->input->post('id'));
			if($result)
			{
				$this->session->set_flashdata('msg', 'success');				
				$this->session->set_flashdata('error_msg', 'Record Sucessfuly added!');
				redirect('ListJobRequirementsManager');
			}
			else
			{
				$this->session->set_flashdata('msg', 'danger');
				$this->session->set_flashdata('error_msg', 'Data not updated!');
				redirect('ListJobRequirementsManager');
			}
		}
		else
		{
			//get form's data and store in local varable
			$data['date']=$this->input->post('date');
			$data['user_id']=$this->input->post('user_id');
			$data['designation']=$this->input->post('designation');
			$data['no_requirements']=$this->input->post('no_requirements');
			$data['comments']=$this->input->post('comments');
			$result = $this->AddJobRequirementsManagerModels->addNewJobRequirements($data);
			if($result)
			{
				$this->session->set_flashdata('msg', 'success');				
				$this->session->set_flashdata('error_msg', 'Record Sucessfuly added!');
				redirect('ListJobRequirementsManager');
			}
			else
			{
				$this->session->set_flashdata('msg', 'danger');
				$this->session->set_flashdata('error_msg', 'Data not updated!');
				redirect('ListJobRequirementsManager');
			}
		}
	}
	public function updateJobRequirements()
	{
		$data['opening'] = $this->ListJobRequirementsManagerModel->editJobRequirements($this->uri->segment(3));
		$data['designation'] = $this->ListDesignationModel->getDesignationList();
	    $this->load->view('layout/header'); 
	    $this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('add_job_requirements_Manager', $data);
        $this->load->view('layout/footer');
	}
}
