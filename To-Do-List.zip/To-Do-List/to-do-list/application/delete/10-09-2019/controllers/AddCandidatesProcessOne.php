<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AddCandidatesProcessOne extends CI_Controller {
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url');		
		$this->load->library('session');
		$this->load->model('AddCandidatesProcessOneModel');
		$this->load->model('ListCandidatesProcessOneModel');
		$this->load->model('ListDesignationModel');
		$this->load->model('ListSourceModel');
	}
	public function index()
	{
		$data['user'] = $this->ListDesignationModel->getDesignationList();
		$data['source'] = $this->ListSourceModel->getSource();
		$this->load->view('layout/header');
		$this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('add_candidates_process_one', $data);
		$this->load->view('layout/footer');
	}
	public function addNewCandidates()
	{
		if($this->input->post('first_name'))
		{
			if($this->input->post('id'))
			{
				$dateOfBirth = $this->input->post('date_of_birth');
				$today = date("Y-m-d");
				$age = date_diff(date_create($dateOfBirth), date_create($today));
				//get form's data and store in local varable
				$data['first_name']=$this->input->post('first_name');
				$data['last_name']=$this->input->post('last_name');
				//$data['middle_name']=$this->input->post('middle_name');
				$data['designation']=$this->input->post('designation');
				$data['primary_email_address']=$this->input->post('primary_email_address');
				$data['secondary_email_address']=$this->input->post('secondary_email_address');
				$data['primary_phone']=$this->input->post('primary_phone');
				$data['secondary_phone']=$this->input->post('secondary_phone');
				$data['date_of_birth']=$this->input->post('date_of_birth');
				$data['age']=$age->format('%y');
				$data['gender']=$this->input->post('gender');
				$data['current_address']=$this->input->post('current_address');
				$data['permanant_address']=$this->input->post('permanant_address');
				$data['experience']=$this->input->post('experience');
				$data['date']=$this->input->post('date');
				$data['comments']=$this->input->post('comments');
				$data['source']=$this->input->post('source');
				$data['status']=$this->input->post('status');
				$data['user_role']='0';
				$result = $this->AddCandidatesProcessOneModel->updateCandidates($data,$this->input->post('id'));
				if($result)
				{
					$this->session->set_flashdata('msg', 'success');				
					$this->session->set_flashdata('error_msg', 'Record Sucessfuly added!');
					redirect('ListCandidatesProcessOne');
				}
				else
				{
					$this->session->set_flashdata('msg', 'danger');
					$this->session->set_flashdata('error_msg', 'Data not updated!');
					redirect('ListCandidatesProcessOne');
				}
			}
			else
			{
				$dateOfBirth = $this->input->post('date_of_birth');
				$today = date("Y-m-d");
				$age = date_diff(date_create($dateOfBirth), date_create($today));
				//get form's data and store in local varable
				$data['first_name']=$this->input->post('first_name');
				$data['last_name']=$this->input->post('last_name');
				//$data['middle_name']=$this->input->post('middle_name');
				$data['designation']=$this->input->post('designation');
				$data['primary_email_address']=$this->input->post('primary_email_address');
				$data['secondary_email_address']=$this->input->post('secondary_email_address');
				$data['primary_phone']=$this->input->post('primary_phone');
				$data['secondary_phone']=$this->input->post('secondary_phone');
				$data['date_of_birth']=$this->input->post('date_of_birth');
				$data['age']=$age->format('%y');
				$data['gender']=$this->input->post('gender');
				$data['current_address']=$this->input->post('current_address');
				$data['permanant_address']=$this->input->post('permanant_address');
				$data['experience']=$this->input->post('experience');
				$data['date']=$this->input->post('date');
				$data['comments']=$this->input->post('comments');
				$data['source']=$this->input->post('source');
				$data['status']='0';
				$data['user_role']='0';
				$result = $this->AddCandidatesProcessOneModel->addNewCandidates($data);
				if($result)
				{
					$this->session->set_flashdata('msg', 'success');				
					$this->session->set_flashdata('error_msg', 'Record Sucessfuly added!');
					redirect('ListCandidatesProcessOne');
				}
				else
				{
					$this->session->set_flashdata('msg', 'danger');
					$this->session->set_flashdata('error_msg', 'Data not updated!');
					redirect('ListCandidatesProcessOne');
				}
			}
		}
	}
	public function updateCandidates()
	{
		$data['data'] = $this->ListCandidatesProcessOneModel->editCandidates($this->uri->segment(3));
		$data['user'] = $this->ListDesignationModel->getDesignationList();
		$data['source'] = $this->ListSourceModel->getSource();
	    $this->load->view('layout/header'); 
	    $this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('add_candidates_process_one', $data);
        $this->load->view('layout/footer');
	}
}
