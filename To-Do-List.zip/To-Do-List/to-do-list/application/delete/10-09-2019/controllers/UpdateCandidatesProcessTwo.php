<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class UpdateCandidatesProcessTwo extends CI_Controller {
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url');		
		$this->load->library('session');
		$this->load->model('UpdateCandidatesProcessTwoModel');
		$this->load->model('ListCandidatesProcessOneModel');
		$this->load->model('ListDesignationModel');
		$this->load->model('ListEducationModel');
		$this->load->model('ListSourceModel');
	}
	public function index()
	{
		
	}
	public function updateCandidates()
	{
		$data['data'] = $this->ListCandidatesProcessOneModel->editCandidates($this->uri->segment(3));
		$data['user'] = $this->ListDesignationModel->getDesignationList();
		$data['education'] = $this->ListEducationModel->getEducationList();
		$data['source'] = $this->ListSourceModel->getSource();
		$data['candidate_education'] = $this->UpdateCandidatesProcessTwoModel->getCandidateEducation($this->uri->segment(3));
	    $this->load->view('layout/header'); 
	    $this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('update_candidates_process_two',$data);
        $this->load->view('layout/footer');

		if($this->input->post('id'))
		{
			$dateOfBirth = $this->input->post('date_of_birth');
			$today = date("Y-m-d");
			$age = date_diff(date_create($dateOfBirth), date_create($today));
			$user['id']=$this->input->post('id');
			$user['date']=$this->input->post('date');
			$user['first_name']=$this->input->post('first_name');
			$user['last_name']=$this->input->post('last_name');
			$user['middle_name']=$this->input->post('middle_name');
			$user['fh_first_name']=$this->input->post('fh_first_name');
			$user['fh_middle_name']=$this->input->post('fh_middle_name');
			$user['fh_last_name']=$this->input->post('fh_last_name');
			$user['primary_email_address']=$this->input->post('primary_email_address');
			$user['secondary_email_address']=$this->input->post('secondary_email_address');
			$user['primary_phone']=$this->input->post('primary_phone');
			$user['secondary_phone']=$this->input->post('secondary_phone');
			$user['age']=$age->format('%y');
			$user['gender']=$this->input->post('gender');
			$user['date_of_birth']=$this->input->post('date_of_birth');
			$user['current_address']=$this->input->post('current_address');
			$user['permanant_address']=$this->input->post('permanant_address');
			$user['aadhar_no']=$this->input->post('aadhar_no');
			$user['passport_no']=$this->input->post('passport_no');
			$user['passport_valid_date']=$this->input->post('passport_valid_date');
			$user['passport_issue_place']=$this->input->post('passport_issue_place');
			$user['designation']=$this->input->post('designation');
			$user['net_ctc']=$this->input->post('net_ctc');
			$user['gross_ctc']=$this->input->post('gross_ctc');
			$user['date_of_join']=$this->input->post('date_of_join');
			$user['experience']=$this->input->post('experience');
			$user['comments']=$this->input->post('comments');
			$user['source']=$this->input->post('source');
			$user['status']=$this->input->post('status');
			$user['user_role']='0';
			
			$result = $this->UpdateCandidatesProcessTwoModel->addEducationCandidateData($_POST['edu'],$this->input->post('id'));
			$result = $this->UpdateCandidatesProcessTwoModel->updateCandidateData($user,$this->input->post('id'));
			if($result)
			{
				$this->session->set_flashdata('msg', 'success');				
				$this->session->set_flashdata('error_msg', 'Record Sucessfuly added!');
				redirect('ListCandidateProcessTwo');
			}
			else
			{
				$this->session->set_flashdata('msg', 'danger');
				$this->session->set_flashdata('error_msg', 'Data not updated!');
				redirect('ListCandidateProcessTwo');
			}
		}
	}
}
