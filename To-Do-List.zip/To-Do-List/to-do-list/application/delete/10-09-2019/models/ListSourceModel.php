<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class ListSourceModel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	public function getSource()
	{
		$condition = $this->db->query("SELECT `source` FROM `source_tbl`");
	    if($condition->num_rows() > 0)
	    {
	    	return $condition->result();
	    }
	    else
	    {
	    	return false;
	    }   
	}	
}
?>
