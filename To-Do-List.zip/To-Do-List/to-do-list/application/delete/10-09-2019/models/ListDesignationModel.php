<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class ListDesignationModel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	public function getDesignationList()
	{
		$condition = $this->db->query("SELECT `designation` FROM `mst_designation_tbl`");
	    if($condition->num_rows() > 0)
	    {
	    	return $condition->result();
	    }
	    else
	    {
	    	return false;
	    }   
	}	
}
?>
