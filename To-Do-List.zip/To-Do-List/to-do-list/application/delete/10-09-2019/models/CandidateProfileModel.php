<?php

class CandidateProfileModel extends CI_Model

{
	
	function displayprofile($id)
	{
		
		$sql = "SELECT * FROM mst_users_tbl WHERE id='".$id."'";
		$query = $this->db->query($sql);
		return $query->result();
	}


}

?>