<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class AddCandidatesProcessOneModel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	public function addNewCandidates($data)
	{
		$result=$this->db->insert('mst_users_tbl', $data);
		if($result)
		{
			return true;
		}
	}
	public function updateCandidates($data,$id)
	{
		$this->db->where('id',$id);
        return $this->db->update('mst_users_tbl',$data);   
	}
}
?>
