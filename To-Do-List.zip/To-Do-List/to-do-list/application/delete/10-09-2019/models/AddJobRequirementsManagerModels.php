<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class AddJobRequirementsManagerModels extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	public function addNewJobRequirements($data)
	{
		$result=$this->db->insert('designation_openings_tbl', $data);
		if($result)
		{
			return true;
		}
	}
	public function updateCandidates($data,$id)
	{
		$this->db->where('id',$id);
        return $this->db->update('designation_openings_tbl',$data);   
	}
}
?>
