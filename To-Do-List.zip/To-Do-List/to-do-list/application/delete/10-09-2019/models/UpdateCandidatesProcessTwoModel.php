<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class UpdateCandidatesProcessTwoModel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	public function updateCandidateData($data,$id)
	{
		$this->db->where('id',$id);
        return $this->db->update('mst_users_tbl',$data);   
	}
	
	public function getCandidateEducation($id)
	{
    	$this->db->where('user_id',$id);
        $query = $this->db->get('education_tbl');
		if($query->num_rows() > 0)
        {
           return $query->result();
        }
		else
		{
            return false;
        }   
	}

	public function addEducationCandidateData($array,$user_id){
		$this->db->where('user_id',$user_id);
	    $this->db->delete('education_tbl');
		foreach ($array as $arrayvalue) 
		{
	        	$this->db->insert('education_tbl',$arrayvalue);
		}
	}

}
?>
