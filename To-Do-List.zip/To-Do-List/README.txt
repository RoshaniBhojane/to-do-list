1] Copy 'to-do-list' folder and past in web root directory.


2] create database name as 'todo_list_project' and import 'todo_list_project.sql' file in it.


2] Change project URL in below file: to-do-list/application/config/config.php

$config['base_url'] = 'http://localhost/to-do-list'; replace this url with your directory.


4] Change Database configuration: to-do-list/application/config/database.php

'hostname' => 'localhost',
'username' => 'root',
'password' => '',
'database' => 'todo_list_project',