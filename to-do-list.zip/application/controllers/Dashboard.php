<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url');		
		$this->load->library('session');		
		$this->load->model('DashboardModel');
		$this->load->library('pagination');
		if(!$this->session->userdata('user_id'))
	    {
	        redirect('Login');
	    }
	}
	public function index()
	{
		$num_rows=$this->DashboardModel->get_getToDoData_count();
        $config['base_url'] = base_url().'/Dashboard/index/';
        $config['total_rows'] = $num_rows;
        $config['per_page'] = 10;
        $config['num_links'] = 3;
        $config['use_page_numbers'] = False;

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['prev_link'] = '&laquo;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["links"] = $this->pagination->create_links();
		$data['data'] = $this->DashboardModel->getToDoData($config["per_page"], $page);
		$this->load->view('layout/header');
		$this->load->view('dashboard',$data);
		$this->load->view('layout/footer');
	}

	public function addToDoList() 
	{
		$data['user'] = $this->DashboardModel->getUsers();
		$this->load->view('layout/header');
		$this->load->view('add_to_do_list',$data);
		$this->load->view('layout/footer');	

		if($this->input->post('add') == 'add')
		{
			if($this->input->post('todo_id') == '')
			{
				$dataadd['user_id_from'] = $this->session->userdata('user_id');
				$dataadd['user_id_to'] = $this->input->post('user_id_to');
				$dataadd['todo_name'] = $this->input->post('todo_name');
				$dataadd['description'] = $this->input->post('description');
				$dataadd['todo_date'] = $this->input->post('todo_date');
				$dataadd['todo_date'] = $this->input->post('date');
				$dataadd['date'] = date('Y-m-d H:s:i');
				$result = $this->DashboardModel->addToDoList($dataadd);
				if($result)
				{
					$this->session->set_flashdata('msg', 'success');
					$this->session->set_flashdata('error_msg', 'Data Added.');
					redirect('Dashboard');
				}
				else
				{
					$this->session->set_flashdata('msg', 'danger');
					$this->session->set_flashdata('error_msg', 'Please try again.');
					redirect('Dashboard/addToDoList');
				}
			}
			else
			{
				$dataedit['user_id_from'] = $this->session->userdata('user_id');
				$dataedit['user_id_to'] = $this->input->post('user_id_to');
				$dataedit['todo_name'] = $this->input->post('todo_name');
				$dataedit['description'] = $this->input->post('description');
				$dataedit['todo_date'] = $this->input->post('date');
				$dataedit['date'] = date('Y-m-d H:s:i');
				$dataedit['status'] = $this->input->post('status');
				$dataedit['date'] = date('Y-m-d H:s:i');
				$result = $this->DashboardModel->updateToDoData($dataedit,$this->input->post('todo_id'));
				if($result)
				{
					$this->session->set_flashdata('msg', 'success');
					$this->session->set_flashdata('error_msg', 'Data Updated.');
					redirect('Dashboard');
				}
				else
				{
					$this->session->set_flashdata('msg', 'danger');
					$this->session->set_flashdata('error_msg', 'Please try again.');
					redirect('Dashboard/editToDoList'.$this->input->post('todo_id'));
				}
			}

		}	
	}

	public function editToDoList() 
	{
		$data['data'] = $this->DashboardModel->editToDoData($this->uri->segment(3));
		$data['user'] = $this->DashboardModel->getUsers();
		$this->load->view('layout/header');
		$this->load->view('add_to_do_list',$data);
		$this->load->view('layout/footer');		
	}

	public function deleteToDoData()
	{
		$id = $this->uri->segment(3);
		$this->DashboardModel->deleteToDoData($id);
		redirect('Dashboard');
	}

}
