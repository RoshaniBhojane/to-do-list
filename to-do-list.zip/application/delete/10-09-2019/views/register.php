﻿    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <form action="<?php echo base_url('Register/insertuser')?>" class="form-horizontal" method="post">
              <h1>Create Account</h1>
			  <div>
                <input type="text" class="form-control" name="fname" placeholder="First Name" required="" />
              </div>
			  <div>
                <input type="text" class="form-control" name="lname" placeholder="Last Name" required="" />
              </div>
			  <div>
                <input type="email" class="form-control" name="email"  placeholder="Email" required="" />
              </div>
              <div>
                <input type="text" class="form-control" name="username"  placeholder="Username" required="" />
              </div>
              
              <div>
                <input type="password" class="form-control" name="password"  placeholder="Password" required="" />
              </div>
			  
			  <div>
			  <select class="form-control" name="role" required="" >
				<option> Select Role</option>
				<option value="0">New Employee</option>
				<option value="1">Data Entry</option>
				<option value="2">Manager</option>
				<option value="3">HR</option>
				<option value="4">Admin</option>
			  </select>
                
              </div>
			  <br>
              <div>
                <input type="submit" class="btn btn-default submit" value="Submit" name="submit">
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link">Already a member ?
                  <a href="<?php echo base_url('Login'); ?>" class="to_register"> Log in </a>
                </p>

                <div class="clearfix"></div>
                <br />

                <div>
                  <p>© 2019  Digitalzone Business Consulting Private Limited.</p>
                </div>
              </div>
            </form>
          </section>
        </div>
      </div>
    </div>

