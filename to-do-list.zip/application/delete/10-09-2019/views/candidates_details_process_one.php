        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Candidates Detail</h2>
                    <a href="<?php echo base_url();?>AddCandidatesProcessOne/updateCandidates/<?php echo $data['id'];?>" class="btn btn-success pull-right"><i class="fa fa-pencil">Edit</i></a>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    <div class="form-horizontal form-label-left">
                      <div class="form-group">
                        <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                          <label>First Name: </label>
                          <b><p class="form-control"><?php echo $data['first_name']; ?></p></b>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                          <label>Middle Name: </label>
                          <b><p class="form-control"><?php echo $data['middle_name']; ?></p></b>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                          <label>Last Name: </label>
                          <b><p class="form-control"><?php echo $data['last_name']; ?></p></b>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <label>Primary Email: </label>
                          <b><p class="form-control"><?php echo $data['primary_email_address']; ?></p></b>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <label>Secondary Email: </label>
                          <b><p class="form-control"><?php echo $data['secondary_email_address']; ?></p></b>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <label>Phone Number1: </label>
                          <b><p class="form-control"><?php echo $data['primary_phone']; ?></p></b>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <label>Phone Number2: </label>
                          <b><p class="form-control"><?php echo $data['secondary_phone']; ?></p></b>
                        </div>

                        <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                          <label>Date Of Birth: </label>
                          <b><p class="form-control"><?php echo $data['date_of_birth']; ?></p></b>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                          <label>Age: </label>
                          <b><p class="form-control"><?php echo $data['age']; ?></p></b>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                          <label>Gender: </label>
                          <b><p class="form-control"><?php echo $data['gender']; ?></p></b>
                        </div>

                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <label>Current Address: </label>
                          <b><p class="form-control"><?php echo $data['current_address']; ?></p></b>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <label>Permanent Address: </label>
                          <b><p class="form-control"><?php echo $data['permanant_address']; ?></p></b>
                        </div>

                        <div class="col-md-3 col-sm-3 col-xs-12 form-group has-feedback">
                          <label>Designation: </label>
                          <b><p class="form-control"><?php echo $data['designation']; ?></p></b>
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-12 form-group has-feedback">
                          <label>Status: </label>
                          <b><p class="form-control">
                            <?php 
                              if($data['status'] == 0) {  
                              echo "<span style='color: #555555;'>Initiate</span>";
                              } elseif($data['status'] == 1) {  
                              echo "<span style='color: #000000;'>Inprocess</span>";
                              } elseif($data['status'] == 2) {  
                              echo "<span style='color: #3f983f;'>Hired</span>";
                              } elseif($data['status'] == 3) {  
                              echo "<span style='color: #d43928;'>Rejected</span>";
                              } elseif($data['status'] == 4) {  
                              echo "<span style='color: #9b59b6;'>On-Hold</span>";
                              } elseif($data['status'] == 5) {  
                              echo "<span style='color: #219a83;'>Join</span>";
                              } elseif($data['status'] == 6) {  
                              echo "<span style='color: #3498db;'>Not Join</span>";
                              }
                            ?>
                          </p></b>
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <label>Remark: </label>
                          <b><p class="form-control"><?php echo $data['comments']; ?></p></b>
                        </div>
                      </div>

                      <div class="ln_solid"></div>    

                      <!-- <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <button class="btn btn-primary" type="reset">Reset</button>
                          <button type="submit" class="btn btn-success" name="add" value="add">Submit</button>
                        </div>
                      </div> -->

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

