    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <?php
           // print_r($this->session->userdata('username'));
              if($this->session->flashdata('error_msg'))
              {
              ?>
                <div class="alert alert-<?php  echo $this->session->flashdata('msg');?> fade in">
                 <?php  echo $this->session->flashdata('error_msg');?>    
                </div>
              <?php
              }
            ?>
          <section class="login_content">
            <form action="<?php echo base_url();?>Login/login" method="post">
              <h1>Recruitionary Login </h1>
              <div>
                <input type="text" class="form-control" placeholder="Username" name="username" value="" required="" />
              </div>
              <div>
                <input type="password" class="form-control" placeholder="Password" name="password" value="" required="" />
              </div>
              <div>
                <input type="submit" name="login" value="Log in" class="btn btn-default submit">
                <a class="reset_pass" href="<?php echo base_url();?>LostPassword">Lost your password?</a>
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link">New to site?
                  <a href="<?php echo base_url();?>Register" class="to_register"> Create Account </a>
                </p>

                <div class="clearfix"></div>
                <br />

                <div>
                  <p>© 2019  Digitalzone Business Consulting Private Limited.</p>
                </div>
              </div>
            </form>
          </section>
        </div>
      </div>
    </div>

