    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <?php
              if($this->session->flashdata('error_msg'))
              {
              ?>
                <div class="alert alert-<?php  echo $this->session->flashdata('msg');?> fade in">
                 <?php  echo $this->session->flashdata('error_msg');?>    
                </div>
              <?php
              }
            ?>
          <section class="login_content">
            <form action="<?php echo base_url();?>LostPassword/lostpassword" method="post">
              <h1>Recruitionary Login </h1>
              <div>
                <label style="margin-left: -70px;">Please Enter Your Registred Email Address:</label>
                <input type="text" class="form-control" placeholder="Email Address" name="email" value="" required="" />
              </div>
              <div>
                <input type="submit" name="lostpassword" value="Submit" class="btn btn-default submit">
                <a class="reset_pass" href="<?php echo base_url();?>Login"><i class="fa fa-long-arrow-left"></i> Back to Login</a>
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link">New to site?
                  <a href="<?php echo base_url();?>Register" class="to_register"> Create Account </a>
                </p>

                <div class="clearfix"></div>
                <br />

                <div>
                  <p>© 2019  Digitalzone Business Consulting Private Limited.</p>
                </div>
              </div>
            </form>
          </section>
        </div>
      </div>
    </div>

