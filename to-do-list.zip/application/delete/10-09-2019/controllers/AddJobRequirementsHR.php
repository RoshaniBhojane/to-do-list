<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AddJobRequirementsHR extends CI_Controller {
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url');		
		$this->load->library('session');
		$this->load->model('AddJobRequirementsHRModels');
		$this->load->model('ListJobRequirementsHRModel');
		$this->load->model('ListDesignationModel');
	}
	public function index()
	{
		$data['designation'] = $this->ListDesignationModel->getDesignationList();
		$this->load->view('layout/header');
		$this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('add_job_requirements_hr', $data);
		$this->load->view('layout/footer');
	}
	public function addNewJobRequirements()
	{
		if($this->input->post('id'))
		{
			//get form's data and store in local varable
			$data['user_id']=$this->input->post('user_id');
			$data['designation']=$this->input->post('designation');
			$data['designation']=$this->input->post('designation');
			$data['no_requirements']=$this->input->post('no_requirements');
			$data['comments']=$this->input->post('comments');
			$data['deadline']=$this->input->post('deadline');
			$data['no_fullfil_requirements']=$this->input->post('no_fullfil_requirements');
			$data['approved_status']=$this->input->post('approved_status');
			$data['opening_closed_status']=$this->input->post('opening_closed_status');
			$data['hr_comments']=$this->input->post('hr_comments');
			$data['date']=$this->input->post('date');
			/*echo "<pre>";
			print_r($data);
			die;*/
			$result = $this->AddJobRequirementsHRModels->updateCandidates($data,$this->input->post('id'));
			if($result)
			{
				$this->session->set_flashdata('msg', 'success');				
				$this->session->set_flashdata('error_msg', 'Record Sucessfuly added!');
				redirect('ListJobRequirementsHR');
			}
			else
			{
				$this->session->set_flashdata('msg', 'danger');
				$this->session->set_flashdata('error_msg', 'Data not updated!');
				redirect('ListJobRequirementsHR');
			}
		}
	}
	public function updateJobRequirements()
	{
		$data['opening'] = $this->ListJobRequirementsHRModel->editJobRequirements($this->uri->segment(3));
		$data['designation'] = $this->ListDesignationModel->getDesignationList();
	    $this->load->view('layout/header'); 
	    $this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('add_job_requirements_hr', $data);
        $this->load->view('layout/footer');
	}
}
