<?php
class Register extends CI_Controller 
{
		public function __construct()
		{
		
		parent::__construct();
		
		
		$this->load->database();
		
		$this->load->helper('url');
		
		$this->load->model('RegisterModel');
		$this->load->library('session');
		$this->load->library('javascript'); 
		
		}
		public function index()
		{
			$this->load->view('layout/login_header');
			$this->load->view('register');
			$this->load->view('layout/login_footer');
		}
		
		public function insertuser()
		{
			

			if($this->input->post('submit'))
			{
				$fname = $this->input->post('fname');
				$lname = $this->input->post('lname');
				$email = $this->input->post('email');
				
				$username = $this->input->post('username');
				$password1 = $this->input->post('password');
				$password = base64_encode($password1);
				$role = $this->input->post('role');
				
				
				
				
				date_default_timezone_set('Asia/Kolkata');
				$created = date("Y-m-d H:i:s");
				
				$this->RegisterModel->savedata($fname,$lname,$email,$username,$password,$role,$created);
				
				 $this->load->library('phpmailer_lib');
        
				$mail = $this->phpmailer_lib->load();
				
				
				$mail->isSMTP();
				$mail->Host     = 'smtp.gmail.com';
				$mail->SMTPAuth = true;
				$mail->Username = 'contact@digitalzonein.com';
				$mail->Password = 'TeamWork$2018';
				$mail->SMTPSecure = 'ssl';
				$mail->Port     = 465;
				
				$mail->setFrom('contact@digitalzonein.com', 'Digitalzone');
				$mail->addAddress($email, $fname );     
				
				$mail->Subject = 'Registration Successful';
			
				$mail->isHTML(true);
				
				//$htmlContent = file_get_contents("thankyou.html");
				
				$mailContent = '<div id="body" class="mktoText" style="font-family: Helvetica, Arial, Sans-Serif; padding:10px;">
				        <section> 
				        <table id="table-parent" style="background-color: #ffffff; border: 0 none; border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0;" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" width="100%"> 
				        <tbody> 
				        <tr> 
				        <td id="td-parent" style="border-collapse: collapse; font-family: Roboto, sans-serif; padding: 0;" align="center" bgcolor="#ffffff">
				        <div id="email" style="background-color: #ffffff; margin: 0 auto; padding: 20px 10px;" bgcolor="#ffffff"> 
				        <table class="bodyWrap" align="center" style="background-color: #f1f3f4; border: 0 none; border-collapse: collapse; margin: 0; max-width: 600px; mso-table-lspace: 0; mso-table-rspace: 0; padding: 0;" bgcolor="#f1f3f4" border="0" cellpadding="0" cellspacing="0" width="600"> 
				        <tbody> 
				        <tr> 
				        <td class="bodyWrap-td" style="border-collapse: collapse; font-family: Roboto, sans-serif; padding: 0;"> 
				        <table style="border: 0 none; border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0;" border="0" cellpadding="0" cellspacing="0" width="600"> 
				        <tbody> 
				        <tr> 
				        <td class="header-content" style="border-collapse: collapse; font-family: Roboto, sans-serif; padding: 28px 0;" align="center" bgcolor="#ffffff" valign="top" width="600"> 
				        <table style="border: 0 none; border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0;" align="center" border="0" cellpadding="0" cellspacing="0" width="600"> 
				        <tbody> 
				        <tr> 
				        <td class="logo" style="border-collapse: collapse; font-family: Roboto, sans-serif; padding: 0;" align="center" valign="top" width="600"><a href="#" target="_blank"><!-- <img src="cid:logoemail" style="border: 0 none; display: block; height: auto; max-height: auto;" /> -->Recruitionary</a></td> 
				        </tr> 
				        </tbody> 
				        </table> </td> 
				        </tr> 
				        <tr> 
				        <td class="body-content" style="border-collapse: collapse; font-family: Roboto, sans-serif; padding: 20px;background: #1ABB9C;" align="center" valign="top" width="600"> 
				        <table style="border: 0 none; border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0;" align="center" border="0" cellpadding="0" cellspacing="0" width="600">  
				        <tbody> 
				        <tr> 
				        <td class="mod-container-td" style="border: 1px solid #eef0f1; border-collapse: collapse; font-family: Roboto, sans-serif;" align="center" bgcolor="#ffffff" valign="top" width="600"> 
				        <table style="border: 0 none; border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0;" border="0" cellpadding="0" cellspacing="0" width="600"> 
				        <tbody> 
				        <tr> 
				          <td><br></td>
				        </tr> 
				        <tr> 
				        <td class="mod-padding" style="border-collapse: collapse; font-family: Roboto, sans-serif; padding: 25px 30px;" width="600"> 
				        <table style="border: 0 none; border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0;" border="0" cellpadding="0" cellspacing="0"> 
				        <tbody> 
				        <tr> 
				        <td class="copy" style="border-collapse: collapse; color: #5f6368; font-family: Roboto, sans-serif; font-size: 16px; line-height: 26px; padding: 10px 0 0;" width="600">
						<font style="font-size:23px">Thank you!</font><br><br>
				        Dear User,
				        <br><br>
				       
								<font style="font-size:20px">Your registration has been successfully completed.</font><br><br>
								<font style="font-size:18px;text-align:left">To login, find details mentioned below.</font><br><br>
								<font style="font-size:20px">Username:'.$username.'</font><br><br>
								<font style="font-size:20px">Password:'.$password1.'</font><br><br>
				        <br><br>
				        Regards,<br>
				        Recruitionary
				        <br>
				        </td> 
				        </tr> 
				        </tbody> 
				        </table> </td> 
				        </tr> 
				        </tbody> 
				        </table> </td> 
				        </tr> 
				        </tbody> 
				        </table> </td> 
				        </tr>  
				        </tbody> 
				        </table> </td> 
				        </tr> 
				        <tr> 
				        <td class="footer-content" style="border-collapse: collapse; font-family: Roboto, sans-serif; padding: 25px 30px;" align="center" bgcolor="#ffffff" valign="top" width="600"> 
				        <table style="border: 0 none; border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0;" align="center" border="0" cellpadding="0" cellspacing="0" width="600"> 
				        <tbody> 
				        <tr> 
				        <td class="footer-addr" style="border-collapse: collapse; color: #313030; font-family: Roboto, sans-serif; font-size: 13px; line-height: 14px; padding: 0 0 15px;" align="center" valign="top" width="600"><span class="ios-link-footer-addr" style="color: #313030; cursor: text; text-decoration: none;"><span><a target="_blank" href="http://www.digitalzonein.com/" style="color: #215968; font-size: 20px;font-weight: bold;text-decoration: none;">Digitalzone Business Consulting</a><br><br>301 & 338, 3rd  Floor C-3, Amanora Chambers, Amanora Town, Hadapsar, Pune - 411028</span></span></td> 
				        </tr> 
				        </tbody> 
				        </table> </td> 
				        </tr> 
				        </tbody> 
				        </table> 
				        </div> </td> 
				        </tr> 
				        </tbody> 
				        </table> 
				        </section> 
				        </div> ';
					
				$mail->Body = $mailContent;
				
				if(!$mail->send()){
					
					?>
				<script type=text/javascript>alert("Error occured, Please try again.");</script>
				<?php
				}else{
					?>
				<script type=text/javascript>alert("User data have been added successfully.");</script>
				<?php
				}

				
			}
			$this->load->view('layout/login_header');
			$this->load->view('login');
			$this->load->view('layout/login_footer');
		}
		
		
	}

?>