<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ListScheduleInterviewProcessOne extends CI_Controller {
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url');		
		$this->load->library('session');
		$this->load->library('pagination');
		$this->load->model('ListScheduleInterviewProcessOneModel');
		$this->load->model('ListDesignationModel');
		$this->load->model('ListSourceModel');
	}
	public function index()
	{
		$num_rows=$this->ListScheduleInterviewProcessOneModel->get_ScheduleInterviewDate_count();
        $config['base_url'] = base_url().'/ListScheduleInterviewProcessOne/index/';
        $config['total_rows'] = $num_rows;
        $config['per_page'] = 5;
        $config['num_links'] = 3;
        $config['use_page_numbers'] = False;

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['prev_link'] = '&laquo;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["links"] = $this->pagination->create_links();
		
		$data['user'] = $this->ListScheduleInterviewProcessOneModel->getScheduleInterviewDate($config['per_page'], $page);
		$this->load->view('layout/header');
		$this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('list_schedule_interview_process_one',$data);
		$this->load->view('layout/footer');
	}
	public function updateScheduleInterview()
	{
		$data['user'] = $this->ListScheduleInterviewProcessOneModel->editScheduleInterviewData($this->uri->segment(3));
		$data['date'] = $this->ListScheduleInterviewProcessOneModel->editScheduleInterviewDate($this->uri->segment(3));
		$data['designation'] = $this->ListDesignationModel->getDesignationList();
		$data['source'] = $this->ListSourceModel->getSource();
	    $this->load->view('layout/header'); 
	    $this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('add_schedule_interview_process_one', $data);
        $this->load->view('layout/footer');
	}
	public function addInterviewScheduleCandidates()
	{
		if($this->input->post('first_name'))
		{
			if($this->input->post('id'))
			{
				//get form's data and store in local varable
				$data['first_name']=$this->input->post('first_name');
				$data['last_name']=$this->input->post('last_name');
				$data['primary_email_address']=$this->input->post('primary_email_address');
				$data['primary_phone']=$this->input->post('primary_phone');
				$data['experience']=$this->input->post('experience');
				$data['designation']=$this->input->post('designation');	
				$data['source']=$this->input->post('source');
				$data['date'] = $this->input->post('date');
				$data['status']='0';
				$data['user_role']='0';
				$result = $this->ListScheduleInterviewProcessOneModel->addInterviewScheduleData($_POST['sch'],$this->input->post('id'));
				$result = $this->ListScheduleInterviewProcessOneModel->updateCandidateData($data,$this->input->post('id'));
				
				if($result)
				{
					$this->session->set_flashdata('msg', 'success');				
					$this->session->set_flashdata('error_msg', 'Record Sucessfuly added!');
					redirect('ListScheduleInterviewProcessOne/updateScheduleInterview/'.$this->input->post('id'));
				}
				else
				{
					$this->session->set_flashdata('msg', 'danger');
					$this->session->set_flashdata('error_msg', 'Data not updated!');
					redirect('ListScheduleInterviewProcessOne/updateScheduleInterview/'.$this->input->post('id'));
				}
			}
			else
			{
				//get form's data and store in local varable
				$data['first_name']=$this->input->post('first_name');
				$data['last_name']=$this->input->post('last_name');
				$data['primary_email_address']=$this->input->post('primary_email_address');
				$data['primary_phone']=$this->input->post('primary_phone');
				$data['experience']=$this->input->post('experience');
				$data['designation']=$this->input->post('designation');	
				$data['source']=$this->input->post('source');
				$data['date'] = $this->input->post('date');
				$data['status']='0';
				$data['user_role']='0';
				$result = $this->ListScheduleInterviewProcessOneModel->addNewCandidates($data,$_POST['sch']);
				if($result)
				{
					$result = $this->ListScheduleInterviewProcessOneModel->addInterviewScheduleData($_POST['sch'],$result);
					$this->session->set_flashdata('msg', 'success');				
					$this->session->set_flashdata('error_msg', 'Record Sucessfuly added!');
					redirect('ListScheduleInterviewProcessOne');
				}
				else
				{
					$this->session->set_flashdata('msg', 'danger');
					$this->session->set_flashdata('error_msg', 'Data not updated!');
					redirect('ListScheduleInterviewProcessOne');
				}
			}
		}
		$data['designation'] = $this->ListDesignationModel->getDesignationList();
		$data['designation'] = $this->ListDesignationModel->getDesignationList();
		$data['source'] = $this->ListSourceModel->getSource();
	    $this->load->view('layout/header'); 
	    $this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('add_schedule_interview_process_one', $data);
        $this->load->view('layout/footer');
	}
}
