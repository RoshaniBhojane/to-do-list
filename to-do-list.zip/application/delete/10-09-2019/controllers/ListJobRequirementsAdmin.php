<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ListJobRequirementsAdmin extends CI_Controller {
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url');		
		$this->load->library('session');
		$this->load->model('ListJobRequirementsAdminModel');
		$this->load->library('pagination');
	}
	public function index()
	{
		$num_rows=$this->ListJobRequirementsAdminModel->get_opening_count();
        $config['base_url'] = base_url().'/ListJobRequirementsAdmin/index/';
        $config['total_rows'] = $num_rows;
        $config['per_page'] = 5;
        $config['num_links'] = 3;
        $config['use_page_numbers'] = False;

        $config['full_tag_open'] = '<ul class="pagination">';
        $config['full_tag_close'] = '</ul>';
        $config['prev_link'] = '&laquo;';
        $config['prev_tag_open'] = '<li>';
        $config['prev_tag_close'] = '</li>';
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a href="#">';
        $config['cur_tag_close'] = '</a></li>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';

        $this->pagination->initialize($config);
        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
        $data["links"] = $this->pagination->create_links();
		$data['opening'] = $this->ListJobRequirementsAdminModel->getOpeningList($config["per_page"], $page);
		/*$data['opening'] = $this->ListJobRequirementsAdminModel->getOpeningList();
		echo "<pre>";
		print_r($data);
		die;*/
		$this->load->view('layout/header');
		$this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('list_job_requirements_admin', $data);
		$this->load->view('layout/footer');
	}

	/*public function updateCandidateStatus()
	{
		$data['status']=$this->input->post('status');
		$result = $this->ListJobRequirementsAdminModel->updateCandidateStatus($data,$this->input->post('id'));
	}
	public function showCandidateDetails()
	{
		$data['data'] = $this->ListJobRequirementsAdminModel->editCandidates($this->uri->segment(3));
		$this->load->view('layout/header');
		$this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('candidates_details_process_one',$data);
		$this->load->view('layout/footer');
	}*/
}
