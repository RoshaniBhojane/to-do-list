<?php

class ListCandidateProcessTwoModel extends CI_Model

{
	
	function displayrecords($limit, $start)
	{
		
		$hired = 2;
		$join = 5;
		$sql = "SELECT * FROM mst_users_tbl WHERE (status='".$hired."' OR status='".$join."') limit $start, $limit";
		$query = $this->db->query($sql);
		//return $query->result();
		
		if($query->num_rows() > 0)
	    {
	    	return $query->result();
	    }
	    else
	    {
	    	return false;
	    }  
		
	}
	
	public function get_candidates_count()
	{
		$hired = 2;
		$join = 5;
		$sql = "SELECT * FROM mst_users_tbl WHERE (status='".$hired."' OR status='".$join."')";
		//print_r($sql);
		$query = $this->db->query($sql);
		//return $query->result();
		if($query->num_rows() > 0)
	    {
	    	return $query->num_rows();
	    }
	    else
	    {
	    	return false;
	    } 
	}




	
}

?>