<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class UserLostPasswordModel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	public function getLostPassword($email)
	{
		$condition = "SELECT * FROM mst_users_tbl WHERE primary_email_address='".$email."'";
	    if($query = $this->db->query($condition))
	    {
	    	return $query->row_array();
	    }
	    else
	    {
	    	return false;
	    }

	    
	}	
}
?>
