<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class UserLoginModel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	public function getLoginUsers($username,$password)
	{
		$condition = "SELECT * FROM mst_users_tbl WHERE username='".$username."' AND password='".base64_encode($password)."'";
	    if($query = $this->db->query($condition))
	    {
	    	return $query->row_array();
	    }
	    else
	    {
	    	return false;
	    }

	    
	}	
}
?>
