<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class ListEducationModel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	public function getEducationList()
	{
		$condition = $this->db->query("SELECT `degree_type` FROM `education_list_tbl`");
	    if($condition->num_rows() > 0)
	    {
	    	return $condition->result();
	    }
	    else
	    {
	    	return false;
	    }   
	}	
}
?>
