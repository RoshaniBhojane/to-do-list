<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class ListJobRequirementsHRModel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	public function getOpeningList($limit, $start)
	{
		$arr=[];
		$condition = $this->db->query("SELECT `id`, `user_id`, `designation`, `no_requirements`, `comments`, `deadline`, `no_fullfil_requirements`, `approved_status`, `opening_closed_status`, `hr_comments` FROM `designation_openings_tbl` limit $start, $limit");
		if($condition->num_rows() > 0)
	    {
	    	foreach ($condition->result_array() as $value) {
	    		$condition1 = $this->db->query("SELECT `id`,`first_name`,`last_name`,`primary_email_address` FROM `mst_users_tbl` WHERE id=".$value['user_id']);	    		
	    		$mstResult = $condition1->row();
	    		if(!empty($value['id']))
	    		{
	    			$arr[]=array(
		    			'user_id'=>$mstResult->id,
		    			'first_name'=>$mstResult->first_name,
		    			'last_name'=>$mstResult->last_name,
		    			'primary_email_address'=>$mstResult->primary_email_address,
		    			'id'=>$value['id'],
		    			'designation'=>$value['designation'],
		    			'no_requirements'=>$value['no_requirements'],
		    			'comments'=>$value['comments'],
		    			'deadline'=>$value['deadline'],
		    			'no_fullfil_requirements'=>$value['no_fullfil_requirements'],
		    			'approved_status'=>$value['approved_status'],
		    			'opening_closed_status'=>$value['opening_closed_status'],
		    			'hr_comments'=>$value['hr_comments']
		    		);
	    		}
	    	}
	    	return $arr;
	    }
	    else
	    {
	    	return false;
	    } 
	}	

	public function get_opening_count()
	{
		$condition = $this->db->query("SELECT `id`, `user_id`, `designation`, `no_requirements`, `comments`, `deadline`, `no_fullfil_requirements`, `approved_status`, `opening_closed_status`, `hr_comments` FROM `designation_openings_tbl`");
		//$query = $this->db->get($condition)
	    if($condition->num_rows() > 0)
	    {
	    	return $condition->num_rows();
	    }
	    else
	    {
	    	return false;
	    }   
	}
    /*public function updateCandidateStatus($data,$id)
    {
	    $this->db->where('id',$id);
        return $this->db->update('mst_users_tbl',$data); 
	}*/
	public function editJobRequirements($id)
    {
    	$condition = $this->db->query("SELECT `id`,`user_id`,`designation`,`no_requirements`,`comments`,`deadline`,`no_fullfil_requirements`,`approved_status`,`approved_by`,`opening_closed_status`,`opening_closed_by`,`hr_comments` FROM `designation_openings_tbl` WHERE id=".$id);
    	
    	if($condition->num_rows() > 0)
	    {
	    	$result = $condition->row();
	    	$condition1 = $this->db->query("SELECT `id`,`first_name`,`last_name`,`primary_email_address` FROM `mst_users_tbl` WHERE id=".$result->user_id);
	    	$result1 = $condition1->row();
    		if(!empty($result1->id))
    		{
    			$arr=array(
    					'id'=>$result->id,
		    			'user_id'=>$result->user_id,
		    			'designation'=>$result->designation,
		    			'no_requirements'=>$result->no_requirements,
		    			'comments'=>$result->comments,
		    			'deadline'=>$result->deadline,
		    			'no_fullfil_requirements'=>$result->no_fullfil_requirements,
		    			'approved_status'=>$result->approved_status,
		    			'approved_by'=>$result->approved_by,
		    			'opening_closed_status'=>$result->opening_closed_status,
		    			'opening_closed_by'=>$result->opening_closed_by,
		    			'hr_comments'=>$result->hr_comments,
		    			'first_name'=>$result1->first_name,
		    			'last_name'=>$result1->last_name,
		    			'primary_email_address'=>$result1->primary_email_address
		    		);    			
    			return $arr;
    		}
	    }
	    else
	    {
	    	return false;
	    } 
    	/*$this->db->where('id',$id);
        $query = $this->db->get('designation_openings_tbl');
		if($query->num_rows() > 0)
        {
           return $query->row_array();
        }
		else
		{
            return false;
        }    */      
    }
}
?>
