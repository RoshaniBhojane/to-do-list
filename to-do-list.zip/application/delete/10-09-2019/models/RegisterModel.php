<?php

class RegisterModel extends CI_Model

{
	
	function savedata($fname,$lname,$email,$username,$password,$role,$created)
	{
		$query = "insert into mst_users_tbl(first_name,last_name,primary_email_address,username,password,user_role,date) values('$fname','$lname','$email','$username','$password','$role','$created')";
		$this->db->query($query);
		
	}
	
		
}

?>