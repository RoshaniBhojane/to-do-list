<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class AddJobRequirementsAdminModels extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	/*public function addNewJobRequirements($data)
	{
		$result=$this->db->insert('mst_users_tbl', $data);
		if($result)
		{
			return true;
		}
	}*/
	public function updateCandidates($data,$id)
	{
		$this->db->where('id',$id);
        return $this->db->update('designation_openings_tbl',$data);   
	}
	public function getManager($user_id)
	{
        $condition = $this->db->query('SELECT primary_email_address FROM `mst_users_tbl` WHERE user_role="2" AND id="'.$user_id.'"');   
        if($condition->num_rows() > 0)
	    {
	    	return $condition->result();
	    }
	    else
	    {
	    	return false;
	    } 
	}
	public function getManagerHR($user_id)
	{
        $condition = $this->db->query('SELECT primary_email_address FROM `mst_users_tbl` WHERE (user_role="2" AND id="'.$user_id.'") OR user_role="3"');   
        if($condition->num_rows() > 0)
	    {
	    	return $condition->result();
	    }
	    else
	    {
	    	return false;
	    } 
	}
}
?>
