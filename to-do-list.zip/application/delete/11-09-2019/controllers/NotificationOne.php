<?php
class NotificationOne extends CI_Controller 
{
	public function __construct()
	{
	
	parent::__construct();
	
	$this->load->database();
	
	$this->load->helper('url');
	
	$this->load->model('DashboardNotificationModel');
	$this->load->library('session');
	$this->load->library('pagination');
	}
		public function index()
		{
			
			$id = $this->uri->segment(3);
			
			$data['noti'] = $this->DashboardNotificationModel->opennotification($id);
			$data['data1'] = $this->DashboardNotificationModel->fetchnotificationall();
			$this->load->view('layout/header');
			$this->load->view('layout/menu_side_bar');
			$this->load->view('layout/menu_top_bar');
			
			$this->load->view('notification_one',$data);
			
			$this->load->view('layout/footer');
			//redirect('NotificationOne/index/'.$id);
		}
		public function singlenotification()
		{
			$id = $this->uri->segment(3);
			$data['data1'] = $this->DashboardNotificationModel->fetchnotificationall();
			$data['noti'] = $this->DashboardNotificationModel->opennotification($id);
			$this->load->view('layout/header');
			$this->load->view('layout/menu_side_bar');
			$this->load->view('layout/menu_top_bar');
			
			$this->load->view('notification_one',$data);
			
			$this->load->view('layout/footer');
		}
		
		
	}

?>