<?php
	$path = base_url();
	$main_doc1 = array("Adhaar Card", "Pan Card", "Passport size photograph", "SSC Marksheet","HSC Marksheet", "Graduation Marksheet", "Post Graduation Marksheet", "Relieving Letter/Experience Letter/Resignation Letter", "Resume", "Salary Slips");
	
?>
				
<div class="right_col" role="main">
	<div class="page-title">
        <div class="title_left">
            <h3 style="font-weight:bold">Candidate Documents</h3>
		</div>
    </div>
	<div class="clearfix"></div>
	<div class="col-md-12 col-sm-12 col-xs-12">
		<div class="x_panel">
            <div class="x_title">
                    <h2>Upload Documents</h2>
                    
                    <div class="clearfix"></div>
                  </div>  
            <div class="x_content">
                
				<div style="margin-right:43em">
				<?php
				if($this->session->flashdata('success_msg'))
              {
              ?>
                <div class="alert alert-<?php  echo $this->session->flashdata('msg3');?> fade in">
                 <?php  echo $this->session->flashdata('success_msg');?>    
                </div>
              <?php
              }
				?>
					</div>
					<?php
				  foreach($data1 as $row)
						  {?>
				<h4>Candidate Name: <?php echo $row->first_name; $userid= $row->id; echo " "; echo $row->last_name; ?></h4>		  
                <h4>You can upload multiple document onclicking "Add" Button.</h4><br><br>
                
                <form class="form-inline" action="<?php echo base_url('UploadCandidateDocument/uploaddocument')?>" method="post" enctype="multipart/form-data">
				
                  <div class="form-group" style="">
				  
                    <input type="text" name="userid" style="display:none" value="<?php echo $row->id; ?>"  >
						  <?php }  ?>
					<select id="ex3" class="form-control" name="doc_category[]" required="">
						<option value="">Select Category</option>
						<option value="Adhaar Card">Adhaar Card</option>
						<option value="Pan Card">Pan Card</option>
						<option value="Passport size photograph">Passport size photograph</option>
						<option value="SSC Marksheet">SSC Marksheet</option>
						<option value="HSC Marksheet">HSC Marksheet</option>
						<option value="Graduation Marksheet">Graduation Marksheet</option>
						<option value="Post Graduation Marksheet">Post Graduation Marksheet</option>
						<option value="Relieving Letter/Experience Letter/Resignation Letter">Relieving Letter/ Experience Letter/ Resignation Letter</option>
						<option value="Resume">Resume</option>
						<option value="Salary Slips">Salary Slips</option>
					</select>
                  </div>
				  
                  <div class="form-group" style="margin-left:36px">
                    
                    <input type="file" name="doc[]" id="ex4" class="form-control" placeholder=" ">
                  </div>
				  
				  
				  
					<div class="content">
					</div>
					
                  <br><br>
				  <div class="col-md-9 col-sm-9 col-xs-12 col-md-offset-3">
                    <button class="btn btn-primary" onclick="addelement();" id="addScnt" type="button">Add</button>
					<button name="upload" style="" type="submit" class="btn btn-success">Upload</button>
                  </div>
				  
                </form>
            </div>
        </div>
	</div>
	
	<div class="clearfix"></div>
	 <?php
         if(!empty($user))
         {?>
	<div class="col-md-12 col-sm-12 col-xs-12" style="margin-top:30px">
                <div class="x_panel">
                 <div class="x_title" style="border-bottom:none !important">
                    <h2> List of Uploaded Documents</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
					<div id="datatable-buttons_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                      
                      
                    <table id="datatable-buttons" class="table table-striped table-bordered">
                      <thead style="background-color:#2A3F54;color:#FFF">
                        <tr>
                          <th>No.</th>
                          <th>Document Category</th>
                          <th>Document</th>
                          <th>Uploaded Date</th>
                          
                        </tr>
                      </thead>


                      <tbody>
						<?php
							$i=1;
							$doc_cat = array();
						  foreach($user as $row)
						  {
							  
							echo "<tr>";
						  
							echo "<td>".$i."</td>";
							echo "<td>".$row->document_name."</td>";
							echo "<td><a target='_blank' href='".$path."uploads/documents/".$row->user_id."/".$row->document_path."'>".$row->document_path."</a></td>";
							
							echo "<td>".$row->document_uploading_date."</td>";
							
							
							echo "</tr>";
							$i++;
								$docu = $row->document_name;
								
								array_push($doc_cat, $docu);
								
						  }
						 
						?>
                        
                      </tbody>
                    </table>
					</div>
                  </div>
                </div>
              </div>
		 <?php
		 }else{$doc_cat=array();}
		 ?>
		 <!-- deadline starts-->
		 
		 <div class="clearfix"></div>
	 <?php
         if(!empty($deadline))
         {?>
	<div class="col-md-12 col-sm-12 col-xs-12" style="margin-top:30px">
                <div class="x_panel">
                 <div class="x_title" style="border-bottom:none !important">
                    <h2> List of Pending Documents</h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
					<div id="datatable-buttons_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                      
                      
                    <table id="datatable-buttons" class="table table-striped table-bordered">
                      <thead style="background-color:#2A3F54;color:#FFF">
                        <tr>
                          <th>No.</th>
                          <th>Document Category</th>
                          <th>Deadline1</th>
						  <th>Deadline2</th>
						  <th>Reason</th>
                          <th>Date</th>
                          
                        </tr>
                      </thead>


                      <tbody>
						<?php
							$i=1;
							$expired= 'Expired';
						  foreach($deadline as $row)
						  {
							  
							if (!in_array(($row->document_name), $doc_cat)) 
							{	
							echo "<tr>";
						  
							echo "<td>".$i."</td>";
							echo "<td>".$row->document_name."</td>";
							
								date_default_timezone_set("Asia/Kolkata");
								$newdate = date("Y-m-d");
									if($newdate <= $row->deadline_one)
									{
							echo "<td>".$row->deadline_one."</td>";
									}else
									{
							//echo "<td>".$expired."</td>";
							echo "<td style='color:red'>".$row->deadline_one."</td>";
									}										
							if(($row->deadline_two) == '0000-00-00')
							{ 
								echo "<td><a class='btn btn-primary btn-xs' href='".$path."UploadCandidateDocument/setdeadline/".$userid."/".str_replace('/','-',$row->document_name)."/2'><i class='fa fa-clock-o'> SET</i></a></td>";
							}
							else
							{
								if($newdate <= $row->deadline_two)
									{
							echo "<td>".$row->deadline_two."</td>";
									}else
									{
							//echo "<td>".$expired."</td>";
							echo "<td style='color:red'>".$row->deadline_two."</td>";
									}	
							}
							
							echo "<td>".$row->comments."</td>";
							echo "<td>".$row->date."</td>";
							
							
							echo "</tr>";
							$i++;
							}
							
								$docu = $row->document_name;
								
								array_push($doc_cat, $docu);
							
							
						 
								
						  }
						  $no=$i;
							$count2 = count($doc_cat); 
							for($k=0;$k<$count2;$k++)
							{
								if (($key = array_search($doc_cat[$k], $main_doc1)) !== false) 
								{
								unset($main_doc1[$key]);
								}

							}
							$main_doc = array_values($main_doc1); 
							
							$count1 = count($main_doc);
						  for($i=0;$i<$count1;$i++)
						  {
							  
							echo "<tr>";
						  
							echo "<td>".$no."</td>";
							echo "<td>".$main_doc[$i]."</td>";
							echo "<td><a class='btn btn-primary btn-xs' href='".$path."UploadCandidateDocument/setdeadline/".$userid."/".str_replace('/','-',$main_doc[$i])."/1'><i class='fa fa-clock-o'> SET</i></a></td>";
							
							echo "<td><a class='btn btn-primary btn-xs' onclick='deadline();'><i class='fa fa-clock-o'> SET</i></a></td>";
							
							echo "<td>Not defined Yet</td>";
							echo "<td>Not Set Yet</td>";
							
							echo "</tr>";
							$no++;
								
						  }
						 
						
                        
						?>
                        
                      </tbody>
                    </table>
					</div>
                  </div>
                </div>
              </div>
		 <?php
		 }
		 else
		 {
			 
		
		 ?>
		 
		 <!-- deadline end-->
		 
			<div class="clearfix"></div>
			<div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                 <div class="x_title">
                    <h2>Pending Documents</small></h2>
                    
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
					<div id="datatable-buttons_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                     
                    <table id="datatable-buttons" class="table table-striped table-bordered">
                      <thead style="background-color:#2A3F54;color:#FFF">
                        <tr>
                          <th>No.</th>
                          <th>Document Name</th>
                          <th>Deadline 1</th>
                          <th>Deadline 2</th>
                          <th>Reason</th>
                    
                        </tr>
                      </thead>


                      <tbody>
						<?php
							$no=1;
							$count2 = count($doc_cat); 
							for($k=0;$k<$count2;$k++)
							{
								if (($key = array_search($doc_cat[$k], $main_doc1)) !== false) 
								{
								unset($main_doc1[$key]);
								}

							}
							$main_doc = array_values($main_doc1); 
							
							$count1 = count($main_doc);
						  for($i=0;$i<$count1;$i++)
						  {
							  
							echo "<tr>";
						  
							echo "<td>".$no."</td>";
							echo "<td>".$main_doc[$i]."</td>";
							echo "<td><a class='btn btn-primary btn-xs' href='".$path."UploadCandidateDocument/setdeadline/".$userid."/".str_replace('/','-',$main_doc[$i])."/1'><i class='fa fa-clock-o'> SET</i></a></td>";
							
							echo "<td><a class='btn btn-primary btn-xs' onclick='deadline();'><i class='fa fa-clock-o'> SET</i></a></td>";
							
							echo "<td>Not defined Yet</td>";
							
							echo "</tr>";
							$no++;
								
						  }
						 
						?>
                        
                      </tbody>
                    </table>
					

                  
					</div>
                  </div>
                </div>
              </div>
			  <?php
				}
				?>
</div>
<script>

var i = 0;
function addelement()
{
	
	var element ='<div style="margin-top:40px" class="form-group deleteelement_'+i+'"><select id="ex3" class="form-control" name="doc_category[]" required=""><option value="">Select Category</option><option value="Adhaar Card">Adhaar Card</option><option value="Pan Card">Pan Card</option><option value="Passport size photograph">Passport size photograph</option><option value="SSC Marksheet">SSC Marksheet</option><option value="HSC Marksheet">HSC Marksheet</option><option value="Graduation Marksheet">Graduation Marksheet</option><option value="Post Graduation Marksheet">Post Graduation Marksheet</option><option value="Relieving Letter/Experience Letter/Resignation Letter">Relieving Letter/Experience Letter/Resignation Letter</option><option value="Resume">Resume</option><option value="Salary Slips">Salary Slips</option></select></div><div style="margin-top:40px;margin-left:40px" class="form-group deleteelement_'+i+'"><input type="file" name="doc[]" id="ex4" class="form-control" placeholder=" "><button style="margin-left:20px" type="button" class="btn btn-danger btn-xs"><a href="javascript:;" style="color:white" onclick="delete1('+i+')">Remove</a></button></div>';
	
	$(".content").append(element);
	i++;
}
function delete1(id)
{
	$('.deleteelement_'+id).remove();
}
function deadline()
{
	alert('You can not set second deadline without setting First Deadline.');
}
</script>                     