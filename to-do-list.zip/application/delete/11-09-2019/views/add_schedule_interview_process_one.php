        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Add New Candidates</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    <?php
                    // print_r($this->session->userdata('username'));
                    if($this->session->flashdata('error_msg'))
                    {
                    ?>
                      <div class="alert alert-<?php  echo $this->session->flashdata('msg');?> fade in">
                       <?php  echo $this->session->flashdata('error_msg');?>    
                      </div><br />
                    <?php
                    }
                  ?>
                    <form action="<?php echo base_url();?>ListScheduleInterviewProcessOne/addInterviewScheduleCandidates" method="post" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
                      <input type="hidden" name="id" value="<?php if(!empty($user['id'])){echo $user['id'];}else{}?>">
                      <input type="hidden" name="date" value="<?php echo date("Y-m-d H:i:s"); ?>">
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          First Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" name="first_name" value="<?php if(!empty($user['first_name'])){echo $user['first_name'];}else{}?>" class="form-control has-feedback-left" id="inputSuccess2" placeholder="First Name">
                          <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Last Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" name="last_name" value="<?php if(!empty($user['last_name'])){echo $user['last_name'];}else{}?>" class="form-control has-feedback-left" id="inputSuccess2" placeholder="Last Name">
                          <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>  
                      
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Email Address<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="email" name="primary_email_address" value="<?php if(!empty($user['primary_email_address'])){echo $user['primary_email_address'];}else{}?>" class="form-control has-feedback-left" id="inputSuccess4" placeholder="Primary Email">
                          <span class="fa fa-envelope form-control-feedback left" aria-hidden="true"></span>
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Phone Number <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <input type="text" name="primary_phone" value="<?php if(!empty($user['primary_phone'])){echo $user['primary_phone'];}else{}?>" class="form-control" id="inputSuccess5" placeholder="Phone Number1">
                          <span class="fa fa-phone form-control-feedback right" aria-hidden="true"></span>
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Experience <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <select class="form-control" name="experience">
                            <?php if(!empty($user['experience'])){ ?> 
                              <option value="<?php echo $user['experience']; ?>"  selected="selected">
                                <?php if($user['experience'] == 1) { echo "Fresher"; } elseif($user['experience'] == 2) { echo "Experienced"; }?>
                              </option>
                            <?php }?>
                              <option>Select</option>
                              <option value="1"><?php echo "Fresher"; ?></option>
                              <option value="2"><?php echo "Experienced"; ?></option>
                          </select>
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Designation <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <select class="form-control" name="designation">
                            <?php if(!empty($user['designation'])){ ?> 
                              <option value="<?php echo $user['designation']; ?>" selected="selected" ><?php echo $user['designation'];?></option>
                            <?php }?>
                              <option>Select</option>
                             <?php
                                if(!empty($designation))
                                {
                                  foreach ($designation as $designation_value) 
                                  {
                              ?>                              
                                    <option value="<?php echo $designation_value->designation; ?>"><?php echo $designation_value->designation; ?></option>
                              <?php
                                  }
                                }
                              ?>
                          </select>
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Source <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <select class="form-control" name="source">
                            <?php if(!empty($user['source'])){ ?> 
                              <option value="<?php echo $user['source']; ?>" selected="selected" ><?php echo $user['source'];?></option>
                            <?php }?>
                              <option>Select</option>
                             <?php
                                if(!empty($source))
                                {
                                  foreach ($source as $source_value) 
                                  {
                              ?>                              
                                    <option value="<?php echo $source_value->source; ?>"><?php echo $source_value->source; ?></option>
                              <?php
                                  }
                                }
                              ?>
                          </select>
                        </div>
                      </div>

                      <?php
                      if(!empty($user['id'])){
                        if(!empty($date))
                        {
                          $i = 1;
                          foreach ($date as $date_value) 
                          {
                      ?> 
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Interview Date<?php echo $i;?> <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="hidden" name="sch[<?php echo $i;?>][user_id]" value="<?php if(!empty($user['id'])){echo $user['id'];}else{}?>">
                            <input type="hidden" name="sch[<?php echo $i;?>][date]" value="<?php echo date("Y-m-d H:i:s"); ?>">
                            <div class="input-group date">
                                <input type="text" name="sch[<?php echo $i;?>][interview_schedule_date]" value="<?php if(!empty($date_value['interview_schedule_date'])){echo $date_value['interview_schedule_date'];}else{}?>" class="form-control">
                                <span class="input-group-addon">
                                   <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                      </div>
                      <?php
                            $i++;
                          }
                      ?>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Interview Date <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="hidden" name="sch[0][user_id]" value="<?php if(!empty($user['id'])){echo $user['id'];}else{}?>">
                            <input type="hidden" name="sch[0][date]" value="<?php echo date("Y-m-d H:i:s"); ?>">
                            <div class="input-group date" id="myDatepicker1">
                                <input type="text" name="sch[0][interview_schedule_date]" value="" class="form-control">
                                <span class="input-group-addon">
                                   <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                      </div>
                      <?php
                        }
                        else
                        {
                      ?>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Interview Date <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="hidden" name="sch[0][user_id]" value="<?php if(!empty($user['id'])){echo $user['id'];}else{}?>">
                            <div class="input-group date" id="myDatepicker1">
                                <input type="text" name="sch[0][interview_schedule_date]" value="" class="form-control">
                                <span class="input-group-addon">
                                   <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                      </div>
                      <?php
                        }
                      }
                      else
                      {
                    ?>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Interview Date <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <div class="input-group date" id="myDatepicker1">
                                <input type="text" name="sch[0][interview_schedule_date]" value="" class="form-control">
                                <span class="input-group-addon">
                                   <span class="glyphicon glyphicon-calendar"></span>
                                </span>
                            </div>
                        </div>
                      </div>
                    <?php
                      }
                      ?>
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <button class="btn btn-primary" type="reset">Reset</button>
                          <button type="submit" class="btn btn-success" name="add" value="add">Submit</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

