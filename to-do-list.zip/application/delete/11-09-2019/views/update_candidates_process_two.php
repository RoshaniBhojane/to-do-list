        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
            <form action="<?php echo base_url();?>UpdateCandidatesProcessTwo/updateCandidates" method="post">
              <input type="hidden" name="id" value="<?php if(!empty($data['id'])){echo $data['id'];}else{}?>">
              <input type="hidden" name="date" value="<?php echo date("Y-m-d H:i:s"); ?>">
              <!-- Personal Details -->
              <div class="row">
                <div class="col-md-12 col-xs-12">
                  <div class="x_panel">
                    <div class="x_title">
                      <h2>Personal Details </h2>
                      <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                      <br />
                      <div class="form-horizontal form-label-left input_mask">
                        <div class="row">
                          <h5>Applicant Details</h5>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <label>First Name:</label>
                            <input type="text" class="form-control has-feedback-left" name="first_name" value="<?php if(!empty($data['first_name'])){echo $data['first_name'];}else{}?>">
                            <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                          </div>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <label>Middle Name:</label>
                            <input type="text" class="form-control has-feedback-left" name="middle_name" value="<?php if(!empty($data['middle_name'])){echo $data['middle_name'];}else{}?>">
                            <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                          </div>
                          <div class="col-md-4 col-sm-4 co l-xs-12 form-group has-feedback">
                            <label>Last Name:</label>
                            <input type="text" class="form-control has-feedback-left" name="last_name" value="<?php if(!empty($data['last_name'])){echo $data['last_name'];}else{}?>">
                            <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                          </div>
                        </div>
                        <div class="row">
                          <h5>Father's/Husband's Details</h5>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <label>First Name:</label>
                            <input type="text" class="form-control has-feedback-left" name="fh_first_name" value="<?php if(!empty($data['fh_first_name'])){echo $data['fh_first_name'];}else{}?>">
                            <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                          </div>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <label>Middle Name:</label>
                            <input type="text" class="form-control has-feedback-left" name="fh_middle_name" value="<?php if(!empty($data['fh_middle_name'])){echo $data['fh_middle_name'];}else{}?>">
                            <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                          </div>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <label>Last Name:</label>
                            <input type="text" class="form-control has-feedback-left" name="fh_last_name" value="<?php if(!empty($data['fh_last_name'])){echo $data['fh_last_name'];}else{}?>">
                            <span class="fa fa-user form-control-feedback left" aria-hidden="true"></span>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <label>Date of Birth:</label>
                            <input type="text" class="form-control has-feedback-left" id="myDatepicker1" name="date_of_birth" value="<?php if(!empty($data['date_of_birth'])){echo $data['date_of_birth'];}else{}?>">
                            <span class="fa fa-calendar form-control-feedback left" aria-hidden="true"></span>
                          </div>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <label>Age:</label>
                            <input type="text" class="form-control has-feedback-left" name="age" value="<?php if(!empty($data['age'])){echo $data['age'];}else{}?>" readonly>
                            <span class="fa fa-calculator form-control-feedback left" aria-hidden="true"></span>
                          </div>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <label>Gender:</label>
                            <select class="form-control" name="gender" style="text-transform: capitalize !important;">
                              <option <?php if(!empty($data['gender'])) { ?> value="<?php echo $data['gender']; ?>"  selected="selected" <?php } ?>>
                                <?php echo $data['gender']; ?>
                            </option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                            </select>
                          </div>
                        </div>
                        <div class="ln_solid"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Contact Details And Documents Details -->
              <div class="row">
                <!-- Contact Details -->
                <div class="col-md-6 col-xs-12">
                  <div class="x_panel">
                    <div class="x_title">
                      <h2>Contact Details </h2>
                      <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                      <br />
                      <div class="form-horizontal form-label-left input_mask">
                        <div class="row">
                          <div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
                            <label>Current Address</label>
                            <textarea required="required" class="form-control" name="current_address"><?php if(!empty($data['current_address'])){echo $data['current_address'];}else{}?></textarea>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
                            <label>Permanant Address</label>
                            <textarea required="required" class="form-control" name="permanant_address"><?php if(!empty($data['permanant_address'])){echo $data['permanant_address'];}else{}?></textarea>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                            <label>Phone Number1:</label>
                            <input type="text" class="form-control has-feedback-left" name="primary_phone" value="<?php if(!empty($data['primary_phone'])){echo $data['primary_phone'];}else{}?>">
                            <span class="fa fa-phone form-control-feedback left" aria-hidden="true"></span>
                          </div>
                          <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                            <label>Phone Number2:</label>
                            <input type="text" class="form-control has-feedback-left" name="secondary_phone" value="<?php if(!empty($data['secondary_phone'])){echo $data['secondary_phone'];}else{}?>">
                            <span class="fa fa-phone form-control-feedback left" aria-hidden="true"></span>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                            <label>Primary Email Address:</label>
                            <input type="text" class="form-control has-feedback-left" name="primary_email_address" value="<?php if(!empty($data['primary_email_address'])){echo $data['primary_email_address'];}else{}?>">
                            <span class="fa fa-envelope form-control-feedback left" aria-hidden="true"></span>
                          </div>
                          <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                            <label>Secondary Email Address:</label>
                            <input type="text" class="form-control has-feedback-left" name="secondary_email_address" value="<?php if(!empty($data['secondary_email_address'])){echo $data['secondary_email_address'];}else{}?>">
                            <span class="fa fa-envelope form-control-feedback left" aria-hidden="true"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Documents Details -->
                <div class="col-md-6 col-xs-12">
                  <div class="x_panel">
                    <div class="x_title">
                      <h2>Documents Details </h2>
                      <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                      <br />
                      <div class="form-horizontal form-label-left input_mask">
                        <div class="row">
                          <div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
                            <label >Aadhar Card Nnumber:</label>
                            <input type="text" class="form-control has-feedback-left" name="aadhar_no" value="<?php if(!empty($data['aadhar_no'])){echo $data['aadhar_no'];}else{}?>">
                            <span class="fa fa-credit-card form-control-feedback left" aria-hidden="true"></span>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
                            <label >Passport number:</label>
                            <input type="text" class="form-control has-feedback-left" name="passport_no" value="<?php if(!empty($data['passport_no'])){echo $data['passport_no'];}else{}?>">
                            <span class="fa fa-book form-control-feedback left" aria-hidden="true"></span>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
                            <label >Passport Valid Date:</label>
                            <input type="text" class="form-control has-feedback-left" id="myDatepicker8" name="passport_valid_date" value="<?php if(!empty($data['passport_valid_date'])){echo $data['passport_valid_date'];}else{}?>">
                            <span class="fa fa-calendar form-control-feedback left" aria-hidden="true"></span>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
                            <label >Passport Issue Place:</label>
                            <input type="text" class="form-control has-feedback-left" name="passport_issue_place" value="<?php if(!empty($data['passport_issue_place'])){echo $data['passport_issue_place'];}else{}?>">
                            <span class="fa fa-institution form-control-feedback left" aria-hidden="true"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Personal Details -->
              <div class="row">
                <div class="col-md-12 col-xs-12">
                  <div class="x_panel">
                    <div class="x_title">
                      <h2>Job Details </h2>
                      <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                      <br />
                      <div class="form-horizontal form-label-left input_mask">
                        <div class="row">
                          <div class="col-md-3 col-sm-3 col-xs-12 form-group has-feedback">
                            <label>Designation:</label>
                            <input type="text" class="form-control has-feedback-left" name="designation" value="<?php if(!empty($data['designation'])){echo $data['designation'];}else{}?>">
                            <span class="fa fa-briefcase form-control-feedback left" aria-hidden="true"></span>
                          </div>
                          <div class="col-md-3 col-sm-3 col-xs-12 form-group has-feedback">
                            <label>Experience:</label>
                            <select class="form-control" name="experience">
                                <?php if(!empty($data['experience'])){ ?>                               
                                <option value="<?php echo $data['experience']; ?>"  selected="selected">
                                  <?php if($data['experience'] == 1) { echo "Fresher"; } elseif($data['experience'] == 2) { echo "Experienced"; }?>
                                </option>
                                <?php }?>
                                <option>Select</option>
                                <option value="1"><?php echo "Fresher"; ?></option>
                                <option value="2"><?php echo "Experienced"; ?></option>
                            </select>
                          </div>
                          <div class="col-md-3 col-sm-3 col-xs-12 form-group has-feedback">
                            <label>Source:</label>
                            <select class="form-control" name="source">
                                <?php if(!empty($data['source'])){ ?>                               
                                <option value="<?php echo $data['source']; ?>"  selected="selected">
                                  <?php echo $data['source']; ?>
                                </option>
                                <?php }?>
                                <option>Select</option>
                                <?php
                                if(!empty($source))
                                {
                                  foreach ($source as $source_value) 
                                  {
                              ?>                              
                                    <option value="<?php echo $source_value->source; ?>"><?php echo $source_value->source; ?></option>
                              <?php
                                  }
                                }
                              ?>
                            </select>
                          </div>
                          <div class="col-md-3 col-sm-3 col-xs-12 form-group has-feedback">
                            <label>Status:</label>
                            <select class="form-control" name="status">
                              <option <?php if((!empty($data['status'])) && ($data['status'] == 2)) { ?> value="<?php echo $data['status']; ?>"  selected="selected" <?php } else { ?> value="2" <?php } ?> >
                                Hired
                              </option>
                              <option <?php if((!empty($data['status'])) && ($data['status'] == 5)) { ?> value="<?php echo $data['status']; ?>"  selected="selected" <?php } else { ?> value="5" <?php } ?> >
                                On-Board
                              </option>
                              <option <?php if((!empty($data['status'])) && ($data['status'] == 6)) { ?> value="<?php echo $data['status']; ?>"  selected="selected" <?php } else { ?> value="6" <?php } ?> >
                                Not Joined
                              </option>
                            </select>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
                            <label>Remarks:</label>
                            <textarea required="required" class="form-control" name="comments"><?php if(!empty($data['comments'])){echo $data['comments'];}else{}?></textarea>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <label>Net Salary:</label>
                            <input type="text" class="form-control has-feedback-left" name="net_ctc" value="<?php if(!empty($data['net_ctc'])){echo $data['net_ctc'];}else{}?>">
                            <span class="fa fa-money form-control-feedback left" aria-hidden="true"></span>
                          </div>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <label>Gross Salary:</label>
                            <input type="text" class="form-control has-feedback-left" name="gross_ctc" value="<?php if(!empty($data['gross_ctc'])){echo $data['gross_ctc'];}else{}?>">
                            <span class="fa fa-money form-control-feedback left" aria-hidden="true"></span>
                          </div>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <label>Date of Joining:</label>
                            <input type="text" class="form-control has-feedback-left" name="date_of_join" id="dateofbirth" value="<?php if(!empty($data['date_of_join'])){echo $data['date_of_join'];}else{}?>">
                            <span class="fa fa-calendar form-control-feedback left" aria-hidden="true"></span>
                          </div>
                        </div>
                        <!-- <div class="ln_solid"></div> -->
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Education Details -->
              <div class="row">
                <div class="col-md-12 col-xs-12">
                  <div class="x_panel">
                    <div class="x_title">
                      <h2>Education Details </h2>
                      <div class="clearfix"></div>
                    </div>  
                    <div class="x_content">     
                        <h5>You can upload multiple document onclicking "Add" Button.</h5>
                        <?php
                          if(!empty($candidate_education))
                          {
                            $i=0;
                            foreach ($candidate_education as $candidate_education_value) 
                            {
                        ?>  
                        <div class="row">
                          <input type="hidden" name="edu[<?php echo $i;?>][user_id]" value="<?php if(!empty($data['id'])){echo $data['id'];}else{}?>">
                          <input type="hidden" name="edu[<?php echo $i;?>][date]" value="<?php echo date("Y-m-d H:i:s"); ?>">
                          <div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
                            <select id="ex3" class="form-control" name="edu[<?php echo $i;?>][degree_type]" required="">
                              <option value="<?php echo $candidate_education_value->degree_type; ?>"><?php echo $candidate_education_value->degree_type; ?></option>
                              <?php
                                if(!empty($education))
                                {
                                  foreach ($education as $education_value) 
                                  {
                              ?>                              
                                    <option value="<?php echo $education_value->degree_type; ?>"><?php echo $education_value->degree_type; ?></option>
                              <?php
                                  }
                                }
                              ?>
                          </select>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <input type="text" class="form-control" name="edu[<?php echo $i;?>][name_of_institute]" placeholder="Name of institute" required="" value="<?php if(!empty($candidate_education_value->name_of_institute)){echo $candidate_education_value->name_of_institute;}else{}?>">
                          </div>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <input type="text" class="form-control" name="edu[<?php echo $i;?>][university]" placeholder="University" required="" value="<?php if(!empty($candidate_education_value->university)){echo $candidate_education_value->university;}else{}?>">
                          </div>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <input type="text" class="form-control" name="edu[<?php echo $i;?>][specialization]" placeholder="Specialization" required="" value="<?php if(!empty($candidate_education_value->specialization)){echo $candidate_education_value->specialization;}else{}?>">
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <input type="text" class="form-control" name="edu[<?php echo $i;?>][marks]" placeholder="Marks" required="" value="<?php if(!empty($candidate_education_value->marks)){echo $candidate_education_value->marks;}else{}?>">
                          </div>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <input type="text" class="form-control" name="edu[<?php echo $i;?>][edu_start_date]" placeholder="Start date" id="fromDatepicker" required="" value="<?php if(!empty($candidate_education_value->edu_start_date)){echo $candidate_education_value->edu_start_date;}else{}?>">
                          </div>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <input type="text" class="form-control" name="edu[<?php echo $i;?>][edu_end_date]" placeholder="End date" id="toDatepicker" required="" value="<?php if(!empty($candidate_education_value->edu_end_date)){echo $candidate_education_value->edu_end_date;}else{}?>">
                          </div>
                        </div>
                        <div class="ln_solid"></div>
                        <?php
                              $i++;
                            }
                          }
                          else
                          {
                        ?>
                        <div class="row">
                          <input type="hidden" name="edu[0][user_id]" value="<?php if(!empty($data['id'])){echo $data['id'];}else{}?>">
                          <input type="hidden" name="date" value="<?php echo date("Y-m-d H:i:s"); ?>">
                          <div class="col-md-12 col-sm-12 col-xs-12 form-group has-feedback">
                            <select id="ex3" class="form-control" name="edu[0][degree_type]" required="">
                              <option value="">Select Degree</option>
                              <?php
                                if(!empty($education))
                                {
                                  foreach ($education as $education_value) 
                                  {
                              ?>                              
                                    <option value="<?php echo $education_value->degree_type; ?>"><?php echo $education_value->degree_type; ?></option>
                              <?php
                                  }
                                }
                              ?>
                          </select>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <input type="text" class="form-control" name="edu[0][name_of_institute]" placeholder="Name of institute" required="" value="">
                          </div>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <input type="text" class="form-control" name="edu[0][university]" placeholder="University" required="" value="">
                          </div>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <input type="text" class="form-control" name="edu[0][specialization]" placeholder="Specialization" required="" value="">
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <input type="text" class="form-control" name="edu[0][marks]" placeholder="Marks" required="" value="">
                          </div>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <input type="text" class="form-control" name="edu[0][edu_start_date]" placeholder="Start date" id="fromDatepicker" required="" value="">
                          </div>
                          <div class="col-md-4 col-sm-4 col-xs-12 form-group has-feedback">
                            <input type="text" class="form-control" name="edu[0][edu_end_date]" placeholder="End date" id="toDatepicker" required="" value="">
                          </div>
                        </div>
                        <div class="ln_solid"></div>
                        <?php
                          }
                        ?>

                        <div class="content">                          
                        </div>
                        <div class="row">
                          <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                              <div class="x_content">
                                  <div class="form-group">
                                    <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">
                                      <button class="btn btn-primary" onclick="addeducation();" id="addScnt" type="button">+ Add More</button>
                                    </div>
                                  </div>
                              </div>
                            </div>
                          </div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Buttons -->
              <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="x_panel">
                    <div class="x_content">
                        <div class="form-group">
                          <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-5">
                            <button class="btn btn-primary" type="reset">Reset</button>
                            <button type="submit" class="btn btn-success">Submit</button>
                          </div>
                        </div>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
        <!-- /page content -->