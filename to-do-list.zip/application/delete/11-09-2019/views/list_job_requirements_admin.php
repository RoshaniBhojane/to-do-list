
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Candidates <small>Basic information</small></h3>
              </div>
            </div>

            <div class="clearfix"></div>

            <div class="row">              
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <?php
                    // print_r($this->session->userdata('username'));
                    if($this->session->flashdata('error_msg'))
                    {
                    ?>
                      <div class="alert alert-<?php  echo $this->session->flashdata('msg');?> fade in">
                       <?php  echo $this->session->flashdata('error_msg');?>    
                      </div>
                    <?php
                    }
                  ?>
                  <div class="x_content">
                    <div id="datatable-buttons_wrapper" class="dataTables_wrapper form-inline dt-bootstrap no-footer">
                      <div class="dt-buttons btn-group">
                        <a class="btn btn-default buttons-copy buttons-html5 btn-sm" tabindex="0" aria-controls="datatable-buttons" href="#">
                          <span>Copy</span></a><a class="btn btn-default buttons-csv buttons-html5 btn-sm" tabindex="0" aria-controls="datatable-buttons" href="#"><span>CSV</span></a><a class="btn btn-default buttons-print btn-sm" tabindex="0" aria-controls="datatable-buttons" href="#"><span>Print</span>
                        </a>
                      </div>

                      <div class="dataTables_length" id="datatable-buttons_length">                        
                        <!-- <a class="btn btn-primary" type="submit" href="<?php echo base_url();?>AddJobRequirementsAdmin">Add</a> -->
                        <label>
                          Show 
                          <select name="datatable-buttons_length" aria-controls="datatable-buttons" class="form-control input-sm">
                            <option value="10">10</option>
                            <option value="25">25</option>
                            <option value="50">50</option>
                            <option value="100">100</option>
                          </select> entries
                        </label>
                      </div>

                      <div id="datatable-buttons_filter" class="dataTables_filter">
                        <label>
                          Search:<input type="search" class="form-control input-sm" placeholder="" aria-controls="datatable-buttons">
                        </label>
                      </div>

                      <table id="datatable-buttons" class="table table-striped table-bordered">
                        <thead>
                          <tr>
                            <th>Requested Name</th>
                            <th>Required Designation</th>
                            <th>No. of Requirements</th>
                            <th>Comments</th>
                            <th>Deadline</th>
                            <th>Aproval</th>
                            <th>No. of Fulfill Requirements</th>
                            <th>Status</th>
                            <th>HR Comments</th>
                            <th></th>
                          </tr>
                        </thead>


                        <tbody>
                          <?php
                            if(!empty($opening))
                            {
                              foreach ($opening as $opening_value) 
                              {
                          ?>
                          <tr>
                            <td><?php echo $opening_value['first_name']." ".$opening_value['last_name']; ?></td>
                            <td><?php echo $opening_value['designation']; ?></td>
                            <td><?php echo $opening_value['no_requirements']; ?></td>
                            <td><?php echo $opening_value['comments']; ?></td>
                            <?php 
                              $now = strtotime(date("Y-m-d")); 
                              $your_date = strtotime($opening_value['deadline']);
                              $datediff = $now - $your_date;  
                              $day = round($datediff / (60 * 60 * 24));
                            ?>
                            <td <?php if((($day <= '0') AND ($day > '-7')) AND ($opening_value['no_requirements'] != $opening_value['no_fullfil_requirements'])) {?> class="redwarning" <?php } elseif(($day > '0') AND ($opening_value['no_requirements'] != $opening_value['no_fullfil_requirements']) AND ($opening_value['approved_status'] == '1')) { ?> class="redfail" <?php } elseif($opening_value['no_requirements'] == $opening_value['no_fullfil_requirements']) { ?> class="greensuccess" <?php } ?>>
                              <?php
                               echo $opening_value['deadline'];
                              ?>
                            </td>
                            <td><?php if($opening_value['approved_status'] == '0') { echo "<span style='color: #0b0bec;font-weight: 600;'>Pending</span>"; } elseif($opening_value['approved_status'] == '1') { echo "<span style='color: #008000;font-weight: 600;'>Approved</span>"; } elseif($opening_value['approved_status'] == '2') { echo "<span style='color: red;font-weight: 600;'>Not Approved</span>"; } ?></td>
                            <td><?php echo $opening_value['no_fullfil_requirements']; ?></td>
                            <td><?php if($opening_value['opening_closed_status'] == '0') { echo "<span style='color: #0b0bec;font-weight: 600;'>Pending</span>"; } elseif($opening_value['opening_closed_status'] == '1') { echo "<span style='color: #008000;font-weight: 600;'>Closed</span>"; } elseif($opening_value['opening_closed_status'] == '2') { echo "<span style='color: red;font-weight: 600;'>Not Closed</span>"; } ?></td>
                            <td><?php echo $opening_value['hr_comments']; ?></td>
                            <td>
                              <a href="<?php echo base_url();?>AddJobRequirementsAdmin/updateJobRequirements/<?php echo $opening_value['id'];?>" class="btn btn-info btn-xs"><i class="fa fa-pencil">Edit</i></a>
                            </td>
                          </tr>
                          <?php
                              }
                            }
                          ?>
                          
                          <tr>
                            <td colspan="10"><?php echo $links; ?></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
        <!-- /page content -->