        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Export Candidates Data</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    <div id="divToPrint" style="/*display:none;*/">
                      <table id="datatable-buttons" class="table table-striped table-bordered" border="1" style="border-collapse: collapse;">
                        <thead>
                          <tr>
                            <th>id</th>
                            <th>first_name</th>
                            <th>last_name</th>
                            <th>middle_name</th>
                            <th>fh_first_name</th>
                            <th>fh_middle_name</th>
                            <th>fh_last_name</th>
                            <th>experience</th>
                            <th>source</th>
                            <th>primary_email_address</th>
                            <th>secondary_email_address</th>
                            <th>primary_phone</th>
                            <th>secondary_phone</th>
                            <th>age</th>
                            <th>gender</th>
                            <th>date_of_birth</th>
                            <th>current_address</th>
                            <th>permanant_address</th>
                            <th>aadhar_no</th>
                            <th>passport_no</th>
                            <th>passport_valid_date</th>
                            <th>passport_issue_place</th>
                            <th>designation</th>
                            <th>net_ctc</th>
                            <th>gross_ctc</th>
                            <th>date_of_join</th>
                            <th>comments</th>
                            <th>status</th>
                            <th>date</th>
                            
                              
                                  <th>document_name</th>
                                  <th>deadline_one</th>
                                  <th>deadline_two</th>
                                  <th>comments</th>
                                  <th>status</th>
                           
                          </tr>
                        </thead>


                        <tbody>
                           <?php
                            if(!empty($print))
                            {
                              foreach ($print as $print_value) 
                              {
                                $count = count($print_value['documents_deadline_data']);
                                print_r($count);
                          ?>
                          <tr>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['id']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['first_name']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['last_name']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['middle_name']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['fh_first_name']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['fh_middle_name']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['fh_last_name']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['experience']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['source']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['primary_email_address']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['secondary_email_address']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['primary_phone']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['secondary_phone']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['age']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['gender']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['date_of_birth']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['current_address']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['permanant_address']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['aadhar_no']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['passport_no']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['passport_valid_date']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['passport_issue_place']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['designation']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['net_ctc']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['gross_ctc']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['date_of_join']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['comments']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['status']; ?></td>
                            <td rowspan="<?php echo $count+1; ?>"><?php echo  $print_value['date']; ?></td>
                            
                            <?php
                            foreach($print_value['documents_deadline_data'] as $document_value)
                            {
                            ?>
                            <tr>
                            <td><?php echo  $document_value['document_name']; ?></td>
                            <td><?php echo  $document_value['deadline_one']; ?></td>
                            <td><?php echo  $document_value['deadline_two']; ?></td>
                            <td><?php echo  $document_value['comments']; ?></td>
                            <td><?php echo  $document_value['status']; ?></td>
                            </tr>
                            <?php
                            }
                            ?>
                            
                          </tr>
                          <?php
                              }
                            }
                          ?>
                          <tr>
                            <td colspan="11"><?php //echo $links; ?></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                    <form action="<?php echo base_url();?>ListCandidatesExport/getCandidateDataCount" method="post" id="demo-form2" data-parsley-validate class="form-horizontal form-label-left">
                      
                      <!-- SELECT * FROM `mst_users_tbl` WHERE date_of_join BETWEEN '2019-09-1' AND '2019-09-15' -->
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Date of Joining
                        </label>
                        <div class="col-md-3 col-sm-3 col-xs-12 form-group has-feedback">
                          <input type="text" class="form-control" name="fromdate" id="fromdate" placeholder="From" value="<?php if(!empty($_POST['fromdate'])) { echo $_POST['fromdate']; } else { }?>">
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-12 form-group has-feedback">
                          <input type="text" class="form-control" name="todate" id="todate" placeholder="To" value="<?php if(!empty($_POST['todate'])) { echo $_POST['todate']; } else { }?>">
                        </div>
                      </div>
                       
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Gender 
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <select class="form-control" name="gender">
                            <option value="">Select Gender</option>
                            <option value="male" <?php  if(!empty($_POST['gender']) == 'male') { echo "Selected"; }?>>male</option>
                            <option value="female" <?php  if(!empty($_POST['gender']) == 'female') { echo "Selected"; }?>>female</option>
                          </select>
                        </div>
                      </div>

                      <!-- SELECT * FROM `mst_users_tbl` WHERE age BETWEEN '24' AND '25' -->
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Age 
                        </label>
                        <div class="col-md-3 col-sm-3 col-xs-12 form-group has-feedback">
                          <input type="number" class="form-control" name="fromage" placeholder="From" value="<?php if(!empty($_POST['fromage'])) { echo $_POST['fromage']; }else {}?>">
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-12 form-group has-feedback">
                          <input type="number" class="form-control" name="toage" placeholder="To" value="<?php if(!empty($_POST['toage'])) { echo $_POST['toage']; }else {}?>">
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Status 
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <select class="form-control" name="status">
                            <option value="" selected="selected">Select Status</option>
                            <option value="0" <?php  if((!empty($_POST['status'])) AND ($_POST['status'] == '0')) { ?> selected="selected" <?php }?>>Initiate</option>
                            <option value="1" <?php  if((!empty($_POST['status'])) AND ($_POST['status'] == '1')) { ?> selected="selected" <?php }?>>Inprocess</option>
                            <option value="2" <?php  if((!empty($_POST['status'])) AND ($_POST['status'] == '2')) { ?> selected="selected" <?php }?>>Hired</option>
                            <option value="3" <?php  if((!empty($_POST['status'])) AND ($_POST['status'] == '3')) { ?> selected="selected" <?php }?>>Rejected</option>
                            <option value="4" <?php  if((!empty($_POST['status'])) AND ($_POST['status'] == '4')) { ?> selected="selected" <?php }?>>On Hold</option>
                            <option value="5" <?php  if((!empty($_POST['status'])) AND ($_POST['status'] == '5')) { ?> selected="selected" <?php }?>>On Board</option>
                            <option value="6" <?php  if((!empty($_POST['status'])) AND ($_POST['status'] == '6')) { ?> selected="selected" <?php }?>>Not Joined</option>
                          </select>
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Designation 
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <select class="form-control" name="designation">
                            <?php 
                            if(!empty($_POST['designation']))
                            { 
                            ?>
                            <option value="<?php echo $_POST['designation']; ?>" selected="selected"><?php echo $_POST['designation']; ?></option>
                            <?php
                            }
                            else
                            {
                            ?>
                            <option value="">Select Designation</option>
                            <?php
                            }
                            ?>
                            <?php
                            if(!empty($designation))
                            {
                              foreach ($designation as $designation_value) {
                            ?>
                            <option value="<?php echo $designation_value->designation; ?>"><?php echo $designation_value->designation; ?></option>
                            <?php
                              }
                            }
                            ?>
                          </select>
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Experience 
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <select class="form-control" name="experience">
                            <option value="">Select Experience</option>
                            <option value="1" <?php  if(!empty($_POST['experience']) == '1') { echo "Selected"; }?>>Fresher</option>
                            <option value="2" <?php  if(!empty($_POST['experience']) == '2') { echo "Selected"; }?>>Experienced</option>
                          </select>
                        </div>
                      </div>

                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">
                          Source 
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                          <select class="form-control" name="source">
                            <?php 
                            if(!empty($_POST['source']))
                            { 
                            ?>
                            <option value="<?php echo $_POST['source']; ?>" selected="selected"><?php echo $_POST['source']; ?></option>
                            <?php
                            }
                            else
                            {
                            ?>
                            <option value="">Select Source</option>
                            <?php
                            }
                            ?>
                            <?php
                            if(!empty($source))
                            {
                              foreach ($source as $source_value) {
                            ?>
                            <option value="<?php echo $source_value->source; ?>" <?php  if(!empty($_POST['source']) == '1') { echo "Selected"; }?>><?php echo $source_value->source; ?></option>
                            <?php
                              }
                            }
                            ?>
                          </select>
                        </div>
                      </div>
                      
                   
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <button type="submit" class="btn btn-primary" name="reset" value="reset">Reset</button>
                          <button type="submit" class="btn btn-success" name="add" value="add">Search</button>
                          <button type="submit" class="btn btn-sm btn-warning" name="download" value="download">Download</button>
                          <button type="submit" class="btn btn-sm btn-warning" name="print" value="print" onclick="PrintDiv();">Print</button>
                        </div>
                      </div>
                          <?php if(!empty($count)){ ?>
                          <div class="alert alert-success fade in">
                          <?php echo "The total records are ".$count; ?> 
                          </div>
                          <?php } ?>
                    </form>

                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

