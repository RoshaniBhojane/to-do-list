<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class ListScheduleInterviewProcessOneModel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}

	public function getScheduleInterviewDate($limit, $start,$searchby,$searchkeyword)
	{
		$arr=[];
		
		$fname='';
		if($searchby != '' AND $searchkeyword != '')
		{
			$fname=" AND ".$searchby." LIKE '%".$searchkeyword."%'";
		}
		
		$condition = $this->db->query("SELECT `id`,`first_name`,`last_name`,`primary_email_address`,`primary_phone`,`experience`,`source`,`designation` FROM `mst_users_tbl` WHERE status='0' AND user_role='0' $fname ORDER BY `id` ASC limit $start, $limit");
	    if($condition->num_rows() > 0)
	    {
	    	foreach ($condition->result_array() as $value) {
	    		$condition1 = $this->db->query("SELECT `interview_schedule_date` FROM `interview_schedule_tbl` WHERE user_id=".$value['id']);
	    		
	    		$mstResult = $condition1->result_array();
	    		if(!empty($value['first_name']))
	    		{
	    			$arr[]=array(
		    			'user_id'=>$value['id'],
		    			'first_name'=>$value['first_name'],
		    			'last_name'=>$value['last_name'],
		    			'primary_email_address'=>$value['primary_email_address'],
		    			'primary_phone'=>$value['primary_phone'],
		    			'experience'=>$value['experience'],
		    			'designation'=>$value['designation'],
		    			'source'=>$value['source'],
		    			'interview_date'=>$mstResult
		    		);
	    		}	    		
	    	}
	    	return $arr;
	    }
	    else
	    {
	    	return false;
	    }   
	}
	public function get_ScheduleInterviewDate_count()
	{
		$condition = $this->db->query("SELECT `id`,`first_name`,`last_name`,`primary_email_address`,`primary_phone`,`experience`,`source`,`designation` FROM `mst_users_tbl` WHERE status='0' AND user_role='0' ORDER BY `id` ASC");
	    if($condition->num_rows() > 0)
	    {
	    	return $condition->num_rows();
	    }
	    else
	    {
	    	return false;
	    }   
	}
	public function editScheduleInterviewData($id)
    {
		$condition = $this->db->query("SELECT `id`,`first_name`,`last_name`,`primary_email_address`,`primary_phone`,`experience`,`source`,`designation` FROM `mst_users_tbl` WHERE id=".$id);
	    if($condition->num_rows() > 0)
	    {
	    	return $condition->row_array();
	    }
	    else
	    {
	    	return false;
	    }        
    }
    public function editScheduleInterviewDate($id)
    {
		$condition = $this->db->query("SELECT `user_id`,`interview_schedule_date` FROM `interview_schedule_tbl` WHERE user_id=".$id);
		$mstResult = $condition->result_array();
	    if(count($mstResult) > 0)
	    {
	    	return $mstResult;
	    }
	    else
	    {
	    	return false;
	    }        
    }
    public function addNewCandidates($data,$array)
	{
		$result=$this->db->insert('mst_users_tbl', $data);
		if($result)
		{
			$insert_id = $this->db->insert_id();
			foreach ($array as $arrayvalue) 
			{
				if(!empty($arrayvalue['interview_schedule_date'])){
		        	$this->db->insert('interview_schedule_tbl',array('interview_schedule_date'=>$arrayvalue['interview_schedule_date'],'user_id'=>$insert_id,'date'=>$data['date']));
				}
			}
			return true;;
		}
		else
	    {
	    	return false;
	    } 
	}
    public function addInterviewScheduleData($array,$user_id){
		$this->db->where('user_id',$user_id);
	    $this->db->delete('interview_schedule_tbl');
		foreach ($array as $arrayvalue) 
		{
			if(!empty($arrayvalue['interview_schedule_date'])){
	        	$this->db->insert('interview_schedule_tbl',$arrayvalue);
			}
		}
	}
	public function updateCandidateData($data,$id)
	{
		$this->db->where('id',$id);
        return $this->db->update('mst_users_tbl',$data);   
	}
}
?>
