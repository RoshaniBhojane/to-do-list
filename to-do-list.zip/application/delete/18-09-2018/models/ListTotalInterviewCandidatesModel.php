<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class ListTotalInterviewCandidatesModel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}

	public function getCandidatesScheduleInterview($limit, $start,$searchby,$searchkeyword,$designation,$date)
	{
		$arr = [];
		$fname='';
		if($searchby != '' AND $searchkeyword != '')
		{
			$fname=" AND ".$searchby." LIKE '%".$searchkeyword."%'";
		}
		$condition1 = $this->db->query("SELECT `user_id` FROM `interview_schedule_tbl` WHERE interview_schedule_date='".date('Y-m-d',$date)."'");
		if($condition1->num_rows() > 0)
		{
			foreach($condition1->result_array() as $value) 
			{
				$user_id = $value['user_id'];
				$condition = $this->db->query("SELECT `id`,`first_name`,`last_name`,`primary_email_address`,designation,`primary_phone`,`age`,`experience`,`source`,`gender`,`date_of_birth`,`current_address`,`status`,`comments` FROM `mst_users_tbl` WHERE user_role='0' AND id='".$user_id."' AND designation = '".str_replace('%20',' ', $designation)."' $fname limit $start, $limit");	
				if($condition->num_rows() > 0)
				{
					$arr[]=$condition->row();
				}
			}
			return $arr;
		}
		else
		{
			return false;
		}
	}	

	public function get_getCandidatesScheduleInterview_count($searchby,$searchkeyword,$designation,$date)
	{
		$condition1 = $this->db->query("SELECT `user_id` FROM `interview_schedule_tbl` WHERE interview_schedule_date='".date('Y-m-d',$date)."'");

		if($condition1->num_rows() > 0)
		{
			return $condition1->num_rows();
		}
		else
		{
			return false;
		}
	}

	public function getFutureCandidatesScheduleInterview($limit, $start,$searchby,$searchkeyword,$designation,$date)
	{
		$arr = [];
		$fname='';
		if($searchby != '' AND $searchkeyword != '')
		{
			$fname=" AND ".$searchby." LIKE '%".$searchkeyword."%'";
		}
		$condition1 = $this->db->query("SELECT `user_id` FROM `interview_schedule_tbl` WHERE interview_schedule_date > '".date('Y-m-d',$date)."'");
		if($condition1->num_rows() > 0)
		{
			foreach($condition1->result_array() as $value) 
			{
				$user_id = $value['user_id'];
				$condition = $this->db->query("SELECT `id`,`first_name`,`last_name`,`primary_email_address`,designation,`primary_phone`,`age`,`experience`,`source`,`gender`,`date_of_birth`,`current_address`,`status`,`comments` FROM `mst_users_tbl` WHERE user_role='0' AND id='".$user_id."' AND designation = '".str_replace('%20',' ', $designation)."' $fname limit $start, $limit");	
				if($condition->num_rows() > 0)
				{
					$arr[]=$condition->row();
				}
			}
			return $arr;
		}
		else
		{
			return false;
		}
	}	

	public function get_getFutureCandidatesScheduleInterview_count($searchby,$searchkeyword,$designation,$date)
	{
		$condition1 = $this->db->query("SELECT `user_id` FROM `interview_schedule_tbl` WHERE interview_schedule_date >'".date('Y-m-d',$date)."'");

		if($condition1->num_rows() > 0)
		{
			return $condition1->num_rows();
		}
		else
		{
			return false;
		}
	}

    public function updateCandidateStatus($data,$id)
    {
	    $this->db->where('id',$id);
        return $this->db->update('mst_users_tbl',$data); 
	}
	public function editCandidates($id)
    {
    	$this->db->where('id',$id);
        $query = $this->db->get('mst_users_tbl');
		if($query->num_rows() > 0)
        {
           return $query->row_array();
        }
		else
		{
            return false;
        }          
    }
}
?>
