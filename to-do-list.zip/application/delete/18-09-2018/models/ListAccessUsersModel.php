<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class ListAccessUsersModel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	public function getCandidatesdData($limit, $start)
	{
		$condition = $this->db->query("SELECT `id`,`first_name`,`last_name`,`primary_email_address`,`primary_phone`, `user_role` FROM `mst_users_tbl` WHERE user_role !='0' limit $start, $limit");
		//$query = $this->db->get($condition)
	    if($condition->num_rows() > 0)
	    {
	    	return $condition->result();
	    }
	    else
	    {
	    	return false;
	    }   
	}	

	public function get_candidates_count()
	{
		$condition = $this->db->query("SELECT `id`,`first_name`,`last_name`,`primary_email_address`,`primary_phone`, `user_role` FROM `mst_users_tbl` WHERE user_role !='0'");
		//$query = $this->db->get($condition)
	    if($condition->num_rows() > 0)
	    {
	    	return $condition->num_rows();
	    }
	    else
	    {
	    	return false;
	    }   
	}
    public function updateUsersRole($data,$id)
    {
	    $this->db->where('id',$id);
        return $this->db->update('mst_users_tbl',$data); 
	}
}
?>
