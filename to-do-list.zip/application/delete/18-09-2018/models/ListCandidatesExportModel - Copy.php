<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class ListCandidatesExportModel extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	public function getCandidateDataPrint($data)
	{
		$where = '';
		if(!empty($data['fromdate']))
		{
			$where .= " AND (`date_of_join` BETWEEN '".$data['fromdate']."' AND '".$data['todate']."')";
		}
		if(!empty($data['gender']))
		{
			$where .= " AND `gender` = '".$data['gender']."'";
		}
		if(!empty($data['fromage']))
		{
			$where .= " AND (`age` BETWEEN '".$data['fromage']."' AND '".$data['toage']."')";
		}
		if(!empty($data['status']))
		{
			$where .= " AND `status` = '".$data['status']."'";
		}
		if(!empty($data['designation']))
		{
			$where .= " AND `designation` = '".$data['designation']."'";
		}
		if(!empty($data['experience']))
		{
			$where .= " AND `experience` = '".$data['experience']."'";
		}
		if(!empty($data['source']))
		{
			$where .= " AND `source` = '".$data['source']."'";
		}
		$arr=[];
		$condition = $this->db->query("SELECT * FROM `mst_users_tbl` WHERE id !=''".$where);
		//print_r($this->db->last_query());
		if($condition)
		{
			foreach ($condition->result_array() as $values) 
			{
				$condition1 = $this->db->query("SELECT `user_id`, `name_of_institute`, `university`, `location`, `degree_type`, `specialization`, `marks`, `edu_start_date`, `edu_end_date` FROM `education_tbl` WHERE user_id=".$values['id']);
				$mstResult1 = $condition1->result_array();

				$condition2 = $this->db->query("SELECT `user_id`, `document_name`, `deadline_one`, `deadline_two`, `comments`, `status` FROM `documents_deadline_tbl` WHERE user_id =".$values['id']);
				$mstResult2 = $condition2->result_array();

				$condition3 = $this->db->query("SELECT user_id, interview_schedule_date FROM `interview_schedule_tbl` WHERE user_id =".$values['id']);
				$mstResult3 = $condition3->result_array();

				$condition4 = $this->db->query("SELECT user_id, document_name, document_path, document_uploading_date FROM `documents_tbl` WHERE user_id =".$values['id']);
				$mstResult4 = $condition4->result_array();
				if(!empty($values['id']))
	    		{
	    			$arr[]=array(
		    			'id' => $values['id'],
						'first_name' => $values['first_name'],
						'last_name' => $values['last_name'],
						'middle_name' => $values['middle_name'],
						'fh_first_name' => $values['fh_first_name'],
						'fh_middle_name' => $values['fh_middle_name'],
						'fh_last_name' => $values['fh_last_name'],
						'experience' => $values['experience'],
						'source' => $values['source'],
						'primary_email_address' => $values['primary_email_address'],
						'secondary_email_address' => $values['secondary_email_address'],
						'primary_phone' => $values['primary_phone'],
						'secondary_phone' => $values['secondary_phone'],
						'age' => $values['age'],
						'gender' => $values['gender'],
						'date_of_birth' => $values['date_of_birth'],
						'current_address' => $values['current_address'],
						'permanant_address' => $values['permanant_address'],
						'aadhar_no' => $values['aadhar_no'],
						'passport_no' => $values['passport_no'],
						'passport_valid_date' => $values['passport_valid_date'],
						'passport_issue_place' => $values['passport_issue_place'],
						'designation' => $values['designation'],
						'net_ctc' => $values['net_ctc'],
						'gross_ctc' => $values['gross_ctc'],
						'date_of_join' => $values['date_of_join'],
						'comments' => $values['comments'],
						'status' => $values['status'],
						'date' => $values['date'],
		    			'education_data'=>$mstResult1,
		    			'documents_deadline_data'=>$mstResult2,
		    			'interview_schedule_data'=>$mstResult3,
		    			'document_uploading_data'=>$mstResult4
		    		);
	    		}	

			}
	    	return $arr;
		}
		else
		{
			return false;
		}   
	}
	public function getCandidateDataCount($data)
	{
		$where = '';
		if(!empty($data['fromdate']))
		{
			$where .= " AND (`date_of_join` BETWEEN '".$data['fromdate']."' AND '".$data['todate']."')";
		}
		if(!empty($data['gender']))
		{
			$where .= " AND `gender` = '".$data['gender']."'";
		}
		if(!empty($data['fromage']))
		{
			$where .= " AND (`age` BETWEEN '".$data['fromage']."' AND '".$data['toage']."')";
		}
		if(!empty($data['status']))
		{
			$where .= " AND `status` = '".$data['status']."'";
		}
		if(!empty($data['designation']))
		{
			$where .= " AND `designation` = '".$data['designation']."'";
		}
		if(!empty($data['experience']))
		{
			$where .= " AND `experience` = '".$data['experience']."'";
		}
		if(!empty($data['source']))
		{
			$where .= " AND `source` = '".$data['source']."'";
		}
		$condition = $this->db->query("SELECT * FROM `mst_users_tbl` WHERE id !=''".$where);
		//print_r($this->db->last_query());
		if($condition)
		{
	    	return $condition->result_array();
		}
		else
		{
			return false;
		}   
	}	
}
?>
