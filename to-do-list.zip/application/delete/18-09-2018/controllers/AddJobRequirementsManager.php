<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AddJobRequirementsManager extends CI_Controller {
	function __construct() 
	{
		parent::__construct();
		$this->load->helper('url');		
		$this->load->library('session');
		$this->load->model('AddJobRequirementsManagerModels');
		$this->load->model('ListJobRequirementsManagerModel');
		$this->load->model('ListDesignationModel');
	}
	public function index()
	{
		$data['designation'] = $this->ListDesignationModel->getDesignationList();
		$this->load->view('layout/header');
		$this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('add_job_requirements_manager', $data);
		$this->load->view('layout/footer');
	}
	public function addNewJobRequirements()
	{
		if($this->input->post('id'))
		{
			//get form's data and store in local varable
			$data['date']=$this->input->post('date');
			$data['user_id']=$this->input->post('user_id');
			$data['designation']=$this->input->post('designation');
			$data['no_requirements']=$this->input->post('no_requirements');
			$data['comments']=$this->input->post('comments');
			$result = $this->AddJobRequirementsManagerModels->updateCandidates($data,$this->input->post('id'));
			if($result)
			{
				$this->session->set_flashdata('msg', 'success');				
				$this->session->set_flashdata('error_msg', 'Record Sucessfuly added!');
				redirect('ListJobRequirementsManager');
			}
			else
			{
				$this->session->set_flashdata('msg', 'danger');
				$this->session->set_flashdata('error_msg', 'Data not updated!');
				redirect('ListJobRequirementsManager');
			}
		}
		else
		{
			//get form's data and store in local varable
			$data['date']=$this->input->post('date');
			$data['user_id']=$this->input->post('user_id');
			$data['designation']=$this->input->post('designation');
			$data['no_requirements']=$this->input->post('no_requirements');
			$data['comments']=$this->input->post('comments');			
			$result = $this->AddJobRequirementsManagerModels->addNewJobRequirements($data);
			$data['admin'] = $this->AddJobRequirementsManagerModels->getAdmin();
			if($result)
			{
				// Load PHPMailer library
		        $this->load->library('phpmailer_lib');
		        
		        // PHPMailer object
		        $mail = $this->phpmailer_lib->load();
		        
		        // SMTP configuration
		        $mail->isSMTP();
		        $mail->Host     = 'smtp.gmail.com';
		        $mail->SMTPAuth = true;
		        $mail->Username = 'contact@digitalzonein.com';
		        $mail->Password = 'TeamWork$2018';
		        $mail->SMTPSecure = 'ssl';
		        $mail->Port     = 465;
		        
		        $mail->setFrom('contact@digitalzonein.com', 'Test Email');
		        $mail->addReplyTo('contact@digitalzonein.com', 'Test Email');
		        
		        // Add a recipient
				foreach ($data['admin'] as $admin_value) {
					$mail->addAddress($admin_value->primary_email_address);
				}
		        
		        // Email subject
		        $mail->Subject = 'Login details for Recruitionary';
		        
		        // Set email format to HTML
		        $mail->isHTML(true);
		        
		        // Email body content
		        $mailContent = '<!DOCTYPE html>
			        <html>
			        <head>
			          <title></title>
			        </head>
			        <body> 
			        <div id="body" class="mktoText" style="font-family: Helvetica, Arial, Sans-Serif; padding:10px;">
			        <section> 
			        <table id="table-parent" style="background-color: #ffffff; border: 0 none; border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0;" bgcolor="#ffffff" border="0" cellpadding="0" cellspacing="0" width="100%"> 
			        <tbody> 
			        <tr> 
			        <td id="td-parent" style="border-collapse: collapse; font-family: Roboto, sans-serif; padding: 0;" align="center" bgcolor="#ffffff">
			        <div id="email" style="background-color: #ffffff; margin: 0 auto; padding: 20px 10px;" bgcolor="#ffffff"> 
			        <table class="bodyWrap" align="center" style="background-color: #f1f3f4; border: 0 none; border-collapse: collapse; margin: 0; max-width: 600px; mso-table-lspace: 0; mso-table-rspace: 0; padding: 0;" bgcolor="#f1f3f4" border="0" cellpadding="0" cellspacing="0" width="100%"> 
			        <tbody> 
			        <tr> 
			        <td class="bodyWrap-td" style="border-collapse: collapse; font-family: Roboto, sans-serif; padding: 0;"> 
			        <table style="border: 0 none; border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0;" border="0" cellpadding="0" cellspacing="0" width="100%"> 
			        <tbody> 
			        <tr> 
			        <td class="header-content" style="border-collapse: collapse; font-family: Roboto, sans-serif; padding: 28px 0;" align="center" bgcolor="#ffffff" valign="top" width="100%"> 
			        <table style="border: 0 none; border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0;" align="center" border="0" cellpadding="0" cellspacing="0" width="100%"> 
			        <tbody> 
			        <tr> 
			        <td class="logo" style="border-collapse: collapse; font-family: Roboto, sans-serif; padding: 0;" align="center" valign="top" width="100%"><a href="#" target="_blank"><!-- <img src="cid:logoemail" style="border: 0 none; display: block; height: auto; max-height: auto;" /> -->recruitionary</a></td> 
			        </tr> 
			        </tbody> 
			        </table> </td> 
			        </tr> 
			        <tr> 
			        <td class="body-content" style="border-collapse: collapse; font-family: Roboto, sans-serif; padding: 20px;background: #1ABB9C;" align="center" valign="top" width="100%"> 
			        <table style="border: 0 none; border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0;" align="center" border="0" cellpadding="0" cellspacing="0" width="100%">  
			        <tbody> 
			        <tr> 
			        <td class="mod-container-td" style="border: 1px solid #eef0f1; border-collapse: collapse; font-family: Roboto, sans-serif;" align="center" bgcolor="#ffffff" valign="top" width="100%"> 
			        <table style="border: 0 none; border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0;" border="0" cellpadding="0" cellspacing="0" width="100%"> 
			        <tbody> 
			        <tr> 
			          <td><br></td>
			        </tr> 
			        <tr> 
			        <td class="mod-padding" style="border-collapse: collapse; font-family: Roboto, sans-serif; padding: 25px 30px;" width="100%"> 
			        <table style="border: 0 none; border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0;" border="0" cellpadding="0" cellspacing="0"> 
			        <tbody> 
			        <tr> 
			        <td class="copy" style="border-collapse: collapse; color: #5f6368; font-family: Roboto, sans-serif; font-size: 16px; line-height: 26px; padding: 10px 0 0;" width="100%">
			        Dear Admin,
			        <br><br>
			        '.$this->session->userdata('first_name').' '.$this->session->userdata('last_name').' requested for '.$data['no_requirements'].' '.$data['designation'].'.<br><br>
			        "'.$data['comments'].'"
			        <br><br>
			        Regards,<br>
			        Recruitionary
			        <br>
			        </td> 
			        </tr> 
			        </tbody> 
			        </table> </td> 
			        </tr> 
			        </tbody> 
			        </table> </td> 
			        </tr> 
			        </tbody> 
			        </table> </td> 
			        </tr>  
			        </tbody> 
			        </table> </td> 
			        </tr> 
			        <tr> 
			        <td class="footer-content" style="border-collapse: collapse; font-family: Roboto, sans-serif; padding: 25px 30px;" align="center" bgcolor="#ffffff" valign="top" width="100%"> 
			        <table style="border: 0 none; border-collapse: collapse; mso-table-lspace: 0; mso-table-rspace: 0;" align="center" border="0" cellpadding="0" cellspacing="0" width="100%"> 
			        <tbody> 
			        <tr> 
			        <td class="footer-addr" style="border-collapse: collapse; color: #313030; font-family: Roboto, sans-serif; font-size: 13px; line-height: 14px; padding: 0 0 15px;" align="center" valign="top" width="100%"><span class="ios-link-footer-addr" style="color: #313030; cursor: text; text-decoration: none;"><span><a target="_blank" href="http://www.digitalzonein.com/" style="color: #215968; font-size: 20px;font-weight: bold;text-decoration: none;">Digitalzone Business Consulting</a><br>301 & 338, 3rd  Floor C-3, Amanora Chambers, Amanora Town, Hadapsar, Pune - 411028</span></span></td> 
			        </tr> 
			        </tbody> 
			        </table> </td> 
			        </tr> 
			        </tbody> 
			        </table> 
			        </div> </td> 
			        </tr> 
			        </tbody> 
			        </table> 
			        </section> 
			        </div>  
			        </body>
			        </html>';
		        $mail->Body = $mailContent;
		        
		        // Send email
		        if(!$mail->send()){
		            $this->session->set_flashdata('msg', 'danger');
					$this->session->set_flashdata('error_msg', $mail->ErrorInfo);
		 			redirect('ListJobRequirementsManager');
		        }else{		
		        	$this->session->set_flashdata('msg', 'success');	
		        	$this->session->set_flashdata('error_msg', 'Request sucessfuly send to admin');            
					redirect('ListJobRequirementsManager');
		        }
			}
			else
			{
				$this->session->set_flashdata('msg', 'danger');
				$this->session->set_flashdata('error_msg', 'Data not updated!');
				redirect('ListJobRequirementsManager');
			}
		}
	}
	public function updateJobRequirements()
	{
		$data['opening'] = $this->ListJobRequirementsManagerModel->editJobRequirements($this->uri->segment(3));
		$data['designation'] = $this->ListDesignationModel->getDesignationList();
	    $this->load->view('layout/header'); 
	    $this->load->view('layout/menu_side_bar');
		$this->load->view('layout/menu_top_bar');
		$this->load->view('add_job_requirements_manager', $data);
        $this->load->view('layout/footer');
	}
}
